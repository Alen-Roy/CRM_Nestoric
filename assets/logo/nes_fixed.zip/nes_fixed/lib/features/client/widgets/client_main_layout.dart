import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:nes/core/widgets/clay_container.dart';
import 'package:nes/features/client/pages/profile_page.dart';
import 'package:nes/features/client/pages/client_dashboard.dart';
import 'package:nes/features/client/pages/my_request_page.dart';

/// Global key to switch nav tabs from child widgets (e.g. dashboard avatar → profile tab)
final clientNavKey = GlobalKey<ClientMainLayoutState>();

class ClientMainLayout extends StatefulWidget {
  const ClientMainLayout({super.key});

  @override
  State<ClientMainLayout> createState() => ClientMainLayoutState();
}

class ClientMainLayoutState extends State<ClientMainLayout> {
  int _selectedIndex = 0;

  /// Allow children to switch tabs programmatically
  void switchToTab(int index) {
    if (_selectedIndex == index) return;
    setState(() => _selectedIndex = index);
  }

  static final _items = [
    _NavItemData(PhosphorIconsFill.house, PhosphorIconsRegular.house, 'Home'),
    _NavItemData(
      PhosphorIconsFill.clipboardText,
      PhosphorIconsRegular.clipboardText,
      'Requests',
    ),
    _NavItemData(
      PhosphorIconsFill.userCircle,
      PhosphorIconsRegular.userCircle,
      'Profile',
    ),
  ];

  late final List<Widget> _screens = const [
    ClientDashboard(),
    MyRequestsPage(),
    ProfilePage(),
  ];

  void _onItemTapped(int index) {
    if (_selectedIndex == index) return;
    setState(() => _selectedIndex = index);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    final baseColor = isDark
        ? const Color(0xFF2D2D2D)
        : const Color(0xFFDEE4EA);

    return PopScope(
      // If we're on dashboard (index 0), let the OS handle it (minimize).
      // Otherwise intercept and go to dashboard first.
      canPop: _selectedIndex == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) {
          setState(() => _selectedIndex = 0);
        }
      },
      child: Scaffold(
        body: AnimatedSwitcher(
          duration: const Duration(milliseconds: 200),
          switchInCurve: Curves.easeOutCubic,
          switchOutCurve: Curves.easeInCubic,
          transitionBuilder: (child, animation) {
            return FadeTransition(opacity: animation, child: child);
          },
          child: KeyedSubtree(
            key: ValueKey(_selectedIndex),
            child: _screens[_selectedIndex],
          ),
        ),
        extendBody: true,
        bottomNavigationBar: RepaintBoundary(
          child: Padding(
            padding: EdgeInsets.fromLTRB(16, 0, 16, 12 + bottomPadding),
            child: ClayContainer(
              color: baseColor,
              borderRadius: 28,
              depth: 25,
              spread: 2,
              height: 72,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: List.generate(
                  _items.length,
                  (i) => _ClayNavItem(
                    data: _items[i],
                    isSelected: _selectedIndex == i,
                    onTap: () => _onItemTapped(i),
                    color: theme.colorScheme.primary,
                    isDark: isDark,
                    baseColor: baseColor,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _NavItemData {
  final IconData activeIcon;
  final IconData inactiveIcon;
  final String label;

  const _NavItemData(this.activeIcon, this.inactiveIcon, this.label);
}

/// Clay-themed nav item with embossed active indicator
class _ClayNavItem extends StatelessWidget {
  final _NavItemData data;
  final bool isSelected;
  final VoidCallback onTap;
  final Color color;
  final bool isDark;
  final Color baseColor;

  const _ClayNavItem({
    required this.data,
    required this.isSelected,
    required this.onTap,
    required this.color,
    required this.isDark,
    required this.baseColor,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 80,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ClayContainer(
              color: baseColor,
              borderRadius: 50, // Circular
              depth: isSelected ? -15 : 10, // Embossed when selected
              spread: 1,
              emboss: isSelected,
              width: 48,
              height: 48,
              child: Icon(
                isSelected ? data.activeIcon : data.inactiveIcon,
                color: isSelected
                    ? color
                    : (isDark ? Colors.white38 : const Color(0xFF9CA3AF)),
                size: 24,
              ),
            ),
            const SizedBox(height: 4),
            if (isSelected) // Only show label if selected to save space or keep clean
              Text(
                data.label,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  color: color,
                  letterSpacing: 0.2,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
