import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';
import 'package:nes/features/client/model/client_model.dart';
import 'package:nes/services/client_api_service.dart';

// Provider for client stats
final clientStatsProvider = FutureProvider.autoDispose<ClientStats>((
  ref,
) async {
  final token = ref.watch(authProvider).token;
  if (token == null) {
    throw Exception('Not authenticated');
  }

  final result = await ClientApiService.getClientStats(token);
  if (result['success']) {
    return ClientStats.fromJson(result['stats']);
  } else {
    throw Exception(result['error']);
  }
});

// Provider for client requests
final myRequestsProvider = FutureProvider.autoDispose<List<ClientRequest>>((
  ref,
) async {
  final token = ref.watch(authProvider).token;
  if (token == null) {
    throw Exception('Not authenticated');
  }

  final result = await ClientApiService.getMyRequests(token);
  if (result['success']) {
    final requestsData = result['requests'] as List;
    return requestsData.map((r) => ClientRequest.fromJson(r)).toList();
  } else {
    throw Exception(result['error']);
  }
});
