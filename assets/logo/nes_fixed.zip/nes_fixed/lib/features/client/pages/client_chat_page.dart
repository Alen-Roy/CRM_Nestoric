import 'dart:async';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:mime/mime.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';
import 'package:nes/services/chat_api_service.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';

import 'package:nes/core/widgets/clay_container.dart';

class ClientChatPage extends ConsumerStatefulWidget {
  final String requestId;
  final String workerName;
  final String? workerAvatar;

  const ClientChatPage({
    super.key,
    required this.requestId,
    required this.workerName,
    this.workerAvatar,
  });

  @override
  ConsumerState<ClientChatPage> createState() => _ClientChatPageState();
}

class _ClientChatPageState extends ConsumerState<ClientChatPage> {
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  List<ChatMessage> _messages = [];
  bool _isLoading = true;
  bool _isSending = false;
  Timer? _timer;
  bool _isUploading = false;
  bool _hasText = false;

  @override
  void initState() {
    super.initState();
    _loadMessages();
    _messageController.addListener(_onTextChanged);
    _timer = Timer.periodic(
      const Duration(seconds: 3),
      (_) => _loadMessages(silent: true),
    );
  }

  void _onTextChanged() {
    final hasText = _messageController.text.trim().isNotEmpty;
    if (hasText != _hasText) {
      setState(() => _hasText = hasText);
    }
  }

  @override
  void dispose() {
    _messageController.removeListener(_onTextChanged);
    _messageController.dispose();
    _scrollController.dispose();
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _loadMessages({bool silent = false}) async {
    if (!silent) setState(() => _isLoading = true);

    try {
      final token = ref.read(authProvider).token;
      if (token == null) return;

      final result = await ChatApiService.getMessages(
        token: token,
        requestId: widget.requestId,
      );

      if (mounted && result['success']) {
        final List<dynamic> data = result['messages'];
        final newMessages = data.map((m) => ChatMessage.fromJson(m)).toList();

        bool shouldScroll = newMessages.length > _messages.length;

        setState(() {
          _messages = newMessages;
          _isLoading = false;
        });

        ChatApiService.markAsRead(token: token, requestId: widget.requestId);

        if (!silent && _messages.isNotEmpty || shouldScroll) {
          WidgetsBinding.instance.addPostFrameCallback(
            (_) => _scrollToBottom(),
          );
        }
      }
    } catch (e) {
      if (mounted && !silent) setState(() => _isLoading = false);
    }
  }

  void _scrollToBottom() {
    if (_scrollController.hasClients) {
      _scrollController.animateTo(
        _scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeOut,
      );
    }
  }

  Future<void> _sendMessage({
    String? fileUrl,
    String? fileName,
    String? fileType,
  }) async {
    final text = _messageController.text.trim();
    if (text.isEmpty && fileUrl == null) return;

    setState(() => _isSending = true);

    try {
      final token = ref.read(authProvider).token;
      if (token == null) return;

      final result = await ChatApiService.sendMessage(
        token: token,
        requestId: widget.requestId,
        message: text.isEmpty ? (fileUrl != null ? 'Shared a file' : '') : text,
        fileUrl: fileUrl,
        fileName: fileName,
        fileType: fileType,
      );

      if (mounted) {
        if (result['success']) {
          _messageController.clear();
          _loadMessages(silent: true);
          WidgetsBinding.instance.addPostFrameCallback(
            (_) => _scrollToBottom(),
          );
        }
        setState(() => _isSending = false);
      }
    } catch (e) {
      if (mounted) setState(() => _isSending = false);
    }
  }

  // --- Attachment Logic ---

  void _showAttachmentOptions() {
    HapticFeedback.mediumImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) => _AttachmentSheet(
        onPickImage: () => _pickImage(ImageSource.gallery),
        onPickCamera: () => _pickImage(ImageSource.camera),
        onPickDocument: _pickDocument,
      ),
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    Navigator.pop(context);
    try {
      final picker = ImagePicker();
      final XFile? image = await picker.pickImage(
        source: source,
        imageQuality: 70,
      );

      if (image != null) {
        _uploadAndSendFile(File(image.path), 'image');
      }
    } catch (e) {
      debugPrint('Error picking image: $e');
    }
  }

  Future<void> _pickDocument() async {
    Navigator.pop(context);
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'txt'],
      );

      if (result != null &&
          result.files.isNotEmpty &&
          result.files.single.path != null) {
        _uploadAndSendFile(
          File(result.files.single.path!),
          'document',
          name: result.files.single.name,
        );
      }
    } catch (e) {
      debugPrint('Error picking document: $e');
    }
  }

  Future<void> _uploadAndSendFile(
    File file,
    String type, {
    String? name,
  }) async {
    setState(() => _isUploading = true);
    try {
      final token = ref.read(authProvider).token;
      if (token == null) return;

      final uploadRes = await ChatApiService.uploadFile(
        token: token,
        file: file,
        type: type,
      );

      if (uploadRes['success']) {
        final resolvedUrl = uploadRes['url'];
        if (resolvedUrl == null || resolvedUrl.toString().isEmpty) {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Upload succeeded but no URL returned'),
              ),
            );
          }
          return;
        }
        // Use actual MIME type for proper file type identification
        final mimeType =
            lookupMimeType(file.path) ??
            (type == 'image' ? 'image/jpeg' : 'application/octet-stream');
        await _sendMessage(
          fileUrl: resolvedUrl,
          fileName: name ?? file.path.split(Platform.pathSeparator).last,
          fileType: mimeType,
        );
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Upload failed: ${uploadRes['error']}')),
          );
        }
      }
    } catch (e) {
      debugPrint('Upload error: $e');
    } finally {
      if (mounted) setState(() => _isUploading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    // Soft Blue-Grey Clay Theme (matching worker chat)
    final baseColor = isDark
        ? const Color(0xFF2D2D2D)
        : const Color(0xFFDEE4EA);

    final clayTextColor = isDark ? Colors.white70 : const Color(0xFF485057);

    return Scaffold(
      backgroundColor: baseColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: Center(
            child: ClayContainer(
              height: 44,
              width: 44,
              borderRadius: 22,
              depth: 20,
              spread: 1,
              color: baseColor,
              child: IconButton(
                icon: Icon(
                  PhosphorIconsRegular.caretLeft,
                  size: 22,
                  color: clayTextColor,
                ),
                onPressed: () => Navigator.pop(context),
              ),
            ),
          ),
        ),
        title: Column(
          children: [
            Text(
              widget.workerName,
              style: GoogleFonts.plusJakartaSans(
                fontWeight: FontWeight.w800,
                fontSize: 18,
                color: clayTextColor,
              ),
            ),
            Text(
              'Expert',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: Colors.green,
              ),
            ),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Center(
              child: ClayContainer(
                height: 44,
                width: 44,
                borderRadius: 22,
                depth: 20,
                spread: 1,
                color: baseColor,
                child: Hero(
                  tag: 'avatar_${widget.requestId}',
                  child: CircleAvatar(
                    backgroundImage: widget.workerAvatar != null
                        ? NetworkImage(widget.workerAvatar!)
                        : null,
                    backgroundColor: Colors.transparent,
                    child: widget.workerAvatar == null
                        ? Icon(PhosphorIconsFill.user, color: clayTextColor)
                        : null,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          if (_isUploading)
            LinearProgressIndicator(
              backgroundColor: Colors.transparent,
              color: theme.colorScheme.secondary,
            ),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _messages.isEmpty
                ? Center(
                    child: ClayContainer(
                      color: baseColor,
                      borderRadius: 20,
                      depth: 20,
                      padding: const EdgeInsets.all(32),
                      child: Text(
                        'Start chatting\nwith ${widget.workerName}',
                        textAlign: TextAlign.center,
                        style: theme.textTheme.headlineSmall?.copyWith(
                          fontWeight: FontWeight.bold,
                          color: clayTextColor.withValues(alpha: 0.5),
                        ),
                      ),
                    ),
                  )
                : ListView.builder(
                    controller: _scrollController,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 16,
                    ),
                    itemCount: _messages.length,
                    addAutomaticKeepAlives: true,
                    cacheExtent: 500,
                    itemBuilder: (context, index) {
                      final msg = _messages[index];
                      final isMe = msg.senderRole == 'client';

                      // Date separator between different days
                      Widget? dateSeparator;
                      if (index == 0 ||
                          !_isSameDay(
                            _messages[index - 1].timestamp,
                            msg.timestamp,
                          )) {
                        dateSeparator = _buildDateSeparator(
                          msg.timestamp,
                          clayTextColor,
                          baseColor,
                        );
                      }

                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          if (dateSeparator != null) dateSeparator,
                          Align(
                            alignment: isMe
                                ? Alignment.centerRight
                                : Alignment.centerLeft,
                            child: _ClayBubble(
                              key: ValueKey(msg.id),
                              message: msg,
                              isMe: isMe,
                              baseColor: baseColor,
                              isDark: isDark,
                              theme: theme,
                              textColor: clayTextColor,
                              senderName: isMe ? null : widget.workerName,
                            ),
                          ),
                        ],
                      );
                    },
                  ),
          ),
          _buildInputArea(baseColor, isDark, theme, clayTextColor),
        ],
      ),
    );
  }

  bool _isSameDay(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }

  Widget _buildDateSeparator(DateTime date, Color textColor, Color baseColor) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final msgDay = DateTime(date.year, date.month, date.day);
    final diff = today.difference(msgDay).inDays;

    String label;
    if (diff == 0) {
      label = 'Today';
    } else if (diff == 1) {
      label = 'Yesterday';
    } else {
      label = '${date.day}/${date.month}/${date.year}';
    }

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Center(
        child: ClayContainer(
          color: baseColor,
          borderRadius: 12,
          depth: 8,
          spread: 1,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          child: Text(
            label,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: textColor.withValues(alpha: 0.5),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInputArea(
    Color baseColor,
    bool isDark,
    ThemeData theme,
    Color textColor,
  ) {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
        color: baseColor,
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Expanded(
              child: ClayContainer(
                color: baseColor,
                borderRadius: 30,
                depth: -15,
                spread: 1,
                emboss: true,
                padding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 6,
                ),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _messageController,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 15,
                          fontWeight: FontWeight.w500,
                          color: textColor,
                        ),
                        maxLines: 5,
                        minLines: 1,
                        decoration: InputDecoration(
                          hintText: 'Type something...',
                          hintStyle: TextStyle(
                            fontSize: 15,
                            color: textColor.withValues(alpha: 0.4),
                          ),
                          border: InputBorder.none,
                          contentPadding: const EdgeInsets.symmetric(
                            vertical: 8,
                          ),
                        ),
                      ),
                    ),
                    IconButton(
                      icon: Icon(
                        PhosphorIconsRegular.paperclip,
                        size: 22,
                        color: textColor.withValues(alpha: 0.6),
                      ),
                      onPressed: _showAttachmentOptions,
                    ),
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 200),
                      child: !_hasText
                          ? IconButton(
                              key: const ValueKey('camera'),
                              icon: Icon(
                                PhosphorIconsRegular.camera,
                                size: 22,
                                color: textColor.withValues(alpha: 0.6),
                              ),
                              onPressed: () => _pickImage(ImageSource.camera),
                            )
                          : const SizedBox.shrink(key: ValueKey('empty')),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 12),
            GestureDetector(
              onTap: _hasText && !_isSending ? () => _sendMessage() : null,
              child: ClayContainer(
                color: baseColor,
                borderRadius: 50,
                depth: 40,
                spread: 3,
                width: 52,
                height: 52,
                child: _isSending
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(
                          strokeWidth: 2.5,
                          color: Colors.white70,
                        ),
                      )
                    : Icon(
                        PhosphorIconsFill.paperPlaneTilt,
                        color: _hasText
                            ? (isDark
                                  ? Colors.white
                                  : theme.colorScheme.primary)
                            : (isDark
                                  ? Colors.white30
                                  : theme.colorScheme.primary.withValues(
                                      alpha: 0.35,
                                    )),
                        size: 24,
                      ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─── Clay Bubble ───
class _ClayBubble extends StatelessWidget {
  final ChatMessage message;
  final bool isMe;
  final Color baseColor;
  final bool isDark;
  final ThemeData theme;
  final Color textColor;
  final String? senderName;

  const _ClayBubble({
    super.key,
    required this.message,
    required this.isMe,
    required this.baseColor,
    required this.isDark,
    required this.theme,
    required this.textColor,
    this.senderName,
  });

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final maxBubbleWidth = screenWidth * 0.75;

    final bubbleColor = isMe
        ? (isDark ? theme.colorScheme.primary : const Color(0xFF7D7AFF))
        : baseColor;
    final bubbleTextColor = isMe ? Colors.white : textColor;

    return RepaintBoundary(
      child: Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: Column(
          crossAxisAlignment: isMe
              ? CrossAxisAlignment.end
              : CrossAxisAlignment.start,
          children: [
            // Sender name label (only for received messages)
            if (!isMe && senderName != null)
              Padding(
                padding: const EdgeInsets.only(left: 4, bottom: 4),
                child: Text(
                  senderName!,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 11,
                    fontWeight: FontWeight.w600,
                    color: textColor.withValues(alpha: 0.5),
                  ),
                ),
              ),
            // Bubble
            ConstrainedBox(
              constraints: BoxConstraints(maxWidth: maxBubbleWidth),
              child: ClayContainer(
                color: bubbleColor,
                borderRadius: 20,
                customBorderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(20),
                  topRight: const Radius.circular(20),
                  bottomLeft: Radius.circular(isMe ? 20 : 4),
                  bottomRight: Radius.circular(isMe ? 4 : 20),
                ),
                depth: 18,
                spread: 1,
                emboss: false,
                child: Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 10,
                  ),
                  child: Column(
                    crossAxisAlignment: isMe
                        ? CrossAxisAlignment.end
                        : CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (message.hasFile) ...[
                        if (message.isImage)
                          _buildImagePreview(context)
                        else
                          _buildFilePreview(context, bubbleTextColor),
                        if (message.message.isNotEmpty)
                          const SizedBox(height: 8),
                      ],
                      if (message.message.isNotEmpty &&
                          message.message != 'Shared a file')
                        Padding(
                          padding: const EdgeInsets.only(bottom: 4),
                          child: Text(
                            message.message,
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 15,
                              fontWeight: FontWeight.w500,
                              color: bubbleTextColor,
                              height: 1.4,
                            ),
                          ),
                        ),
                      const SizedBox(height: 2),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            _formatTime(message.timestamp),
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w500,
                              color: bubbleTextColor.withValues(alpha: 0.6),
                            ),
                          ),
                          if (isMe) ...[
                            const SizedBox(width: 4),
                            Icon(
                              message.isRead
                                  ? PhosphorIconsFill.checks
                                  : PhosphorIconsRegular.check,
                              size: 14,
                              color: bubbleTextColor.withValues(alpha: 0.8),
                            ),
                          ],
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildImagePreview(BuildContext context) {
    return GestureDetector(
      onTap: () => launchUrl(Uri.parse(message.fileUrl!)),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: CachedNetworkImage(
          imageUrl: message.fileUrl!,
          width: 220,
          fit: BoxFit.cover,
          memCacheWidth: 400,
          placeholder: (context, url) => Container(
            height: 180,
            width: 220,
            color: Colors.black12,
            child: const Center(
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
          ),
          errorWidget: (context, url, error) => Container(
            height: 80,
            width: 220,
            decoration: BoxDecoration(
              color: Colors.black12,
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Center(
              child: Icon(PhosphorIconsRegular.imageSquare, size: 32),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFilePreview(BuildContext context, Color color) {
    return GestureDetector(
      onTap: () => launchUrl(Uri.parse(message.fileUrl!)),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: 0.08),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(PhosphorIconsFill.fileText, size: 22, color: color),
            ),
            const SizedBox(width: 10),
            Flexible(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    message.fileName ?? 'Attachment',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 13,
                      color: color,
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    'Tap to open',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 11,
                      color: color.withValues(alpha: 0.6),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 6),
            Icon(
              PhosphorIconsRegular.arrowSquareOut,
              size: 16,
              color: color.withValues(alpha: 0.5),
            ),
          ],
        ),
      ),
    );
  }

  String _formatTime(DateTime time) {
    final hour = time.hour;
    final minute = time.minute.toString().padLeft(2, '0');
    final period = hour >= 12 ? 'PM' : 'AM';
    final displayHour = hour == 0 ? 12 : (hour > 12 ? hour - 12 : hour);
    return '$displayHour:$minute $period';
  }
}

// ─── Attachment Sheet ───
class _AttachmentSheet extends StatelessWidget {
  final VoidCallback onPickImage;
  final VoidCallback onPickCamera;
  final VoidCallback onPickDocument;

  const _AttachmentSheet({
    required this.onPickImage,
    required this.onPickCamera,
    required this.onPickDocument,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Container(
      height: 250,
      margin: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isDark ? const Color(0xFF1F2C34) : Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.2),
            blurRadius: 10,
            spreadRadius: 2,
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            margin: const EdgeInsets.only(top: 10, bottom: 20),
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.grey[400],
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _buildOption(
                icon: PhosphorIconsFill.fileText,
                color: Colors.purple,
                label: 'Document',
                onTap: onPickDocument,
                theme: theme,
              ),
              _buildOption(
                icon: PhosphorIconsFill.camera,
                color: Colors.pink,
                label: 'Camera',
                onTap: onPickCamera,
                theme: theme,
              ),
              _buildOption(
                icon: PhosphorIconsFill.image,
                color: Colors.purple,
                label: 'Gallery',
                onTap: onPickImage,
                theme: theme,
              ),
            ],
          ),
          const SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget _buildOption({
    required IconData icon,
    required Color color,
    required String label,
    required VoidCallback onTap,
    required ThemeData theme,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          CircleAvatar(
            radius: 30,
            backgroundColor: color,
            child: Icon(icon, color: Colors.white, size: 28),
          ),
          const SizedBox(height: 8),
          Text(
            label,
            style: theme.textTheme.bodyMedium?.copyWith(
              fontWeight: FontWeight.w500,
            ),
          ),
        ],
      ),
    );
  }
}
