import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:nes/core/theme/app_colors.dart';
import 'package:nes/core/widgets/clay_container.dart';
import 'package:nes/features/client/pages/payment_page.dart';
import 'package:nes/services/admin_api_service.dart';

class CreateRequestPage extends ConsumerStatefulWidget {
  const CreateRequestPage({super.key});

  @override
  ConsumerState<CreateRequestPage> createState() => _CreateRequestPageState();
}

class _CreateRequestPageState extends ConsumerState<CreateRequestPage> {
  final _formKey = GlobalKey<FormState>();
  final _descriptionController = TextEditingController();

  // ── Dynamic services fetched from backend ──
  List<String> _availableServices = [];
  bool _loadingServices = true;
  String? _servicesError;

  final Set<String> _selectedServices = {};
  DateTime? _selectedDeadline;

  final List<File> _selectedFiles = [];
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    _fetchServices();
  }

  /// Fetches active services from the backend so that any admin
  /// add / delete is immediately reflected here.
  Future<void> _fetchServices() async {
    setState(() {
      _loadingServices = true;
      _servicesError = null;
    });
    try {
      final result = await AdminApiService.getActiveServicePrices();
      if (!mounted) return;
      if (result['success'] == true) {
        final list = result['prices'] as List<dynamic>? ?? [];
        setState(() {
          _availableServices =
              list.map((e) => e['serviceName'] as String).toList();
          _loadingServices = false;
        });
      } else {
        setState(() {
          _servicesError = result['error'] ?? 'Failed to load services';
          _loadingServices = false;
        });
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _servicesError = 'Could not load services. Please try again.';
        _loadingServices = false;
      });
    }
  }

  @override
  void dispose() {
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _pickFiles() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        allowMultiple: true,
        type: FileType.custom,
        allowedExtensions: ['jpg', 'jpeg', 'png', 'pdf', 'doc', 'docx'],
      );

      if (result != null) {
        setState(() {
          _selectedFiles.addAll(result.paths.map((path) => File(path!)));
        });
      }
    } catch (e) {
      _showSnack('Error picking files: $e', isError: true);
    }
  }

  void _removeFile(int index) {
    setState(() {
      _selectedFiles.removeAt(index);
    });
  }

  Future<void> _selectDeadline() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now().add(const Duration(days: 7)),
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      builder: (context, child) {
        final theme = Theme.of(context);
        return Theme(
          data: theme.copyWith(
            colorScheme: theme.colorScheme.copyWith(
              primary: AppColors.primary,
              onPrimary: Colors.white,
              surface: theme.cardColor,
            ),
          ),
          child: child!,
        );
      },
    );

    if (picked != null) {
      setState(() {
        _selectedDeadline = picked;
      });
    }
  }

  Future<void> _proceedToPayment() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedServices.isEmpty) {
      _showSnack('Please select at least one service', isError: true);
      return;
    }

    setState(() => _isSubmitting = true);
    try {
      final result = await Navigator.push<bool>(
        context,
        MaterialPageRoute(
          builder: (_) => PaymentPage(
            selectedServices: _selectedServices.toList(),
            description: _descriptionController.text.trim(),
            deadline: _selectedDeadline,
            selectedFiles: List.from(_selectedFiles),
          ),
        ),
      );

      if (result == true && mounted) {
        Navigator.pop(context, true);
      }
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  void _showSnack(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: GoogleFonts.plusJakartaSans(color: Colors.white),
        ),
        backgroundColor: isError ? AppColors.error : AppColors.success,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }

  /// Gradient divider
  Widget _buildDivider(Color dividerColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 22),
      child: Container(
        height: 1,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              dividerColor.withValues(alpha: 0),
              dividerColor,
              dividerColor,
              dividerColor.withValues(alpha: 0),
            ],
            stops: const [0.0, 0.2, 0.8, 1.0],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    final baseColor = isDark
        ? const Color(0xFF2D2D2D)
        : const Color(0xFFDEE4EA);
    final textColor = isDark ? Colors.white70 : const Color(0xFF485057);
    final dividerColor = isDark
        ? Colors.white.withValues(alpha: 0.06)
        : Colors.black.withValues(alpha: 0.06);

    return Scaffold(
      backgroundColor: baseColor,
      body: SafeArea(
        child: Column(
          children: [
            // ── Header ──
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: Row(
                children: [
                  ClayContainer(
                    color: baseColor,
                    borderRadius: 22,
                    depth: 20,
                    spread: 1,
                    width: 44,
                    height: 44,
                    child: IconButton(
                      icon: Icon(
                        PhosphorIconsRegular.caretLeft,
                        size: 22,
                        color: textColor,
                      ),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Text(
                    'New Request',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                      color: textColor,
                      letterSpacing: -0.5,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // ── Form Body ──
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 40),
                physics: const BouncingScrollPhysics(),
                child: Form(
                  key: _formKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ── Select Services ──
                      _buildSectionTitle(
                        'Select Services',
                        PhosphorIconsRegular.briefcase,
                        textColor,
                        theme,
                      ),
                      const SizedBox(height: 14),
                      _buildServiceGrid(theme, isDark, baseColor, textColor),

                      _buildDivider(dividerColor),

                      // ── Project Details ──
                      _buildSectionTitle(
                        'Project Details',
                        PhosphorIconsRegular.textAlignLeft,
                        textColor,
                        theme,
                      ),
                      const SizedBox(height: 14),

                      ClayContainer(
                        color: baseColor,
                        depth: -10,
                        spread: 1,
                        borderRadius: 20,
                        emboss: true,
                        child: TextFormField(
                          controller: _descriptionController,
                          maxLines: 6,
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 14,
                            color: textColor,
                          ),
                          decoration: InputDecoration(
                            hintText:
                                'Describe your project requirements, goals, and any specific features...',
                            hintStyle: GoogleFonts.plusJakartaSans(
                              fontSize: 14,
                              color: textColor.withValues(alpha: 0.35),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(20),
                              borderSide: BorderSide.none,
                            ),
                            contentPadding: const EdgeInsets.all(18),
                            filled: true,
                            fillColor: Colors.transparent,
                          ),
                          validator: (value) {
                            if (value == null || value.trim().length < 20) {
                              return 'Please provide at least 20 characters';
                            }
                            return null;
                          },
                        ),
                      ),

                      _buildDivider(dividerColor),

                      // ── Attachments & Deadline ──
                      _buildSectionTitle(
                        'Attachments & Deadline',
                        PhosphorIconsRegular.calendarBlank,
                        textColor,
                        theme,
                      ),
                      const SizedBox(height: 14),

                      Row(
                        children: [
                          Expanded(
                            child: _buildActionButton(
                              baseColor,
                              textColor,
                              theme,
                              icon: PhosphorIconsRegular.paperclip,
                              label: 'Add Files',
                              onTap: _pickFiles,
                              isActive: _selectedFiles.isNotEmpty,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _buildActionButton(
                              baseColor,
                              textColor,
                              theme,
                              icon: PhosphorIconsRegular.calendarCheck,
                              label: _selectedDeadline == null
                                  ? 'Set Deadline'
                                  : '${_selectedDeadline!.day}/${_selectedDeadline!.month}',
                              onTap: _selectDeadline,
                              isActive: _selectedDeadline != null,
                            ),
                          ),
                        ],
                      ),

                      // ── File List ──
                      if (_selectedFiles.isNotEmpty) ...[
                        const SizedBox(height: 16),
                        ..._selectedFiles.asMap().entries.map((entry) {
                          final index = entry.key;
                          final file = entry.value;
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: ClayContainer(
                              color: baseColor,
                              depth: 10,
                              borderRadius: 16,
                              spread: 1,
                              padding: const EdgeInsets.symmetric(
                                horizontal: 14,
                                vertical: 12,
                              ),
                              child: Row(
                                children: [
                                  ClayContainer(
                                    color: baseColor,
                                    borderRadius: 12,
                                    depth: -8,
                                    spread: 0,
                                    emboss: true,
                                    width: 40,
                                    height: 40,
                                    child: Icon(
                                      PhosphorIconsRegular.file,
                                      size: 20,
                                      color: theme.colorScheme.primary,
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Text(
                                      file.path
                                          .split(Platform.pathSeparator)
                                          .last,
                                      style: GoogleFonts.plusJakartaSans(
                                        fontWeight: FontWeight.w600,
                                        fontSize: 13,
                                        color: textColor,
                                      ),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                  GestureDetector(
                                    onTap: () => _removeFile(index),
                                    child: Icon(
                                      PhosphorIconsRegular.x,
                                      size: 18,
                                      color: Colors.redAccent,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        }),
                      ],

                      const SizedBox(height: 32),

                      // ── Submit Button ──
                      GestureDetector(
                        onTap: _isSubmitting ? null : _proceedToPayment,
                        child: ClayContainer(
                          color: baseColor,
                          borderRadius: 22,
                          depth: 25,
                          spread: 2,
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.symmetric(vertical: 18),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  theme.colorScheme.primary,
                                  theme.colorScheme.primary.withValues(
                                    alpha: 0.8,
                                  ),
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(22),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                const Icon(
                                  PhosphorIconsRegular.creditCard,
                                  color: Colors.white,
                                  size: 20,
                                ),
                                const SizedBox(width: 10),
                                Text(
                                  'Proceed to Payment',
                                  style: GoogleFonts.plusJakartaSans(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                    color: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(
    String title,
    IconData icon,
    Color textColor,
    ThemeData theme,
  ) {
    return Row(
      children: [
        Icon(
          icon,
          size: 18,
          color: theme.colorScheme.primary.withValues(alpha: 0.7),
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: textColor,
            letterSpacing: -0.3,
          ),
        ),
      ],
    );
  }

  Widget _buildServiceGrid(
    ThemeData theme,
    bool isDark,
    Color baseColor,
    Color textColor,
  ) {
    // ── Loading state ──
    if (_loadingServices) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 24),
          child: CircularProgressIndicator(
            color: theme.colorScheme.primary,
            strokeWidth: 2.5,
          ),
        ),
      );
    }

    // ── Error state ──
    if (_servicesError != null) {
      return ClayContainer(
        color: baseColor,
        depth: 10,
        borderRadius: 16,
        spread: 1,
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Icon(
              PhosphorIconsRegular.warning,
              color: AppColors.error,
              size: 28,
            ),
            const SizedBox(height: 8),
            Text(
              _servicesError!,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 13,
                color: textColor.withValues(alpha: 0.7),
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 12),
            GestureDetector(
              onTap: _fetchServices,
              child: Text(
                'Tap to retry',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: theme.colorScheme.primary,
                ),
              ),
            ),
          ],
        ),
      );
    }

    // ── Empty state (no active services) ──
    if (_availableServices.isEmpty) {
      return ClayContainer(
        color: baseColor,
        depth: 10,
        borderRadius: 16,
        spread: 1,
        padding: const EdgeInsets.symmetric(vertical: 24),
        child: Center(
          child: Text(
            'No services available at the moment.',
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13,
              color: textColor.withValues(alpha: 0.5),
            ),
          ),
        ),
      );
    }

    // ── Loaded services ──
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: _availableServices.map((service) {
        final isSelected = _selectedServices.contains(service);
        return GestureDetector(
          onTap: () {
            setState(() {
              if (isSelected) {
                _selectedServices.remove(service);
              } else {
                _selectedServices.add(service);
              }
            });
          },
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            child: ClayContainer(
              color: isSelected ? theme.colorScheme.primary : baseColor,
              borderRadius: 14,
              depth: isSelected ? 15 : 10,
              spread: 1,
              padding:
                  const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
              child: Text(
                service,
                style: GoogleFonts.plusJakartaSans(
                  fontWeight:
                      isSelected ? FontWeight.w700 : FontWeight.w500,
                  color: isSelected ? Colors.white : textColor,
                  fontSize: 13,
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildActionButton(
    Color baseColor,
    Color textColor,
    ThemeData theme, {
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    required bool isActive,
  }) {
    return GestureDetector(
      onTap: onTap,
      child: ClayContainer(
        color: baseColor,
        depth: isActive ? 18 : 12,
        spread: 1,
        borderRadius: 18,
        padding: const EdgeInsets.symmetric(vertical: 18),
        child: Column(
          children: [
            Icon(
              icon,
              color: isActive
                  ? theme.colorScheme.primary
                  : textColor.withValues(alpha: 0.5),
              size: 26,
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: GoogleFonts.plusJakartaSans(
                fontWeight: FontWeight.w600,
                fontSize: 13,
                color: isActive
                    ? theme.colorScheme.primary
                    : textColor.withValues(alpha: 0.5),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
