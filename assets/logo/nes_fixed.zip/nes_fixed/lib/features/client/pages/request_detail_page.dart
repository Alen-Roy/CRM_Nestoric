import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:nes/core/widgets/clay_container.dart';
import 'package:nes/core/widgets/clay_icon.dart';
import 'package:nes/features/client/model/client_model.dart';
import 'package:nes/features/client/pages/client_chat_page.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';
import 'package:nes/services/client_api_service.dart';

class RequestDetailPage extends ConsumerStatefulWidget {
  final ClientRequest request;

  const RequestDetailPage({super.key, required this.request});

  @override
  ConsumerState<RequestDetailPage> createState() => _RequestDetailPageState();
}

class _RequestDetailPageState extends ConsumerState<RequestDetailPage> {
  late ClientRequest currentRequest;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    currentRequest = widget.request;
  }

  Future<void> _deleteRequest() async {
    final theme = Theme.of(context);
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Text(
          'Delete Request',
          style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w800),
        ),
        content: const Text('Are you sure you want to delete this request?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(
              foregroundColor: theme.colorScheme.error,
            ),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    setState(() => isLoading = true);

    final token = ref.read(authProvider).token;
    if (token == null) return;

    final result = await ClientApiService.deleteRequest(
      token: token,
      requestId: currentRequest.id,
    );

    if (mounted) {
      setState(() => isLoading = false);

      if (result['success']) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Request deleted successfully',
              style: GoogleFonts.plusJakartaSans(color: Colors.white),
            ),
            backgroundColor: Colors.green,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
          ),
        );
        Navigator.pop(context, true);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(result['error'] ?? 'Failed to delete request'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  /// Gradient divider
  Widget _buildDivider(Color dividerColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 20),
      child: Container(
        height: 1,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              dividerColor.withValues(alpha: 0),
              dividerColor,
              dividerColor,
              dividerColor.withValues(alpha: 0),
            ],
            stops: const [0.0, 0.2, 0.8, 1.0],
          ),
        ),
      ),
    );
  }

  /// Section header with icon
  Widget _buildSectionHeader(
    String title,
    IconData icon,
    Color textColor,
    ThemeData theme,
  ) {
    return Row(
      children: [
        ClayIcon(
          icon: icon,
          size: 18,
          color: theme.colorScheme.primary.withValues(alpha: 0.7),
          baseColor: Theme.of(context).brightness == Brightness.dark
              ? const Color(0xFF2D2D2D)
              : const Color(0xFFDEE4EA),
          depth: 10,
          spread: 1,
          borderRadius: 12,
          padding: const EdgeInsets.all(8),
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: textColor,
            letterSpacing: -0.3,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    final baseColor = isDark
        ? const Color(0xFF2D2D2D)
        : const Color(0xFFDEE4EA);
    final textColor = isDark ? Colors.white70 : const Color(0xFF485057);
    final dividerColor = isDark
        ? Colors.white.withValues(alpha: 0.06)
        : Colors.black.withValues(alpha: 0.06);

    final statusColor = _getStatusColor(currentRequest.status);
    final statusIcon = _getStatusIcon(currentRequest.status);

    return Scaffold(
      backgroundColor: baseColor,
      body: SafeArea(
        bottom: false,
        child: isLoading
            ? const Center(child: CircularProgressIndicator())
            : Column(
                children: [
                  // ── Header ──
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                    child: Row(
                      children: [
                        ClayIcon(
                          icon: PhosphorIconsRegular.caretLeft,
                          size: 22,
                          color: textColor,
                          baseColor: baseColor,
                          borderRadius: 22,
                          depth: 20,
                          spread: 1,
                          padding: const EdgeInsets.all(11),
                          onTap: () => Navigator.pop(context),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Text(
                            'Request Details',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 24,
                              fontWeight: FontWeight.w800,
                              color: textColor,
                              letterSpacing: -0.5,
                            ),
                          ),
                        ),
                        if (currentRequest.status == 'pending')
                          ClayIcon(
                            icon: PhosphorIconsRegular.trash,
                            size: 20,
                            color: Colors.redAccent,
                            baseColor: baseColor,
                            borderRadius: 22,
                            depth: 20,
                            spread: 1,
                            padding: const EdgeInsets.all(12),
                            onTap: _deleteRequest,
                          ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),

                  // ── Content ──
                  Expanded(
                    child: ListView(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(20, 0, 20, 120),
                      children: [
                        // ── Status Card ──
                        ClayContainer(
                          color: baseColor,
                          borderRadius: 24,
                          depth: 20,
                          spread: 2,
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(24),
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  statusColor,
                                  statusColor.withValues(alpha: 0.7),
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              borderRadius: BorderRadius.circular(24),
                            ),
                            child: Column(
                              children: [
                                ClayIcon(
                                  icon: statusIcon,
                                  size: 52,
                                  color: Colors.white,
                                  baseColor:
                                      statusColor, // Base color is same as background to make it look embossed/debossed on the card?
                                  // The card has a gradient. ClayContainer doesn't support gradient baseColor easily except via `color`.
                                  // But `ClayIcon` wraps `ClayContainer`.
                                  // If I use `statusColor`, it might look okay.
                                  // Or I can make it behave like a "cutout" or "stamped" icon.
                                  depth: -20, // Embossed
                                  spread: 1,
                                  borderRadius: 50,
                                  padding: const EdgeInsets.all(16),
                                ),
                                const SizedBox(height: 12),
                                Text(
                                  currentRequest.status[0].toUpperCase() +
                                      currentRequest.status
                                          .substring(1)
                                          .replaceAll('_', ' '),
                                  style: GoogleFonts.plusJakartaSans(
                                    fontSize: 24,
                                    fontWeight: FontWeight.w800,
                                    color: Colors.white,
                                  ),
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  'Request #${currentRequest.id.substring(currentRequest.id.length - 6).toUpperCase()}',
                                  style: GoogleFonts.plusJakartaSans(
                                    fontSize: 13,
                                    color: Colors.white.withValues(alpha: 0.8),
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        _buildDivider(dividerColor),

                        // ── Services ──
                        _buildSectionHeader(
                          'Services Requested',
                          PhosphorIconsRegular.briefcase,
                          textColor,
                          theme,
                        ),
                        const SizedBox(height: 14),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: currentRequest.services.map((service) {
                            return ClayContainer(
                              color: baseColor,
                              borderRadius: 14,
                              depth: 12,
                              spread: 1,
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 10,
                              ),
                              child: Text(
                                service,
                                style: GoogleFonts.plusJakartaSans(
                                  color: theme.colorScheme.primary,
                                  fontWeight: FontWeight.w700,
                                  fontSize: 13,
                                ),
                              ),
                            );
                          }).toList(),
                        ),

                        _buildDivider(dividerColor),

                        // ── Description ──
                        _buildSectionHeader(
                          'Description',
                          PhosphorIconsRegular.textAlignLeft,
                          textColor,
                          theme,
                        ),
                        const SizedBox(height: 14),
                        ClayContainer(
                          color: baseColor,
                          borderRadius: 18,
                          depth: -10,
                          spread: 1,
                          emboss: true,
                          padding: const EdgeInsets.all(18),
                          child: Text(
                            currentRequest.description,
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 14,
                              color: textColor,
                              height: 1.6,
                            ),
                          ),
                        ),

                        // ── Assigned Worker ──
                        if (currentRequest.assignedWorkerName != null) ...[
                          _buildDivider(dividerColor),
                          _buildSectionHeader(
                            'Assigned Worker',
                            PhosphorIconsRegular.user,
                            textColor,
                            theme,
                          ),
                          const SizedBox(height: 14),
                          ClayContainer(
                            color: baseColor,
                            borderRadius: 20,
                            depth: 15,
                            spread: 1,
                            padding: const EdgeInsets.all(16),
                            child: Row(
                              children: [
                                ClayContainer(
                                  color: baseColor,
                                  borderRadius: 28,
                                  depth: 12,
                                  spread: 1,
                                  width: 56,
                                  height: 56,
                                  child: Container(
                                    decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: [
                                          theme.colorScheme.primary,
                                          theme.colorScheme.primary.withValues(
                                            alpha: 0.7,
                                          ),
                                        ],
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                      ),
                                      shape: BoxShape.circle,
                                    ),
                                    child:
                                        currentRequest.assignedWorkerAvatar !=
                                            null
                                        ? ClipOval(
                                            child: Image.network(
                                              currentRequest
                                                  .assignedWorkerAvatar!,
                                              fit: BoxFit.cover,
                                              width: 56,
                                              height: 56,
                                              errorBuilder: (_, __, ___) =>
                                                  const Icon(
                                                    PhosphorIconsFill.user,
                                                    color: Colors.white,
                                                    size: 26,
                                                  ),
                                            ),
                                          )
                                        : const Icon(
                                            PhosphorIconsFill.user,
                                            color: Colors.white,
                                            size: 26,
                                          ),
                                  ),
                                ),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        currentRequest.assignedWorkerName!,
                                        style: GoogleFonts.plusJakartaSans(
                                          fontWeight: FontWeight.w700,
                                          fontSize: 16,
                                          color: textColor,
                                        ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        'Working on your request',
                                        style: GoogleFonts.plusJakartaSans(
                                          fontSize: 13,
                                          color: textColor.withValues(
                                            alpha: 0.5,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                ClayIcon(
                                  icon: PhosphorIconsFill.sealCheck,
                                  size: 26,
                                  color: theme.colorScheme.primary,
                                  baseColor: baseColor,
                                  depth: 5,
                                  spread: 0,
                                  borderRadius: 50,
                                  padding: const EdgeInsets.all(4),
                                ),
                              ],
                            ),
                          ),
                        ],

                        _buildDivider(dividerColor),

                        // ── Timeline ──
                        _buildSectionHeader(
                          'Timeline',
                          PhosphorIconsRegular.clockCounterClockwise,
                          textColor,
                          theme,
                        ),
                        const SizedBox(height: 16),
                        _buildTimelineItem(
                          'Request Created',
                          _formatDate(currentRequest.createdAt),
                          PhosphorIconsFill.plusCircle,
                          Colors.blue,
                          true,
                          baseColor,
                          textColor,
                        ),
                        if (currentRequest.status != 'pending')
                          _buildTimelineItem(
                            'Assigned to Worker',
                            currentRequest.assignedWorkerName ?? 'Worker',
                            PhosphorIconsFill.clipboardText,
                            Colors.orange,
                            true,
                            baseColor,
                            textColor,
                          ),
                        if (currentRequest.status == 'in_progress' ||
                            currentRequest.status == 'completed')
                          _buildTimelineItem(
                            'Work in Progress',
                            'Being worked on',
                            PhosphorIconsFill.trendUp,
                            Colors.purple,
                            true,
                            baseColor,
                            textColor,
                          ),
                        if (currentRequest.status == 'completed')
                          _buildTimelineItem(
                            'Completed',
                            'Request finished',
                            PhosphorIconsFill.checkCircle,
                            Colors.green,
                            true,
                            baseColor,
                            textColor,
                          )
                        else
                          _buildTimelineItem(
                            'Pending Completion',
                            'Waiting...',
                            PhosphorIconsFill.hourglass,
                            Colors.grey,
                            false,
                            baseColor,
                            textColor,
                          ),
                      ],
                    ),
                  ),
                ],
              ),
      ),

      // ── Bottom "Message Worker" Button ──
      bottomNavigationBar: currentRequest.assignedWorkerId != null
          ? SafeArea(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => ClientChatPage(
                          requestId: currentRequest.id,
                          workerName:
                              currentRequest.assignedWorkerName ?? 'Worker',
                          workerAvatar:
                              currentRequest.assignedWorkerAvatar ?? '',
                        ),
                      ),
                    );
                  },
                  child: ClayContainer(
                    color: baseColor,
                    borderRadius: 22,
                    depth: 25,
                    spread: 2,
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            theme.colorScheme.primary,
                            theme.colorScheme.primary.withValues(alpha: 0.8),
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(22),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            PhosphorIconsFill.chatCircle,
                            color: Colors.white,
                            size: 22,
                          ),
                          const SizedBox(width: 10),
                          Text(
                            'Message Worker',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              color: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            )
          : null,
    );
  }

  Widget _buildTimelineItem(
    String title,
    String subtitle,
    IconData icon,
    Color color,
    bool isCompleted,
    Color baseColor,
    Color textColor,
  ) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Row(
        children: [
          ClayIcon(
            icon: icon,
            color: isCompleted ? Colors.white : color.withValues(alpha: 0.4),
            size: 20,
            baseColor: isCompleted ? color : baseColor,
            borderRadius: 20,
            depth: isCompleted ? 12 : -8,
            spread: 1,
            emboss: !isCompleted,
            padding: const EdgeInsets.all(12),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: isCompleted
                        ? textColor
                        : textColor.withValues(alpha: 0.4),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  subtitle,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 13,
                    color: textColor.withValues(alpha: 0.45),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'pending':
        return Colors.orange;
      case 'assigned':
        return Colors.blue;
      case 'in_progress':
        return Colors.purple;
      case 'completed':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status) {
      case 'pending':
        return PhosphorIconsFill.clock;
      case 'assigned':
        return PhosphorIconsFill.clipboardText;
      case 'in_progress':
        return PhosphorIconsFill.trendUp;
      case 'completed':
        return PhosphorIconsFill.checkCircle;
      default:
        return PhosphorIconsFill.info;
    }
  }

  String _formatDate(DateTime date) {
    return '${date.day}/${date.month}/${date.year} at ${date.hour}:${date.minute.toString().padLeft(2, '0')}';
  }
}
