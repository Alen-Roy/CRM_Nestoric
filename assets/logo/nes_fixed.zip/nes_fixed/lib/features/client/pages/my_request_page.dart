import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:nes/core/animations/page_transitions.dart';
import 'package:nes/core/animations/stagger_animation.dart';
import 'package:nes/core/animations/tap_bounce.dart';
import 'package:nes/core/widgets/clay_container.dart';
import 'package:nes/features/client/model/client_model.dart';
import 'package:nes/features/client/pages/request_detail_page.dart';
import 'package:nes/features/client/pages/create_request_page.dart';
import 'package:nes/core/widgets/breathing_widget.dart';
import 'package:nes/core/widgets/clay_icon.dart';
import 'package:nes/features/client/providers/client_providers.dart';

class MyRequestsPage extends ConsumerStatefulWidget {
  const MyRequestsPage({super.key});

  @override
  ConsumerState<MyRequestsPage> createState() => _MyRequestsPageState();
}

class _MyRequestsPageState extends ConsumerState<MyRequestsPage>
    with TickerProviderStateMixin {
  String selectedFilter = 'all';
  late AnimationController _staggerController;
  late AnimationController _fabController;

  @override
  void initState() {
    super.initState();
    _staggerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fabController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    // Trigger animations immediately
    _staggerController.forward();
    _fabController.forward();
  }

  @override
  void dispose() {
    _staggerController.dispose();
    _fabController.dispose();
    super.dispose();
  }

  List<ClientRequest> _getFilteredRequests(List<ClientRequest> allRequests) {
    if (selectedFilter == 'all') return allRequests;
    return allRequests.where((r) => r.status == selectedFilter).toList();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final requestsAsync = ref.watch(myRequestsProvider);

    final baseColor = isDark
        ? const Color(0xFF2D2D2D)
        : const Color(0xFFDEE4EA);

    final textColor = isDark ? Colors.white70 : const Color(0xFF485057);

    return Scaffold(
      backgroundColor: baseColor,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Header ──
            StaggeredFadeSlide(
              index: 0,
              controller: _staggerController,
              totalItems: 6,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        'My Requests',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 28,
                          fontWeight: FontWeight.w900,
                          color: textColor,
                          letterSpacing: -0.5,
                        ),
                      ),
                    ),
                    ClayIcon(
                      icon: PhosphorIconsRegular.arrowClockwise,
                      size: 22,
                      color: textColor,
                      baseColor: baseColor,
                      borderRadius: 22,
                      depth: 20,
                      spread: 1,
                      padding: const EdgeInsets.all(11),
                      onTap: () => ref.refresh(myRequestsProvider),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // ── Filter Chips (Clay) ──
            StaggeredFadeSlide(
              index: 1,
              controller: _staggerController,
              totalItems: 6,
              child: _buildFilterChips(baseColor, textColor, theme),
            ),
            const SizedBox(height: 16),

            // ── Requests List ──
            Expanded(
              child: requestsAsync.when(
                data: (allRequests) {
                  final filteredRequests = _getFilteredRequests(allRequests);

                  if (filteredRequests.isEmpty) {
                    return _buildEmptyState(baseColor, textColor, theme);
                  }

                  return ListView.separated(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
                    itemCount: filteredRequests.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 14),
                    itemBuilder: (context, index) {
                      return StaggeredFadeSlide(
                        index: 2 + index,
                        controller: _staggerController,
                        totalItems: 6 + filteredRequests.length,
                        child: TapBounce(
                          onTap: () {
                            Navigator.push(
                              context,
                              SmoothPageRoute(
                                page: RequestDetailPage(
                                  request: filteredRequests[index],
                                ),
                              ),
                            );
                            // No need to reload manually, provider handles it if invalidated elsewhere
                          },
                          child: _buildRequestCard(
                            filteredRequests[index],
                            baseColor,
                            textColor,
                            theme,
                          ),
                        ),
                      );
                    },
                  );
                },
                error: (error, stack) => Center(child: Text('Error: $error')),
                loading: () => const Center(child: CircularProgressIndicator()),
              ),
            ),
          ],
        ),
      ),
      // ── FAB (Clay styled button) ──
      floatingActionButton: ScaleTransition(
        scale: CurvedAnimation(
          parent: _fabController,
          curve: Curves.elasticOut,
        ),
        child: GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              SmoothPageRoute(page: const CreateRequestPage()),
            );
            // No need to reload manually
          },
          child: ClayContainer(
            color: baseColor,
            borderRadius: 24,
            depth: 30,
            spread: 2,
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                ClayIcon(
                  icon: PhosphorIconsFill.plus,
                  color: isDark ? Colors.white : theme.colorScheme.primary,
                  size: 22,
                  baseColor: baseColor,
                  depth: -5, // Embossed for subtle effect inside FAB
                  spread: 0,
                  borderRadius: 20,
                  padding: const EdgeInsets.all(4),
                ),
                const SizedBox(width: 10),
                Text(
                  'New Request',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: isDark ? Colors.white : theme.colorScheme.primary,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFilterChips(Color baseColor, Color textColor, ThemeData theme) {
    final filters = [
      {'value': 'all', 'label': 'All', 'icon': PhosphorIconsFill.listBullets},
      {'value': 'pending', 'label': 'Pending', 'icon': PhosphorIconsFill.clock},
      {
        'value': 'assigned',
        'label': 'Assigned',
        'icon': PhosphorIconsFill.clipboardText,
      },
      {
        'value': 'in_progress',
        'label': 'In Progress',
        'icon': PhosphorIconsFill.trendUp,
      },
      {
        'value': 'completed',
        'label': 'Completed',
        'icon': PhosphorIconsFill.checkCircle,
      },
    ];

    return SizedBox(
      height: 50,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 20),
        itemCount: filters.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (context, index) {
          final filter = filters[index];
          final isSelected = selectedFilter == filter['value'];

          return GestureDetector(
            onTap: () {
              setState(() {
                selectedFilter = filter['value'] as String;
              });
            },
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOutCubic,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: isSelected
                    ? theme.colorScheme.primary
                    : Colors.transparent,
                borderRadius: BorderRadius.circular(16),
                boxShadow: isSelected
                    ? [
                        BoxShadow(
                          color: theme.colorScheme.primary.withValues(
                            alpha: 0.3,
                          ),
                          blurRadius: 8,
                          offset: const Offset(0, 3),
                        ),
                      ]
                    : null,
                border: isSelected
                    ? null
                    : Border.all(
                        color: textColor.withValues(alpha: 0.15),
                        width: 1,
                      ),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ClayIcon(
                    icon: filter['icon'] as IconData,
                    size: 16,
                    color: isSelected
                        ? Colors.white
                        : textColor.withValues(alpha: 0.6),
                    baseColor: isSelected
                        ? theme.colorScheme.primary
                        : Colors
                              .transparent, // Transparent base might look weird with clay, but let's try.
                    // Actually if baseColor is transparent, ClayContainer allows it but shadow might look off.
                    // If not selected, it's transparent background.
                    // Maybe we only use ClayIcon if selected?
                    // Or we just use ClayIcon with baseColor same as parent container.
                    // Parent container is AnimatedContainer.
                    // Let's use `baseColor` from context.
                    // But the parent container changes color.
                    // If not selected, baseColor should be the scaffold baseColor? No, because it's inside an AnimatedContainer which is transparent.
                    // So it's on top of Scaffold.
                    // Let's keep it simple: If selected, use ClayIcon with emboss/depth. If not, maybe just Icon?
                    // User said "every icon".
                    // Let's try to make it ClayIcon always.
                    depth: isSelected ? -5 : 5,
                    spread: 0,
                    borderRadius: 50,
                    padding: const EdgeInsets.all(4),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    filter['label'] as String,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 13,
                      fontWeight: isSelected
                          ? FontWeight.w700
                          : FontWeight.w600,
                      color: isSelected
                          ? Colors.white
                          : textColor.withValues(alpha: 0.7),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildRequestCard(
    ClientRequest request,
    Color baseColor,
    Color textColor,
    ThemeData theme,
  ) {
    final statusColor = _getStatusColor(request.status);
    final statusIcon = _getStatusIcon(request.status);

    return ClayContainer(
      color: baseColor,
      borderRadius: 20,
      depth: 15,
      spread: 1,
      padding: const EdgeInsets.all(18),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              // Status dot
              Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  color: statusColor,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: statusColor.withValues(alpha: 0.4),
                      blurRadius: 6,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  request.services.join(', '),
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: textColor,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: statusColor.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    ClayIcon(
                      icon: statusIcon,
                      size: 13,
                      color: statusColor,
                      baseColor: statusColor.withValues(alpha: 0.12),
                      depth: 3,
                      spread: 0,
                      borderRadius: 10,
                      padding: const EdgeInsets.all(3),
                    ),
                    const SizedBox(width: 4),
                    Text(
                      request.status[0].toUpperCase() +
                          request.status.substring(1).replaceAll('_', ' '),
                      style: GoogleFonts.plusJakartaSans(
                        color: statusColor,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            request.description,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 14,
              color: textColor.withValues(alpha: 0.6),
              height: 1.4,
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              ClayIcon(
                icon: PhosphorIconsRegular.calendarBlank,
                size: 14,
                color: textColor.withValues(alpha: 0.5),
                baseColor: baseColor,
                depth: 5,
                spread: 0,
                borderRadius: 8,
                padding: const EdgeInsets.all(4),
              ),
              const SizedBox(width: 6),
              Text(
                _formatDate(request.createdAt),
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 12,
                  color: textColor.withValues(alpha: 0.5),
                ),
              ),
              if (request.assignedWorkerName != null) ...[
                const Spacer(),
                ClayIcon(
                  icon: PhosphorIconsFill.user,
                  size: 14,
                  color: theme.colorScheme.primary,
                  baseColor: baseColor,
                  depth: 5,
                  spread: 0,
                  borderRadius: 100, // Circular
                  padding: const EdgeInsets.all(4),
                ),
                const SizedBox(width: 6),
                Text(
                  request.assignedWorkerName!,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12,
                    color: theme.colorScheme.primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState(Color baseColor, Color textColor, ThemeData theme) {
    return Center(
      child: ClayContainer(
        color: baseColor,
        borderRadius: 24,
        depth: 20,
        spread: 1,
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            BreathingWidget(
              duration: const Duration(seconds: 4),
              scaleEnd: 1.05,
              child: SizedBox(
                height: 120,
                width: 120,
                child: Image.asset(
                  'assets/images/boy_empty.png',
                  fit: BoxFit.contain,
                  errorBuilder: (context, error, stackTrace) {
                    return ClayIcon(
                      icon: PhosphorIconsRegular.tray,
                      size: 64,
                      color: textColor.withValues(alpha: 0.3),
                      baseColor: baseColor,
                      depth: -10,
                      spread: 1,
                      borderRadius: 60,
                      padding: const EdgeInsets.all(28),
                    );
                  },
                ),
              ),
            ),
            const SizedBox(height: 16),
            Text(
              selectedFilter == 'all'
                  ? 'No requests yet'
                  : 'No ${selectedFilter.replaceAll('_', ' ')} requests',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: textColor.withValues(alpha: 0.6),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Create your first request to get started',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 13,
                color: textColor.withValues(alpha: 0.4),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'pending':
        return Colors.orange;
      case 'assigned':
        return Colors.blue;
      case 'in_progress':
        return Colors.purple;
      case 'completed':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status) {
      case 'pending':
        return PhosphorIconsFill.clock;
      case 'assigned':
        return PhosphorIconsFill.clipboardText;
      case 'in_progress':
        return PhosphorIconsFill.trendUp;
      case 'completed':
        return PhosphorIconsFill.checkCircle;
      default:
        return PhosphorIconsFill.info;
    }
  }

  String _formatDate(DateTime date) {
    final now = DateTime.now();
    final difference = now.difference(date);

    if (difference.inDays == 0) {
      return 'Today';
    } else if (difference.inDays == 1) {
      return 'Yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }
}
