import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:nes/core/animations/page_transitions.dart';
import 'package:nes/core/animations/stagger_animation.dart';
import 'package:nes/core/animations/tap_bounce.dart';
import 'package:nes/core/widgets/clay_container.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';
import 'package:nes/core/providers/theme_provider.dart';
import 'package:nes/features/client/model/client_model.dart';
import 'package:nes/features/client/model/service_data.dart';
import 'package:nes/features/client/model/service_item.dart';
import 'package:nes/core/widgets/breathing_widget.dart';
import 'package:nes/core/widgets/clay_icon.dart';
import 'package:nes/features/client/providers/client_providers.dart';
import 'package:nes/features/client/pages/create_request_page.dart';
import 'package:nes/features/client/pages/my_request_page.dart';
import 'package:nes/features/client/widgets/client_main_layout.dart';

class ClientDashboard extends ConsumerStatefulWidget {
  const ClientDashboard({super.key});

  @override
  ConsumerState<ClientDashboard> createState() => _ClientDashboardState();
}

class _ClientDashboardState extends ConsumerState<ClientDashboard>
    with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late Animation<double> _fadeAnim;
  late AnimationController _staggerController;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _fadeAnim = CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);
    _staggerController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );

    // Trigger animations immediately
    _fadeController.forward();
    _staggerController.forward();
  }

  @override
  void dispose() {
    _staggerController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final user = ref.watch(currentUserProvider);
    final isDark = theme.brightness == Brightness.dark;
    final bottomNavHeight = 72 + 12 + MediaQuery.of(context).padding.bottom;
    ref.watch(themeModeProvider); // Watch theme mode for changes

    final statsAsync = ref.watch(clientStatsProvider);
    final requestsAsync = ref.watch(myRequestsProvider);

    // Animate between 0.0 (light) and 1.0 (dark)
    final targetValue = isDark ? 1.0 : 0.0;

    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: targetValue, end: targetValue),
      duration: const Duration(milliseconds: 400),
      curve: Curves.easeInOutCubic,
      builder: (context, value, child) {
        // Interpolate colors
        final baseColor = Color.lerp(
          const Color(0xFFDEE4EA),
          const Color(0xFF2D2D2D),
          value,
        )!;

        final textColor = Color.lerp(
          const Color(0xFF485057),
          Colors.white70,
          value,
        )!;

        final dividerColor = Color.lerp(
          Colors.black.withValues(alpha: 0.06),
          Colors.white.withValues(alpha: 0.06),
          value,
        )!;

        // Interpolate shadow colors for ClayContainers
        final shadowColor1 = Color.lerp(
          Colors.black.withValues(alpha: 0.12),
          Colors.black.withValues(alpha: 0.4),
          value,
        );
        final shadowColor2 = Color.lerp(
          Colors.white.withValues(alpha: 0.7),
          Colors.white.withValues(alpha: 0.04),
          value,
        );

        return Scaffold(
          backgroundColor: baseColor,
          body: SafeArea(
            bottom: false,
            child: RefreshIndicator(
              onRefresh: () async {
                ref.invalidate(clientStatsProvider);
                ref.invalidate(myRequestsProvider);
              },
              color: theme.colorScheme.primary,
              child: ListView(
                physics: const AlwaysScrollableScrollPhysics(
                  parent: BouncingScrollPhysics(),
                ),
                padding: EdgeInsets.fromLTRB(20, 16, 20, bottomNavHeight + 24),
                children: [
                  // ── Header ──
                  StaggeredFadeSlide(
                    index: 0,
                    controller: _staggerController,
                    totalItems: 8,
                    child: _buildHeader(
                      theme,
                      user,
                      baseColor,
                      textColor,
                      isDark,
                      shadowColor1,
                      shadowColor2,
                    ),
                  ),
                  const SizedBox(height: 24),

                  // ── New Request Banner ──
                  StaggeredFadeSlide(
                    index: 1,
                    controller: _staggerController,
                    totalItems: 8,
                    child: _buildNewRequestBanner(
                      baseColor,
                      textColor,
                      theme,
                      isDark,
                      shadowColor1,
                      shadowColor2,
                    ),
                  ),

                  // ── Divider ──
                  _buildSectionDivider(dividerColor),

                  // ── Stats ──
                  if (statsAsync.isLoading || requestsAsync.isLoading)
                    const Padding(
                      padding: EdgeInsets.symmetric(vertical: 40),
                      child: Center(child: CircularProgressIndicator()),
                    )
                  else if (statsAsync.hasError)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      child: Center(child: Text('Error: ${statsAsync.error}')),
                    )
                  else
                    FadeTransition(
                      opacity: _fadeAnim,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          StaggeredFadeSlide(
                            index: 2,
                            controller: _staggerController,
                            totalItems: 8,
                            child: _buildSectionHeader(
                              'Overview',
                              PhosphorIconsRegular.chartBar,
                              textColor,
                              theme,
                            ),
                          ),
                          const SizedBox(height: 14),
                          StaggeredFadeSlide(
                            index: 3,
                            controller: _staggerController,
                            totalItems: 8,
                            child: Row(
                              children: [
                                _ClayStatusTile(
                                  label: "Total",
                                  value:
                                      "${statsAsync.value?.totalRequests ?? 0}",
                                  icon: PhosphorIconsFill.chartLineUp,
                                  color: const Color(0xFF667eea),
                                  baseColor: baseColor,
                                  textColor: textColor,
                                  shadowColor1: shadowColor1,
                                  shadowColor2: shadowColor2,
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      SmoothPageRoute(
                                        page: const MyRequestsPage(),
                                      ),
                                    );
                                  },
                                ),
                                const SizedBox(width: 12),
                                _ClayStatusTile(
                                  label: "Pending",
                                  value: "${statsAsync.value?.pending ?? 0}",
                                  icon: PhosphorIconsFill.clock,
                                  color: const Color(0xFFf093fb),
                                  baseColor: baseColor,
                                  textColor: textColor,
                                  shadowColor1: shadowColor1,
                                  shadowColor2: shadowColor2,
                                  onTap: () {},
                                ),
                                const SizedBox(width: 12),
                                _ClayStatusTile(
                                  label: "Done",
                                  value: "${statsAsync.value?.completed ?? 0}",
                                  icon: PhosphorIconsFill.checkCircle,
                                  color: const Color(0xFF4facfe),
                                  baseColor: baseColor,
                                  textColor: textColor,
                                  shadowColor1: shadowColor1,
                                  shadowColor2: shadowColor2,
                                  onTap: () {},
                                ),
                              ],
                            ),
                          ),

                          // ── Recent Requests ──
                          if (requestsAsync.hasValue &&
                              requestsAsync.value!.isNotEmpty) ...[
                            _buildSectionDivider(dividerColor),
                            StaggeredFadeSlide(
                              index: 4,
                              controller: _staggerController,
                              totalItems: 8,
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  _buildSectionHeader(
                                    'Recent Requests',
                                    PhosphorIconsRegular.listChecks,
                                    textColor,
                                    theme,
                                  ),
                                  GestureDetector(
                                    onTap: () {
                                      Navigator.push(
                                        context,
                                        SmoothPageRoute(
                                          page: const MyRequestsPage(),
                                        ),
                                      );
                                    },
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 14,
                                        vertical: 6,
                                      ),
                                      decoration: BoxDecoration(
                                        color: theme.colorScheme.primary
                                            .withValues(alpha: 0.1),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Text(
                                        'See all',
                                        style: GoogleFonts.plusJakartaSans(
                                          fontSize: 12,
                                          fontWeight: FontWeight.w700,
                                          color: theme.colorScheme.primary,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 14),
                            ...requestsAsync.value!
                                .take(3)
                                .toList()
                                .asMap()
                                .entries
                                .map(
                                  (entry) => StaggeredFadeSlide(
                                    index: 5 + entry.key,
                                    controller: _staggerController,
                                    totalItems: 8,
                                    child: Padding(
                                      padding: const EdgeInsets.only(
                                        bottom: 12,
                                      ),
                                      child: TapBounce(
                                        child: _buildRequestCard(
                                          entry.value,
                                          baseColor,
                                          textColor,
                                          theme,
                                          isDark,
                                          shadowColor1,
                                          shadowColor2,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                          ],

                          // ── Services ──
                          _buildSectionDivider(dividerColor),
                          StaggeredFadeSlide(
                            index: 6,
                            controller: _staggerController,
                            totalItems: 8,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                _buildSectionHeader(
                                  'Our Services',
                                  PhosphorIconsRegular.briefcase,
                                  textColor,
                                  theme,
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'Explore what we can do for you',
                                  style: GoogleFonts.plusJakartaSans(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w500,
                                    color: textColor.withValues(alpha: 0.45),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 16),
                          StaggeredFadeSlide(
                            index: 7,
                            controller: _staggerController,
                            totalItems: 8,
                            child: _buildServicesGrid(
                              baseColor,
                              textColor,
                              theme,
                              isDark,
                              shadowColor1,
                              shadowColor2,
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  // ── Section Divider (modern subtle line) ──
  Widget _buildSectionDivider(Color dividerColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 24),
      child: Row(
        children: [
          Expanded(
            child: Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    dividerColor.withValues(alpha: 0),
                    dividerColor,
                    dividerColor,
                    dividerColor.withValues(alpha: 0),
                  ],
                  stops: const [0.0, 0.2, 0.8, 1.0],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Section Header (icon + title) ──
  Widget _buildSectionHeader(
    String title,
    IconData icon,
    Color textColor,
    ThemeData theme,
  ) {
    return Row(
      children: [
        ClayIcon(
          icon: icon,
          size: 18,
          color: theme.colorScheme.primary.withValues(alpha: 0.7),
          baseColor: Theme.of(context).brightness == Brightness.dark
              ? const Color(0xFF2D2D2D)
              : const Color(0xFFDEE4EA),
          depth: 10,
          spread: 1,
          borderRadius: 12,
          padding: const EdgeInsets.all(8),
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 20,
            fontWeight: FontWeight.w800,
            color: textColor,
            letterSpacing: -0.5,
          ),
        ),
      ],
    );
  }

  // ── Header ──
  Widget _buildHeader(
    ThemeData theme,
    dynamic user,
    Color baseColor,
    Color textColor,
    bool isDark,
    Color? shadowColor1,
    Color? shadowColor2,
  ) {
    return Row(
      children: [
        BreathingWidget(
          duration: const Duration(seconds: 3),
          scaleEnd: 1.1,
          child: SizedBox(
            height: 50,
            width: 50,
            child: Image.asset(
              'assets/images/boy_waving.png',
              fit: BoxFit.contain,
              errorBuilder: (context, error, stackTrace) {
                return ClayIcon(
                  icon: PhosphorIconsFill.handWaving,
                  size: 24,
                  color: theme.colorScheme.primary,
                  baseColor: baseColor,
                  depth: 10,
                  spread: 1,
                  borderRadius: 25,
                  padding: const EdgeInsets.all(10),
                );
              },
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _getGreeting(),
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: textColor.withValues(alpha: 0.6),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                user?.fullName ?? 'Client',
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 28,
                  fontWeight: FontWeight.w800,
                  color: textColor,
                  letterSpacing: -1,
                  height: 1.2,
                ),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
        ),
        // Profile avatar → switches to Profile tab (index 2)
        GestureDetector(
          onTap: () {
            clientNavKey.currentState?.switchToTab(2);
          },
          child: ClayContainer(
            color: baseColor,
            borderRadius: 18,
            depth: 20,
            spread: 1,
            width: 52,
            height: 52,
            shadowColor1: shadowColor1,
            shadowColor2: shadowColor2,
            child: Container(
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [Color(0xFF667eea), Color(0xFF764ba2)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(16),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: user?.avatarUrl != null
                    ? Image.network(
                        user!.avatarUrl!,
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => const Icon(
                          PhosphorIconsFill.user,
                          color: Colors.white,
                          size: 24,
                        ),
                      )
                    : const Icon(
                        PhosphorIconsFill.user,
                        color: Colors.white,
                        size: 24,
                      ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // ── New Request Banner (Clay - Monochrome) ──
  Widget _buildNewRequestBanner(
    Color baseColor,
    Color textColor,
    ThemeData theme,
    bool isDark,
    Color? shadowColor1,
    Color? shadowColor2,
  ) {
    return GestureDetector(
      onTap: () => _showCreateRequest(context),
      child: ClayContainer(
        color: baseColor,
        borderRadius: 24,
        depth: 25,
        spread: 2,
        shadowColor1: shadowColor1,
        shadowColor2: shadowColor2,
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(borderRadius: BorderRadius.circular(24)),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Need help with\na project?',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                        color: textColor,
                        height: 1.2,
                        letterSpacing: -0.5,
                      ),
                    ),
                    const SizedBox(height: 14),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 18,
                        vertical: 11,
                      ),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.primary.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          ClayIcon(
                            icon: PhosphorIconsFill.plus,
                            size: 16,
                            color: theme.colorScheme.primary,
                            baseColor: theme.colorScheme.primary.withValues(
                              alpha: 0.1,
                            ),
                            depth: 5,
                            spread: 0,
                            borderRadius: 10,
                            padding: const EdgeInsets.all(4),
                          ),
                          const SizedBox(width: 8),
                          Text(
                            'New Request',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              color: theme.colorScheme.primary,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 12),
              ClayIcon(
                icon: PhosphorIconsFill.rocketLaunch,
                size: 32,
                color: textColor.withValues(alpha: 0.7),
                baseColor: baseColor,
                borderRadius: 20,
                depth: -10,
                spread: 1,
                emboss: true,
                padding: const EdgeInsets.all(
                  20,
                ), // Adjusted padding to match previous size
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ── Services Grid (Clay) ──
  Widget _buildServicesGrid(
    Color baseColor,
    Color textColor,
    ThemeData theme,
    bool isDark,
    Color? shadowColor1,
    Color? shadowColor2,
  ) {
    return Column(
      children: [
        for (int i = 0; i < ServicesData.services.length; i += 2) ...[
          Row(
            children: [
              Expanded(
                child: _ClayServiceCard(
                  service: ServicesData.services[i],
                  baseColor: baseColor,
                  textColor: textColor,
                  isDark: isDark,
                  shadowColor1: shadowColor1,
                  shadowColor2: shadowColor2,
                  onTap: () => _showCreateRequest(context),
                ),
              ),
              const SizedBox(width: 12),
              if (i + 1 < ServicesData.services.length)
                Expanded(
                  child: _ClayServiceCard(
                    service: ServicesData.services[i + 1],
                    baseColor: baseColor,
                    textColor: textColor,
                    isDark: isDark,
                    shadowColor1: shadowColor1,
                    shadowColor2: shadowColor2,
                    onTap: () => _showCreateRequest(context),
                  ),
                )
              else
                const Expanded(child: SizedBox()),
            ],
          ),
          if (i + 2 < ServicesData.services.length) const SizedBox(height: 12),
        ],
      ],
    );
  }

  // ── Request Card (Clay) ──
  Widget _buildRequestCard(
    ClientRequest request,
    Color baseColor,
    Color textColor,
    ThemeData theme,
    bool isDark,
    Color? shadowColor1,
    Color? shadowColor2,
  ) {
    Color statusColor;
    IconData statusIcon;

    switch (request.status) {
      case 'pending':
        statusColor = Colors.orange;
        statusIcon = PhosphorIconsFill.clock;
        break;
      case 'assigned':
        statusColor = Colors.blue;
        statusIcon = PhosphorIconsFill.clipboardText;
        break;
      case 'in_progress':
        statusColor = Colors.purple;
        statusIcon = PhosphorIconsFill.trendUp;
        break;
      case 'completed':
        statusColor = Colors.green;
        statusIcon = PhosphorIconsFill.checkCircle;
        break;
      default:
        statusColor = Colors.grey;
        statusIcon = PhosphorIconsFill.info;
    }

    return ClayContainer(
      color: baseColor,
      borderRadius: 18,
      depth: 15,
      spread: 1,
      padding: const EdgeInsets.all(16),
      shadowColor1: shadowColor1,
      shadowColor2: shadowColor2,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: statusColor,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: statusColor.withValues(alpha: 0.4),
                      blurRadius: 6,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  request.services.join(', '),
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    color: textColor,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 10,
                  vertical: 5,
                ),
                decoration: BoxDecoration(
                  color: statusColor.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(statusIcon, size: 12, color: statusColor),
                    const SizedBox(width: 4),
                    Text(
                      request.status[0].toUpperCase() +
                          request.status.substring(1).replaceAll('_', ' '),
                      style: GoogleFonts.plusJakartaSans(
                        color: statusColor,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            request.description,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13,
              color: textColor.withValues(alpha: 0.5),
              height: 1.4,
            ),
          ),
          if (request.assignedWorkerName != null) ...[
            const SizedBox(height: 10),
            Row(
              children: [
                Icon(
                  PhosphorIconsFill.user,
                  size: 14,
                  color: theme.colorScheme.primary,
                ),
                const SizedBox(width: 6),
                Text(
                  request.assignedWorkerName!,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 12,
                    color: theme.colorScheme.primary,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  String _getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Good morning 👋';
    if (hour < 17) return 'Good afternoon 👋';
    return 'Good evening 👋';
  }

  void _showCreateRequest(BuildContext context) async {
    await Navigator.push(
      context,
      SmoothPageRoute(page: const CreateRequestPage()),
    );
  }
}

/// ── Clay Service Card (with subtle inner shadow highlight) ──
class _ClayServiceCard extends StatelessWidget {
  final ServiceItem service;
  final Color baseColor;
  final Color textColor;
  final bool isDark;
  final VoidCallback onTap;
  final Color? shadowColor1;
  final Color? shadowColor2;

  const _ClayServiceCard({
    required this.service,
    required this.baseColor,
    required this.textColor,
    required this.isDark,
    required this.onTap,
    this.shadowColor1,
    this.shadowColor2,
  });

  @override
  Widget build(BuildContext context) {
    final gradientColors = (service.gradient as LinearGradient).colors;
    final primaryColor = gradientColors.first;

    return GestureDetector(
      onTap: onTap,
      child: ClayContainer(
        color: baseColor,
        borderRadius: 20,
        depth: 15,
        spread: 1,
        shadowColor1: shadowColor1,
        shadowColor2: shadowColor2,
        child: Container(
          height: 140,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            border: Border(
              top: BorderSide(
                color: isDark
                    ? Colors.white.withValues(alpha: 0.04)
                    : Colors.white.withValues(alpha: 0.6),
                width: 1,
              ),
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              ClayIcon(
                icon: service.icon,
                size: 22,
                color: primaryColor,
                baseColor: baseColor,
                borderRadius: 14,
                depth: -10,
                spread: 0,
                emboss: true,
                padding: const EdgeInsets.all(11),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    service.title,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 13,
                      fontWeight: FontWeight.w700,
                      color: textColor,
                      height: 1.2,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    service.subtitle,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 10,
                      fontWeight: FontWeight.w500,
                      color: textColor.withValues(alpha: 0.4),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ClayStatusTile extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  final Color baseColor;
  final Color textColor;
  final Color? shadowColor1;
  final Color? shadowColor2;
  final VoidCallback onTap;

  const _ClayStatusTile({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
    required this.baseColor,
    required this.textColor,
    required this.onTap,
    this.shadowColor1,
    this.shadowColor2,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: ClayContainer(
          color: baseColor,
          borderRadius: 22,
          depth: 15,
          spread: 1,
          shadowColor1: shadowColor1,
          shadowColor2: shadowColor2,
          child: Container(
            height: 130,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(22)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ClayIcon(
                  icon: icon,
                  color: color,
                  size: 20,
                  baseColor: baseColor,
                  borderRadius: 12,
                  depth: -10,
                  spread: 0,
                  emboss: true,
                  padding: const EdgeInsets.all(9),
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      value,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 28,
                        fontWeight: FontWeight.w800,
                        color: textColor,
                        height: 1,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      label,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: textColor.withValues(alpha: 0.5),
                        letterSpacing: 0.3,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
