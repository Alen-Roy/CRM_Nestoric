import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:nes/core/theme/app_colors.dart';
import 'package:nes/core/widgets/clay_container.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';
import 'package:nes/services/client_api_service.dart';
import 'package:nes/services/chat_api_service.dart';
import 'package:nes/features/client/providers/client_providers.dart';
import 'package:nes/services/admin_api_service.dart';

// ─────────────────────────────────────────────
//  Razorpay Key — MUST be passed at build/run time via:
//  flutter run --dart-define=RAZORPAY_KEY=rzp_live_xxx
//  flutter build apk --dart-define=RAZORPAY_KEY=rzp_live_xxx
//  Never hardcode the key here.
// ─────────────────────────────────────────────
const String kRazorpayKeyId = "rzp_live_SP6uHh5lXdRZRK";

// ────────────────────────────────────────────
//  3-Tier Payment Plan definitions
// ────────────────────────────────────────────
class _PlanTier {
  final String id; // 'basic' | 'standard' | 'premium'
  final String label;
  final String emoji;
  final double multiplier;
  final Color color;
  final List<String> perks;

  const _PlanTier({
    required this.id,
    required this.label,
    required this.emoji,
    required this.multiplier,
    required this.color,
    required this.perks,
  });

  factory _PlanTier.fromJson(Map<String, dynamic> json) {
    // Parse hex color string like '#68D391' → Color
    Color parseColor(String hex) {
      final h = hex.replaceAll('#', '');
      return Color(int.parse('FF$h', radix: 16));
    }

    return _PlanTier(
      id: json['tierId'] as String,
      label: json['label'] as String,
      emoji: json['emoji'] as String,
      multiplier: (json['multiplier'] as num).toDouble(),
      color: parseColor(json['color'] as String? ?? '#68D391'),
      perks: (json['perks'] as List<dynamic>?)?.cast<String>() ?? [],
    );
  }
}

// Hardcoded fallback (used only if the API call fails)
const _fallbackPlans = [
  _PlanTier(
    id: 'basic',
    label: 'Basic',
    emoji: '🌱',
    multiplier: 1.0,
    color: Color(0xFF68D391),
    perks: ['Standard queue', '7-day delivery', 'Email updates'],
  ),
  _PlanTier(
    id: 'standard',
    label: 'Standard',
    emoji: '⚡',
    multiplier: 1.5,
    color: Color(0xFF63B3ED),
    perks: ['Priority queue', '3–4 day delivery', 'Chat support'],
  ),
  _PlanTier(
    id: 'premium',
    label: 'Premium',
    emoji: '👑',
    multiplier: 2.5,
    color: Color(0xFF8B7FD5),
    perks: ['Dedicated worker', '1–2 day express', '24/7 support'],
  ),
];

class PaymentPage extends ConsumerStatefulWidget {
  final List<String> selectedServices;
  final String description;
  final DateTime? deadline;
  final List<File> selectedFiles;

  const PaymentPage({
    super.key,
    required this.selectedServices,
    required this.description,
    required this.deadline,
    required this.selectedFiles,
  });

  @override
  ConsumerState<PaymentPage> createState() => _PaymentPageState();
}

class _PaymentPageState extends ConsumerState<PaymentPage> {
  late Razorpay _razorpay;
  bool _isProcessing = false;
  bool _isUploading = false;
  bool _paymentSuccess = false;

  // ── Prices and tiers fetched from backend ───
  Map<String, double> _servicePrices = {};
  List<_PlanTier> _plans = _fallbackPlans;
  bool _pricesLoading = true;

  // ── Selected plan ────────────────────────────
  _PlanTier get _selectedPlan => _plans[_selectedPlanIndex];
  int _selectedPlanIndex = 0; // default: Basic

  double get _subtotal =>
      widget.selectedServices.fold(
        0.0,
        (sum, s) => sum + (_servicePrices[s] ?? 0),
      ) *
      _selectedPlan.multiplier;
  double get _tax => _subtotal * 0.18;
  double get _total => _subtotal + _tax;
  int get _totalInPaise => (_total * 100).round();

  @override
  void initState() {
    super.initState();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _onPaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _onPaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _onExternalWallet);
    _fetchPrices();
  }

  Future<void> _fetchPrices() async {
    // Fetch prices and tiers in parallel
    final results = await Future.wait([
      AdminApiService.getActiveServicePrices(),
      AdminApiService.getPlanTiers(),
    ]);

    if (!mounted) return;

    final priceResult = results[0];
    final tierResult = results[1];

    final map = <String, double>{};
    if (priceResult['success'] == true) {
      final list = priceResult['prices'] as List;
      for (final item in list) {
        map[item['serviceName'] as String] = (item['price'] as num).toDouble();
      }
    }

    List<_PlanTier> tiers = _fallbackPlans;
    if (tierResult['success'] == true) {
      final tierList = tierResult['tiers'] as List;
      if (tierList.isNotEmpty) {
        tiers = tierList
            .map((t) => _PlanTier.fromJson(t as Map<String, dynamic>))
            .toList();
      }
    }

    setState(() {
      _servicePrices = map;
      _plans = tiers;
      _pricesLoading = false;
    });
  }

  @override
  void dispose() {
    _razorpay.clear();
    super.dispose();
  }

  // ── Razorpay event handlers ──────────────────
  void _onPaymentSuccess(PaymentSuccessResponse response) async {
    if (!mounted) return;
    setState(() => _paymentSuccess = true);
    _showSnack('Payment successful! Submitting your request…');
    await _submitRequest(
      paymentId: response.paymentId ?? 'unknown',
      orderId: response.orderId,
      signature: response.signature,
    );
  }

  void _onPaymentError(PaymentFailureResponse response) {
    setState(() => _isProcessing = false);
    _showSnack(
      'Payment failed: ${response.message ?? "Unknown error"}',
      isError: true,
    );
  }

  void _onExternalWallet(ExternalWalletResponse response) {
    _showSnack('External wallet: ${response.walletName}');
  }

  // ── Launch Razorpay checkout ─────────────────
  // upiApp package names: 'com.google.android.apps.nbu.paisa.user' (GPay)
  //   'com.phonepe.app' (PhonePe), 'net.one97.paytm' (Paytm), 'in.org.npci.upiapp' (BHIM)
  void _startPayment({String? upiAppPackage}) {
    if (kRazorpayKeyId.isEmpty) {
      _showSnack(
        'Razorpay key not configured. Pass --dart-define=RAZORPAY_KEY=rzp_xxx when running the app.',
        isError: true,
      );
      return;
    }

    final authState = ref.read(authProvider);
    final userName = authState.user?.fullName ?? 'Customer';
    final userEmail = authState.user?.email ?? 'customer@example.com';
    // Phone is always collected at sign-up / Google profile setup — pass it directly.
    final userPhone = authState.user?.phone ?? '';

    final options = <String, dynamic>{
      'key': kRazorpayKeyId,
      'amount': _totalInPaise,
      'name': 'Nexify',
      'description': widget.selectedServices.join(', '),
      'prefill': {
        'name': userName,
        'email': userEmail,
        'contact': userPhone,
        'method': 'upi',
      },
      'theme': {'color': '#6C63FF'},
      'method': {
        'upi': true,
        'card': false,
        'netbanking': false,
        'wallet': false,
        'emi': false,
        'bank_transfer': false,
      },
      'upi': {
        'flow': 'intent',
        if (upiAppPackage != null) 'app_name': upiAppPackage,
      },
    };

    try {
      setState(() => _isProcessing = true);
      _razorpay.open(options);
    } catch (e) {
      setState(() => _isProcessing = false);
      _showSnack('Error: $e', isError: true);
    }
  }

  // ── Submit request after successful payment ──
  Future<void> _submitRequest({
    required String paymentId,
    String? orderId,
    String? signature,
  }) async {
    final token = ref.read(authProvider).token;
    if (token == null) {
      _showSnack('Session expired. Please login again.', isError: true);
      return;
    }

    setState(() => _isProcessing = true);
    final List<String> uploadedFileUrls = [];

    try {
      // Upload files if any
      if (widget.selectedFiles.isNotEmpty) {
        setState(() => _isUploading = true);
        for (var file in widget.selectedFiles) {
          final isImage = [
            'jpg',
            'jpeg',
            'png',
          ].any((ext) => file.path.toLowerCase().endsWith(ext));
          final type = isImage ? 'image' : 'document';

          final uploadResult = await ChatApiService.uploadFile(
            token: token,
            file: file,
            type: type,
          );

          if (uploadResult['success']) {
            final url = uploadResult['url'];
            if (url != null && url.toString().isNotEmpty) {
              uploadedFileUrls.add(url);
            } else {
              debugPrint('Upload succeeded but no URL for: ${file.path}');
              throw Exception(
                'Upload returned no URL for ${file.path.split('/').last}',
              );
            }
          } else {
            throw Exception('Failed to upload ${file.path.split('/').last}');
          }
        }
        setState(() => _isUploading = false);
      }

      // Create the request, passing payment info and selected plan
      final result = await ClientApiService.createRequest(
        token: token,
        services: widget.selectedServices,
        description: widget.description,
        deadline: widget.deadline,
        uploadedFiles: uploadedFileUrls.isNotEmpty ? uploadedFileUrls : null,
        paymentId: paymentId,
        razorpayOrderId: orderId,
        razorpaySignature: signature,
        amountPaid: _total,
        plan: _selectedPlan.id,
      );

      if (result['success']) {
        if (mounted) {
          ref.invalidate(clientStatsProvider);
          ref.invalidate(myRequestsProvider);
          _showSuccessDialog();
        }
      } else {
        throw Exception(result['error']);
      }
    } catch (e) {
      if (mounted) {
        _showSnack(
          'Paid but request failed: ${e.toString().replaceAll("Exception: ", "")}. '
          'Contact support with payment ID: $paymentId',
          isError: true,
        );
      }
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) {
        final theme = Theme.of(context);
        final isDark = theme.brightness == Brightness.dark;
        final baseColor = isDark
            ? const Color(0xFF2D2D2D)
            : const Color(0xFFDEE4EA);

        return Dialog(
          backgroundColor: baseColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(28),
          ),
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    color: AppColors.success.withValues(alpha: 0.1),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    PhosphorIconsFill.checkCircle,
                    color: AppColors.success,
                    size: 48,
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  'Request Submitted!',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  'Payment confirmed and your request has been successfully submitted. '
                  'We\'ll get back to you shortly.',
                  textAlign: TextAlign.center,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 14,
                    color: Colors.grey,
                  ),
                ),
                const SizedBox(height: 28),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18),
                      ),
                    ),
                    onPressed: () {
                      // Close dialog then pop back to dashboard safely.
                      // Using popUntil avoids stale-context issues from
                      // calling pop() multiple times inside a dialog builder.
                      Navigator.of(context).pop(); // close dialog
                      // Pop back to the root route (ClientMainLayout)
                      Navigator.of(context).popUntil((route) => route.isFirst);
                    },
                    child: Text(
                      'Back to Dashboard',
                      style: GoogleFonts.plusJakartaSans(
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showSnack(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: GoogleFonts.plusJakartaSans(color: Colors.white),
        ),
        backgroundColor: isError ? AppColors.error : AppColors.success,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }

  // ─────────────────────────────────────────────
  //  BUILD
  // ─────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final baseColor = isDark
        ? const Color(0xFF2D2D2D)
        : const Color(0xFFDEE4EA);
    final textColor = isDark ? Colors.white70 : const Color(0xFF485057);
    final dividerColor = isDark
        ? Colors.white.withValues(alpha: 0.06)
        : Colors.black.withValues(alpha: 0.06);

    if (_pricesLoading) {
      return Scaffold(
        backgroundColor: baseColor,
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      backgroundColor: baseColor,
      body: SafeArea(
        child: Column(
          children: [
            // ── Header ──────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: Row(
                children: [
                  ClayContainer(
                    color: baseColor,
                    borderRadius: 22,
                    depth: 20,
                    spread: 1,
                    width: 44,
                    height: 44,
                    child: IconButton(
                      icon: Icon(
                        PhosphorIconsRegular.caretLeft,
                        size: 22,
                        color: textColor,
                      ),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Payment',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 24,
                          fontWeight: FontWeight.w800,
                          color: textColor,
                          letterSpacing: -0.5,
                        ),
                      ),
                      Text(
                        'Review & pay to submit',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 12,
                          color: textColor.withValues(alpha: 0.5),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // ── Progress indicator ───────────────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Row(
                children: [
                  _buildStep(baseColor, theme, '1', 'Services', isDone: true),
                  _buildStepLine(dividerColor, isDone: true),
                  _buildStep(baseColor, theme, '2', 'Details', isDone: true),
                  _buildStepLine(dividerColor, isDone: true),
                  _buildStep(
                    baseColor,
                    theme,
                    '3',
                    'Payment',
                    isActive: true,
                    isDone: false,
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // ── Scrollable body ──────────────────────
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 40),
                physics: const BouncingScrollPhysics(),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // ── Choose your plan ───────────────
                    _buildSectionTitle(
                      'Choose Your Plan',
                      PhosphorIconsRegular.star,
                      textColor,
                      theme,
                    ),
                    const SizedBox(height: 14),
                    Row(
                      children: _plans.asMap().entries.map((entry) {
                        final idx = entry.key;
                        final plan = entry.value;
                        final isSelected = _selectedPlanIndex == idx;
                        return Expanded(
                          child: GestureDetector(
                            onTap: () =>
                                setState(() => _selectedPlanIndex = idx),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 220),
                              curve: Curves.easeOutCubic,
                              margin: const EdgeInsets.symmetric(horizontal: 4),
                              decoration: BoxDecoration(
                                color: isSelected
                                    ? plan.color.withValues(alpha: 0.15)
                                    : baseColor,
                                borderRadius: BorderRadius.circular(18),
                                border: Border.all(
                                  color: isSelected
                                      ? plan.color
                                      : plan.color.withValues(alpha: 0.2),
                                  width: isSelected ? 2 : 1,
                                ),
                                boxShadow: isSelected
                                    ? [
                                        BoxShadow(
                                          color: plan.color.withValues(
                                            alpha: 0.25,
                                          ),
                                          blurRadius: 12,
                                          offset: const Offset(0, 4),
                                        ),
                                      ]
                                    : [],
                              ),
                              padding: const EdgeInsets.symmetric(
                                vertical: 14,
                                horizontal: 10,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text(
                                    plan.emoji,
                                    style: const TextStyle(fontSize: 22),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    plan.label,
                                    style: GoogleFonts.plusJakartaSans(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w800,
                                      color: isSelected
                                          ? plan.color
                                          : textColor,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 6,
                                      vertical: 2,
                                    ),
                                    decoration: BoxDecoration(
                                      color: plan.color.withValues(alpha: 0.15),
                                      borderRadius: BorderRadius.circular(6),
                                    ),
                                    child: Text(
                                      '\u00d7${plan.multiplier % 1 == 0 ? plan.multiplier.toStringAsFixed(0) : plan.multiplier.toStringAsFixed(1)}',
                                      style: GoogleFonts.plusJakartaSans(
                                        fontSize: 10,
                                        fontWeight: FontWeight.w700,
                                        color: plan.color,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  ...plan.perks.map(
                                    (p) => Padding(
                                      padding: const EdgeInsets.only(bottom: 3),
                                      child: Row(
                                        children: [
                                          Icon(
                                            PhosphorIconsRegular.checkCircle,
                                            size: 9,
                                            color: plan.color,
                                          ),
                                          const SizedBox(width: 4),
                                          Expanded(
                                            child: Text(
                                              p,
                                              style:
                                                  GoogleFonts.plusJakartaSans(
                                                    fontSize: 9,
                                                    color: textColor.withValues(
                                                      alpha: 0.7,
                                                    ),
                                                  ),
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 24),

                    // ── Order summary ──────────────────
                    _buildSectionTitle(
                      'Order Summary',
                      PhosphorIconsRegular.receipt,
                      textColor,
                      theme,
                    ),
                    const SizedBox(height: 14),

                    ClayContainer(
                      color: baseColor,
                      depth: 15,
                      spread: 1,
                      borderRadius: 20,
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        children: [
                          ...widget.selectedServices.map((service) {
                            final basePrice = _servicePrices[service] ?? 0;
                            final adjustedPrice =
                                basePrice * _selectedPlan.multiplier;
                            return Padding(
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              child: Row(
                                children: [
                                  Container(
                                    width: 8,
                                    height: 8,
                                    decoration: BoxDecoration(
                                      color: theme.colorScheme.primary,
                                      shape: BoxShape.circle,
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  Expanded(
                                    child: Text(
                                      service,
                                      style: GoogleFonts.plusJakartaSans(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w500,
                                        color: textColor,
                                      ),
                                    ),
                                  ),
                                  if (_selectedPlan.multiplier != 1.0)
                                    Text(
                                      '\u20b9${basePrice.toStringAsFixed(0)} ',
                                      style: GoogleFonts.plusJakartaSans(
                                        fontSize: 12,
                                        color: textColor.withValues(alpha: 0.4),
                                        decoration: TextDecoration.lineThrough,
                                      ),
                                    ),
                                  Text(
                                    '\u20b9${adjustedPrice.toStringAsFixed(0)}',
                                    style: GoogleFonts.plusJakartaSans(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w700,
                                      color: textColor,
                                    ),
                                  ),
                                ],
                              ),
                            );
                          }),

                          // Plan multiplier indicator row
                          if (_selectedPlan.multiplier != 1.0)
                            Padding(
                              padding: const EdgeInsets.only(top: 4, bottom: 4),
                              child: Row(
                                children: [
                                  Icon(
                                    PhosphorIconsRegular.star,
                                    size: 12,
                                    color: _selectedPlan.color,
                                  ),
                                  const SizedBox(width: 6),
                                  Text(
                                    '${_selectedPlan.label} plan \u00d7${_selectedPlan.multiplier % 1 == 0 ? _selectedPlan.multiplier.toStringAsFixed(0) : _selectedPlan.multiplier.toStringAsFixed(1)} applied',
                                    style: GoogleFonts.plusJakartaSans(
                                      fontSize: 11,
                                      color: _selectedPlan.color,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                            ),

                          Padding(
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            child: Container(
                              height: 1,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    dividerColor.withValues(alpha: 0),
                                    dividerColor,
                                    dividerColor,
                                    dividerColor.withValues(alpha: 0),
                                  ],
                                ),
                              ),
                            ),
                          ),

                          _buildPriceLine('Subtotal', _subtotal, textColor),
                          const SizedBox(height: 8),
                          _buildPriceLine(
                            'GST (18%)',
                            _tax,
                            textColor,
                            isSubtle: true,
                          ),
                          const SizedBox(height: 14),

                          Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 14,
                            ),
                            decoration: BoxDecoration(
                              color: theme.colorScheme.primary.withValues(
                                alpha: 0.1,
                              ),
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  'Total Payable',
                                  style: GoogleFonts.plusJakartaSans(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w800,
                                    color: theme.colorScheme.primary,
                                  ),
                                ),
                                Text(
                                  '₹${_total.toStringAsFixed(0)}',
                                  style: GoogleFonts.plusJakartaSans(
                                    fontSize: 20,
                                    fontWeight: FontWeight.w900,
                                    color: theme.colorScheme.primary,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 24),

                    // ── Pay button ────────────────────────
                    GestureDetector(
                      onTap: _isProcessing ? null : () => _startPayment(),
                      child: ClayContainer(
                        color: baseColor,
                        borderRadius: 22,
                        depth: 25,
                        spread: 2,
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 18),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                theme.colorScheme.primary,
                                theme.colorScheme.primary.withValues(
                                  alpha: 0.8,
                                ),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(22),
                          ),
                          child: _isProcessing
                              ? Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    const SizedBox(
                                      width: 20,
                                      height: 20,
                                      child: CircularProgressIndicator(
                                        color: Colors.white,
                                        strokeWidth: 2,
                                      ),
                                    ),
                                    const SizedBox(width: 12),
                                    Text(
                                      _paymentSuccess
                                          ? (_isUploading
                                                ? 'Uploading files…'
                                                : 'Submitting request…')
                                          : 'Processing payment…',
                                      style: GoogleFonts.plusJakartaSans(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w700,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                )
                              : Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    const Icon(
                                      PhosphorIconsFill.lockKey,
                                      color: Colors.white,
                                      size: 20,
                                    ),
                                    const SizedBox(width: 10),
                                    Text(
                                      'Pay ₹${_total.toStringAsFixed(0)} & Submit',
                                      style: GoogleFonts.plusJakartaSans(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w700,
                                        color: Colors.white,
                                      ),
                                    ),
                                  ],
                                ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 14),
                    Center(
                      child: Text(
                        '🔒 Your payment is 100% secure & encrypted',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 12,
                          color: textColor.withValues(alpha: 0.4),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─────────────────────────────────────────────
  //  Helper widgets
  // ─────────────────────────────────────────────
  Widget _buildStep(
    Color baseColor,
    ThemeData theme,
    String number,
    String label, {
    bool isDone = false,
    bool isActive = false,
  }) {
    final color = (isDone || isActive)
        ? theme.colorScheme.primary
        : Colors.grey.withValues(alpha: 0.3);
    return Column(
      children: [
        Container(
          width: 32,
          height: 32,
          decoration: BoxDecoration(
            color: isDone || isActive
                ? theme.colorScheme.primary
                : Colors.grey.withValues(alpha: 0.15),
            shape: BoxShape.circle,
          ),
          child: isDone
              ? const Icon(Icons.check, color: Colors.white, size: 16)
              : Center(
                  child: Text(
                    number,
                    style: GoogleFonts.plusJakartaSans(
                      color: isActive ? Colors.white : Colors.grey,
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                    ),
                  ),
                ),
        ),
        const SizedBox(height: 4),
        Text(
          label,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 10,
            color: color,
            fontWeight: (isDone || isActive)
                ? FontWeight.w700
                : FontWeight.w400,
          ),
        ),
      ],
    );
  }

  Widget _buildStepLine(Color dividerColor, {bool isDone = false}) {
    return Expanded(
      child: Container(
        height: 2,
        margin: const EdgeInsets.only(bottom: 18, left: 4, right: 4),
        decoration: BoxDecoration(
          color: isDone
              ? AppColors.primary.withValues(alpha: 0.4)
              : dividerColor,
          borderRadius: BorderRadius.circular(2),
        ),
      ),
    );
  }

  Widget _buildSectionTitle(
    String title,
    IconData icon,
    Color textColor,
    ThemeData theme,
  ) {
    return Row(
      children: [
        Icon(
          icon,
          size: 18,
          color: theme.colorScheme.primary.withValues(alpha: 0.7),
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: textColor,
            letterSpacing: -0.3,
          ),
        ),
      ],
    );
  }

  Widget _buildPriceLine(
    String label,
    double amount,
    Color textColor, {
    bool isSubtle = false,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: GoogleFonts.plusJakartaSans(
            fontSize: isSubtle ? 13 : 14,
            color: isSubtle ? textColor.withValues(alpha: 0.5) : textColor,
            fontWeight: isSubtle ? FontWeight.w400 : FontWeight.w600,
          ),
        ),
        Text(
          '₹${amount.toStringAsFixed(0)}',
          style: GoogleFonts.plusJakartaSans(
            fontSize: isSubtle ? 13 : 14,
            color: isSubtle ? textColor.withValues(alpha: 0.5) : textColor,
            fontWeight: isSubtle ? FontWeight.w400 : FontWeight.w600,
          ),
        ),
      ],
    );
  }
}
