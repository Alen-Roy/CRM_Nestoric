import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:nes/core/providers/theme_provider.dart';
import 'package:nes/core/widgets/clay_container.dart';
import 'package:nes/core/widgets/clay_icon.dart';
import 'package:nes/features/auth/presentation/login_signup.dart';
import 'package:nes/features/auth/models/user_model.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';
import 'package:nes/services/app_info_service.dart';

class ProfilePage extends ConsumerWidget {
  const ProfilePage({super.key});

  Future<void> _logout(BuildContext context, WidgetRef ref) async {
    final theme = Theme.of(context);
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
          title: Text(
            'Logout',
            style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w800),
          ),
          content: const Text('Are you sure you want to logout?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              style: TextButton.styleFrom(
                foregroundColor: theme.colorScheme.error,
              ),
              child: const Text('Logout'),
            ),
          ],
        );
      },
    );

    if (confirm == true && context.mounted) {
      await ref.read(authProvider.notifier).logout();
      if (context.mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LoginSignup()),
          (route) => false,
        );
      }
    }
  }

  /// Gradient divider for clean section separation
  Widget _buildDivider(double value) {
    // Interpolate divider color
    final dividerColor = Color.lerp(
      Colors.black.withValues(alpha: 0.06),
      Colors.white.withValues(alpha: 0.06),
      value,
    )!;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 24),
      child: Container(
        height: 1,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              dividerColor.withValues(alpha: 0),
              dividerColor,
              dividerColor,
              dividerColor.withValues(alpha: 0),
            ],
            stops: const [0.0, 0.2, 0.8, 1.0],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final user = ref.watch(currentUserProvider);
    final themeMode = ref.watch(themeModeProvider);

    // Animate between 0.0 (light) and 1.0 (dark)
    final targetValue = isDark ? 1.0 : 0.0;

    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: targetValue, end: targetValue),
      duration: const Duration(milliseconds: 400),
      curve: Curves.easeInOutCubic,
      builder: (context, value, child) {
        // Interpolate colors
        final baseColor = Color.lerp(
          const Color(0xFFDEE4EA),
          const Color(0xFF2D2D2D),
          value,
        )!;

        final textColor = Color.lerp(
          const Color(0xFF485057),
          Colors.white70,
          value,
        )!;

        // Interpolate shadow colors for ClayContainers
        final shadowColor1 = Color.lerp(
          Colors.black.withValues(alpha: 0.12),
          Colors.black.withValues(alpha: 0.4),
          value,
        );
        final shadowColor2 = Color.lerp(
          Colors.white.withValues(alpha: 0.7),
          Colors.white.withValues(alpha: 0.04),
          value,
        );

        return Scaffold(
          backgroundColor: baseColor,
          body: SafeArea(
            child: ListView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 100),
              children: [
                // Header
                Text(
                  'Profile',
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 30,
                    fontWeight: FontWeight.w900,
                    color: textColor,
                    letterSpacing: -1,
                  ),
                ),
                const SizedBox(height: 24),

                // ── Avatar Card (Clay) ──
                GestureDetector(
                  onTap: () {
                    if (user != null) {
                      _showEditProfileDialog(context, ref, user);
                    }
                  },
                  child: ClayContainer(
                    color: baseColor,
                    borderRadius: 24,
                    depth: 20,
                    spread: 1,
                    padding: const EdgeInsets.all(24),
                    shadowColor1: shadowColor1,
                    shadowColor2: shadowColor2,
                    child: Row(
                      children: [
                        ClayContainer(
                          color: baseColor,
                          borderRadius: 34,
                          depth: 15,
                          spread: 1,
                          width: 68,
                          height: 68,
                          shadowColor1: shadowColor1,
                          shadowColor2: shadowColor2,
                          child: Container(
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  theme.colorScheme.primary,
                                  theme.colorScheme.primary.withValues(
                                    alpha: 0.7,
                                  ),
                                ],
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                              ),
                              shape: BoxShape.circle,
                            ),
                            child: user?.avatarUrl != null
                                ? ClipOval(
                                    child: Image.network(
                                      user!.avatarUrl!,
                                      fit: BoxFit.cover,
                                      errorBuilder: (_, __, ___) => const Icon(
                                        PhosphorIconsFill.user,
                                        color: Colors.white,
                                        size: 30,
                                      ),
                                    ),
                                  )
                                : const Icon(
                                    PhosphorIconsFill.user,
                                    color: Colors.white,
                                    size: 30,
                                  ),
                          ),
                        ),
                        const SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                user?.fullName ?? 'User',
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 22,
                                  fontWeight: FontWeight.w800,
                                  color: textColor,
                                  letterSpacing: -0.3,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                user?.email ?? '',
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 14,
                                  color: textColor.withValues(alpha: 0.6),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                // ── Divider ──
                _buildDivider(value),

                // ── Appearance Section ──
                _ClaySection(
                  label: 'APPEARANCE',
                  icon: PhosphorIconsRegular.paintBrush,
                  textColor: textColor,
                  theme: theme,
                ),
                const SizedBox(height: 12),
                _ClayThemeSelector(
                  currentMode: themeMode,
                  onChanged: (mode) {
                    ref.read(themeModeProvider.notifier).setThemeMode(mode);
                  },
                  baseColor: baseColor,
                  textColor: textColor,
                  theme: theme,
                  shadowColor1: shadowColor1,
                  shadowColor2: shadowColor2,
                ),

                // ── Divider ──
                _buildDivider(value),

                // ── General Section ──
                _ClaySection(
                  label: 'GENERAL',
                  icon: PhosphorIconsRegular.gear,
                  textColor: textColor,
                  theme: theme,
                ),
                const SizedBox(height: 12),
                _ClaySettingsItem(
                  icon: PhosphorIconsRegular.info,
                  title: 'About Nexify',
                  subtitle: 'Version ${AppInfoService.version}',
                  onTap: () {
                    showAboutDialog(
                      context: context,
                      applicationName: 'Nexify',
                      applicationVersion: AppInfoService.version,
                      applicationIcon: Container(
                        width: 56,
                        height: 56,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              theme.colorScheme.primary,
                              theme.colorScheme.primary.withValues(alpha: 0.7),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Icon(
                          PhosphorIconsFill.buildings,
                          color: Colors.white,
                          size: 28,
                        ),
                      ),
                    );
                  },
                  baseColor: baseColor,
                  textColor: textColor,
                  theme: theme,
                  shadowColor1: shadowColor1,
                  shadowColor2: shadowColor2,
                ),
                const SizedBox(height: 10),
                _ClaySettingsItem(
                  icon: PhosphorIconsRegular.shieldCheck,
                  title: 'Privacy Policy',
                  subtitle: 'Read our terms',
                  onTap: () => _showPrivacyPolicy(context),
                  baseColor: baseColor,
                  textColor: textColor,
                  theme: theme,
                  shadowColor1: shadowColor1,
                  shadowColor2: shadowColor2,
                ),
                const SizedBox(height: 10),
                _ClaySettingsItem(
                  icon: PhosphorIconsRegular.question,
                  title: 'Help & Support',
                  subtitle: 'Get assistance',
                  onTap: () => _showHelpSupport(context),
                  baseColor: baseColor,
                  textColor: textColor,
                  theme: theme,
                  shadowColor1: shadowColor1,
                  shadowColor2: shadowColor2,
                ),

                // ── Divider ──
                _buildDivider(value),

                // ── Logout ──
                Material(
                  color: Colors.transparent,
                  borderRadius: BorderRadius.circular(18),
                  child: InkWell(
                    onTap: () => _logout(context, ref),
                    borderRadius: BorderRadius.circular(18),
                    splashColor: Colors.redAccent.withValues(alpha: 0.1),
                    highlightColor: Colors.redAccent.withValues(alpha: 0.05),
                    child: ClayContainer(
                      color: baseColor,
                      borderRadius: 18,
                      depth: 15,
                      spread: 1,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shadowColor1: shadowColor1,
                      shadowColor2: shadowColor2,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            PhosphorIconsFill.signOut,
                            color: Colors.redAccent,
                            size: 22,
                          ),
                          const SizedBox(width: 10),
                          Text(
                            'Logout',
                            style: GoogleFonts.plusJakartaSans(
                              color: Colors.redAccent,
                              fontWeight: FontWeight.w700,
                              fontSize: 16,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  void _showPrivacyPolicy(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        final theme = Theme.of(context);
        final isDark = theme.brightness == Brightness.dark;
        final baseColor = isDark
            ? const Color(0xFF2D2D2D)
            : const Color(0xFFDEE4EA);
        final textColor = isDark ? Colors.white70 : const Color(0xFF485057);

        return DraggableScrollableSheet(
          initialChildSize: 0.7,
          minChildSize: 0.5,
          maxChildSize: 0.95,
          builder: (_, controller) {
            return Container(
              decoration: BoxDecoration(
                color: baseColor,
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(24),
                ),
              ),
              padding: const EdgeInsets.all(24),
              child: ListView(
                controller: controller,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: textColor.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  Text(
                    'Privacy Policy',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: textColor,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Last updated: February 20, 2026',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 14,
                      color: textColor.withValues(alpha: 0.6),
                    ),
                  ),
                  const SizedBox(height: 24),
                  _buildSectionTitle('1. Information Collection', textColor),
                  _buildSectionText(
                    'We collect information you provide directly to us, such as when you create or modify your account, request services, contact customer support, or otherwise communicate with us. This information may include: name, email, phone number, postal address, profile picture, payment method, and other information you choose to provide.',
                    textColor,
                  ),
                  _buildSectionTitle('2. Information Usage', textColor),
                  _buildSectionText(
                    'We use user data to provide, maintain, and improve our services. This includes using the data to: process payments, send receipts, provide customer support, and authenticate users.',
                    textColor,
                  ),
                  _buildSectionTitle('3. Information Sharing', textColor),
                  _buildSectionText(
                    'We do not share your personal information with third parties except as described in this privacy policy. We may share your information with service providers who perform services on our behalf.',
                    textColor,
                  ),
                  _buildSectionTitle('4. Security', textColor),
                  _buildSectionText(
                    'We take reasonable measures to help protect information about you from loss, theft, misuse and unauthorized access, disclosure, alteration and destruction.',
                    textColor,
                  ),
                  const SizedBox(height: 40),
                ],
              ),
            );
          },
        );
      },
    );
  }

  void _showHelpSupport(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) {
        final theme = Theme.of(context);
        final isDark = theme.brightness == Brightness.dark;
        final baseColor = isDark
            ? const Color(0xFF2D2D2D)
            : const Color(0xFFDEE4EA);
        final textColor = isDark ? Colors.white70 : const Color(0xFF485057);

        return DraggableScrollableSheet(
          initialChildSize: 0.6,
          minChildSize: 0.4,
          maxChildSize: 0.9,
          builder: (_, controller) {
            return Container(
              decoration: BoxDecoration(
                color: baseColor,
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(24),
                ),
              ),
              padding: const EdgeInsets.all(24),
              child: ListView(
                controller: controller,
                children: [
                  Center(
                    child: Container(
                      width: 40,
                      height: 4,
                      decoration: BoxDecoration(
                        color: textColor.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(2),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  Text(
                    'Help & Support',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: textColor,
                    ),
                  ),
                  const SizedBox(height: 24),
                  _buildSectionTitle('Frequently Asked Questions', textColor),
                  const SizedBox(height: 16),
                  _buildFaqItem(
                    context,
                    'How do I reset my password?',
                    'Go to the login page and tap "Forgot Password". Follow the instructions sent to your email.',
                    textColor,
                    baseColor,
                  ),
                  _buildFaqItem(
                    context,
                    'How do I cancel a request?',
                    'Go to your active requests, select the one you want to cancel, and tap the "Cancel" button.',
                    textColor,
                    baseColor,
                  ),
                  _buildFaqItem(
                    context,
                    'Is my payment information secure?',
                    'Yes, we use industry-standard encryption to protect your payment details.',
                    textColor,
                    baseColor,
                  ),
                  const SizedBox(height: 24),
                  _buildSectionTitle('Contact Us', textColor),
                  const SizedBox(height: 16),
                  ListTile(
                    leading: Icon(
                      PhosphorIconsRegular.envelope,
                      color: theme.colorScheme.primary,
                    ),
                    title: Text(
                      'Email Support',
                      style: GoogleFonts.plusJakartaSans(
                        color: textColor,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    subtitle: Text(
                      'info@nexifydigital.com',
                      style: GoogleFonts.plusJakartaSans(
                        color: textColor.withValues(alpha: 0.7),
                      ),
                    ),
                    onTap: () {},
                  ),
                  ListTile(
                    leading: Icon(
                      PhosphorIconsRegular.phone,
                      color: theme.colorScheme.primary,
                    ),
                    title: Text(
                      'Call Us',
                      style: GoogleFonts.plusJakartaSans(
                        color: textColor,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    subtitle: Text(
                      '+91-9986459376',
                      style: GoogleFonts.plusJakartaSans(
                        color: textColor.withValues(alpha: 0.7),
                      ),
                    ),
                    onTap: () {},
                  ),
                  const SizedBox(height: 40),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Widget _buildSectionTitle(String title, Color textColor) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Text(
        title,
        style: GoogleFonts.plusJakartaSans(
          fontSize: 18,
          fontWeight: FontWeight.w700,
          color: textColor,
        ),
      ),
    );
  }

  Widget _buildSectionText(String text, Color textColor) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16.0),
      child: Text(
        text,
        style: GoogleFonts.plusJakartaSans(
          fontSize: 14,
          height: 1.5,
          color: textColor.withValues(alpha: 0.8),
        ),
      ),
    );
  }

  Widget _buildFaqItem(
    BuildContext context,
    String question,
    String answer,
    Color textColor,
    Color baseColor,
  ) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: ExpansionTile(
          tilePadding: EdgeInsets.zero,
          title: Text(
            question,
            style: GoogleFonts.plusJakartaSans(
              fontWeight: FontWeight.w600,
              color: textColor,
            ),
          ),
          children: [
            Padding(
              padding: const EdgeInsets.only(bottom: 8.0),
              child: Text(
                answer,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 14,
                  color: textColor.withValues(alpha: 0.7),
                  height: 1.4,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showEditProfileDialog(
    BuildContext context,
    WidgetRef ref,
    UserModel user,
  ) {
    final nameController = TextEditingController(text: user.fullName);
    final phoneController = TextEditingController(text: user.phone ?? '');
    final formKey = GlobalKey<FormState>();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
          title: Text(
            'Edit Profile',
            style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w800),
          ),
          content: Form(
            key: formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: nameController,
                  decoration: const InputDecoration(
                    labelText: 'Full Name',
                    prefixIcon: Icon(PhosphorIconsRegular.user),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(12)),
                    ),
                  ),
                  validator: (v) =>
                      v?.trim().isEmpty == true ? 'Name is required' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: phoneController,
                  decoration: const InputDecoration(
                    labelText: 'Phone Number',
                    prefixIcon: Icon(PhosphorIconsRegular.phone),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.all(Radius.circular(12)),
                    ),
                  ),
                  keyboardType: TextInputType.phone,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            Consumer(
              builder: (context, ref, child) {
                final isLoading = ref.watch(isLoadingProvider);
                return TextButton(
                  onPressed: isLoading
                      ? null
                      : () async {
                          if (formKey.currentState!.validate()) {
                            await ref
                                .read(authProvider.notifier)
                                .updateProfile(
                                  fullName: nameController.text.trim(),
                                  phone: phoneController.text.trim().isEmpty
                                      ? null
                                      : phoneController.text.trim(),
                                );
                            if (context.mounted) {
                              Navigator.pop(context);
                            }
                          }
                        },
                  child: isLoading
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Text('Save'),
                );
              },
            ),
          ],
        );
      },
    );
  }
}

// ── Section Label with Icon ──
class _ClaySection extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color textColor;
  final ThemeData theme;

  const _ClaySection({
    required this.label,
    required this.icon,
    required this.textColor,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        ClayIcon(
          icon: icon,
          size: 16,
          color: theme.colorScheme.primary.withValues(alpha: 0.6),
          baseColor: Theme.of(context).brightness == Brightness.dark
              ? const Color(0xFF2D2D2D)
              : const Color(0xFFDEE4EA),
          depth: 5,
          spread: 0,
          borderRadius: 8,
          padding: const EdgeInsets.all(6),
        ),
        const SizedBox(width: 8),
        Text(
          label,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 12,
            fontWeight: FontWeight.w700,
            color: textColor.withValues(alpha: 0.4),
            letterSpacing: 1.5,
          ),
        ),
      ],
    );
  }
}

// ── Theme Selector (Clay) ──
class _ClayThemeSelector extends StatelessWidget {
  final ThemeMode currentMode;
  final ValueChanged<ThemeMode> onChanged;
  final Color baseColor;
  final Color textColor;
  final ThemeData theme;
  final Color? shadowColor1;
  final Color? shadowColor2;

  const _ClayThemeSelector({
    required this.currentMode,
    required this.onChanged,
    required this.baseColor,
    required this.textColor,
    required this.theme,
    this.shadowColor1,
    this.shadowColor2,
  });

  @override
  Widget build(BuildContext context) {
    return ClayContainer(
      color: baseColor,
      borderRadius: 20,
      depth: -12,
      spread: 1,
      emboss: true,
      shadowColor1: shadowColor1,
      shadowColor2: shadowColor2,
      padding: const EdgeInsets.all(6),
      child: Row(
        children: [
          _ClayThemeOption(
            icon: PhosphorIconsFill.sun,
            label: 'Light',
            isSelected: currentMode == ThemeMode.light,
            onTap: () => onChanged(ThemeMode.light),
            baseColor: baseColor,
            textColor: textColor,
            theme: theme,
          ),
          const SizedBox(width: 6),
          _ClayThemeOption(
            icon: PhosphorIconsFill.moon,
            label: 'Dark',
            isSelected: currentMode == ThemeMode.dark,
            onTap: () => onChanged(ThemeMode.dark),
            baseColor: baseColor,
            textColor: textColor,
            theme: theme,
          ),
          const SizedBox(width: 6),
          _ClayThemeOption(
            icon: PhosphorIconsFill.circleHalf,
            label: 'System',
            isSelected: currentMode == ThemeMode.system,
            onTap: () => onChanged(ThemeMode.system),
            baseColor: baseColor,
            textColor: textColor,
            theme: theme,
          ),
        ],
      ),
    );
  }
}

class _ClayThemeOption extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  final Color baseColor;
  final Color textColor;
  final ThemeData theme;

  const _ClayThemeOption({
    required this.icon,
    required this.label,
    required this.isSelected,
    required this.onTap,
    required this.baseColor,
    required this.textColor,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: BoxDecoration(
            color: isSelected ? theme.colorScheme.primary : Colors.transparent,
            borderRadius: BorderRadius.circular(14),
            boxShadow: isSelected
                ? [
                    BoxShadow(
                      color: theme.colorScheme.primary.withValues(alpha: 0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ]
                : null,
          ),
          child: Column(
            children: [
              Icon(
                icon,
                size: 22,
                color: isSelected
                    ? Colors.white
                    : textColor.withValues(alpha: 0.5),
              ),
              const SizedBox(height: 4),
              Text(
                label,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 12,
                  fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                  color: isSelected
                      ? Colors.white
                      : textColor.withValues(alpha: 0.5),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ClaySettingsItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final Color baseColor;
  final Color textColor;
  final ThemeData theme;
  final Color? shadowColor1;
  final Color? shadowColor2;

  const _ClaySettingsItem({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    required this.baseColor,
    required this.textColor,
    required this.theme,
    this.shadowColor1,
    this.shadowColor2,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: ClayContainer(
        color: baseColor,
        borderRadius: 18,
        depth: 15,
        spread: 1,
        padding: const EdgeInsets.all(16),
        shadowColor1: shadowColor1,
        shadowColor2: shadowColor2,
        child: Row(
          children: [
            ClayIcon(
              icon: icon,
              color: theme.colorScheme.primary,
              size: 22,
              baseColor: baseColor,
              borderRadius: 14,
              depth: -10,
              spread: 0,
              emboss: true,
              padding: const EdgeInsets.all(11),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: GoogleFonts.plusJakartaSans(
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                      color: textColor,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 13,
                      color: textColor.withValues(alpha: 0.5),
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              PhosphorIconsRegular.caretRight,
              color: textColor.withValues(alpha: 0.3),
              size: 20,
            ),
          ],
        ),
      ),
    );
  }
}
