
import 'package:flutter/material.dart';

class ServiceItem {
  final String id;
  final String title;
  final String subtitle;
  final IconData icon;
  final Gradient gradient;

  ServiceItem({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.gradient,
  });
}
