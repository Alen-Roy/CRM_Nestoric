import 'package:flutter/material.dart';
import 'package:nes/features/client/model/service_item.dart';

// ignore_for_file: depend_on_referenced_packages
import 'package:phosphor_flutter/phosphor_flutter.dart';

class ServicesData {
  static final List<ServiceItem> services = [
    ServiceItem(
      id: 'website',
      title: 'Website Development',
      subtitle: 'React / Next / Flutter web',
      icon: PhosphorIcons.globe(PhosphorIconsStyle.duotone),
      gradient: const LinearGradient(
        colors: [Color(0xFFee0979), Color(0xFFff6a00)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
    ),
    ServiceItem(
      id: 'mobile',
      title: 'Mobile Application Development',
      subtitle: 'iOS / Android',
      icon: PhosphorIcons.deviceMobile(PhosphorIconsStyle.duotone),
      gradient: LinearGradient(
        colors: [Color(0xFF11998e), Color(0xFF38ef7d)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
    ),
    ServiceItem(
      id: 'seo',
      title: 'SEO',
      subtitle: 'Search Engine Optimization',
      icon: PhosphorIcons.magnifyingGlass(PhosphorIconsStyle.duotone),
      gradient: LinearGradient(
        colors: [Color(0xFF667eea), Color(0xFF764ba2)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
    ),
    ServiceItem(
      id: 'reputation',
      title: 'Online Reputation Management',
      subtitle: 'Brand reputation & monitoring',
      icon: PhosphorIcons.shieldCheck(PhosphorIconsStyle.duotone),
      gradient: LinearGradient(
        colors: [Color(0xFF6a3093), Color(0xFFa044ff)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
    ),
    ServiceItem(
      id: 'social',
      title: 'Social Media Management',
      subtitle: 'Content & engagement strategy',
      icon: PhosphorIcons.shareNetwork(PhosphorIconsStyle.duotone),
      gradient: LinearGradient(
        colors: [Color(0xFF4facfe), Color(0xFF00f2fe)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
    ),
    ServiceItem(
      id: 'marketing',
      title: 'Performance Marketing',
      subtitle: 'ROI-driven campaigns',
      icon: PhosphorIcons.chartLineUp(PhosphorIconsStyle.duotone),
      gradient: LinearGradient(
        colors: [Color(0xFFf093fb), Color(0xFFF5576c)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
    ),
  ];
}
