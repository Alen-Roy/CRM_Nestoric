// lib/features/client/models/client_models.dart

class ClientRequest {
  final String id;
  final String clientId;
  final List<String> services;
  final String description;
  final String status; // pending, assigned, in_progress, completed
  final String? assignedWorkerId;
  final String? assignedWorkerName;
  final String? assignedWorkerAvatar;
  final DateTime createdAt;
  final DateTime? deadline;
  final DateTime? updatedAt;
  final List<String>? uploadedFiles;
  final String? note;
  final String? plan; // 'basic' | 'standard' | 'premium'

  ClientRequest({
    required this.id,
    required this.clientId,
    required this.services,
    required this.description,
    required this.status,
    this.assignedWorkerId,
    this.assignedWorkerName,
    this.assignedWorkerAvatar,
    required this.createdAt,
    this.deadline,
    this.updatedAt,
    this.uploadedFiles,
    this.note,
    this.plan,
  });

  factory ClientRequest.fromJson(Map<String, dynamic> json) {
    return ClientRequest(
      id: json['_id'] ?? '',
      clientId: json['clientId'] ?? '',
      services: List<String>.from(json['services'] ?? []),
      description: json['description'] ?? '',
      status: json['status'] ?? 'pending',
      assignedWorkerId: json['assignedWorkerId'],
      assignedWorkerName: json['assignedWorkerName'],
      assignedWorkerAvatar: json['assignedWorkerAvatar'],
      createdAt: DateTime.tryParse(json['createdAt'] ?? '') ?? DateTime.now(),
      deadline: json['deadline'] != null
          ? DateTime.tryParse(json['deadline'])
          : null,
      updatedAt: json['updatedAt'] != null
          ? DateTime.tryParse(json['updatedAt'])
          : null,
      uploadedFiles: json['uploadedFiles'] != null
          ? List<String>.from(json['uploadedFiles'])
          : null,
      note: json['note'],
      plan: json['plan'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'clientId': clientId,
      'services': services,
      'description': description,
      'status': status,
      'assignedWorkerId': assignedWorkerId,
      'assignedWorkerName': assignedWorkerName,
      'assignedWorkerAvatar': assignedWorkerAvatar,
      'createdAt': createdAt.toIso8601String(),
      'deadline': deadline?.toIso8601String(),
      'updatedAt': updatedAt?.toIso8601String(),
      'uploadedFiles': uploadedFiles,
      'note': note,
    };
  }
}

class ClientStats {
  final int totalRequests;
  final int pending;
  final int inProgress;
  final int completed;

  ClientStats({
    required this.totalRequests,
    required this.pending,
    required this.inProgress,
    required this.completed,
  });

  factory ClientStats.fromJson(Map<String, dynamic> json) {
    return ClientStats(
      totalRequests: json['total'] ?? json['totalRequests'] ?? 0,
      pending: json['pending'] ?? 0,
      inProgress: json['inProgress'] ?? 0,
      completed: json['completed'] ?? 0,
    );
  }
}
