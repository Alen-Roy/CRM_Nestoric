// lib/features/worker/providers/worker_provider.dart
// ViewModel layer for the Worker feature — MVVM pattern via Riverpod.

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';
import 'package:nes/features/worker/models/worker_model.dart';
import 'package:nes/services/worker_api_service.dart';

// ─────────────────────────────────────────────
// State
// ─────────────────────────────────────────────

class WorkerState {
  final List<WorkerTask> tasks;
  final WorkerStats? stats;
  final bool isLoading;
  final String? error;
  final String
  selectedFilter; // 'all' | 'assigned' | 'in_progress' | 'completed'

  const WorkerState({
    this.tasks = const [],
    this.stats,
    this.isLoading = false,
    this.error,
    this.selectedFilter = 'all',
  });

  List<WorkerTask> get filteredTasks {
    if (selectedFilter == 'all') return tasks;
    return tasks.where((t) => t.status == selectedFilter).toList();
  }

  WorkerState copyWith({
    List<WorkerTask>? tasks,
    WorkerStats? stats,
    bool? isLoading,
    String? error,
    String? selectedFilter,
    bool clearError = false,
    bool clearStats = false,
  }) {
    return WorkerState(
      tasks: tasks ?? this.tasks,
      stats: clearStats ? null : (stats ?? this.stats),
      isLoading: isLoading ?? this.isLoading,
      error: clearError ? null : (error ?? this.error),
      selectedFilter: selectedFilter ?? this.selectedFilter,
    );
  }
}

// ─────────────────────────────────────────────
// Notifier (ViewModel)
// ─────────────────────────────────────────────

class WorkerNotifier extends StateNotifier<WorkerState> {
  final Ref _ref;

  WorkerNotifier(this._ref) : super(const WorkerState());

  String? get _token => _ref.read(authProvider).token;

  /// Load tasks and stats in parallel.
  Future<void> loadData() async {
    final token = _token;
    if (token == null) {
      state = state.copyWith(
        isLoading: false,
        error: 'Authentication required. Please log in again.',
      );
      return;
    }

    state = state.copyWith(isLoading: true, clearError: true);

    final results = await Future.wait([
      WorkerApiService.getMyTasks(token),
      WorkerApiService.getWorkerStats(token),
    ]);

    final tasksResult = results[0];
    final statsResult = results[1];

    List<WorkerTask> tasks = state.tasks;
    WorkerStats? stats = state.stats;
    String? error;

    if (tasksResult['success'] == true) {
      final raw = tasksResult['tasks'] as List;
      tasks = raw.map((t) => WorkerTask.fromJson(t)).toList();
    } else {
      error = tasksResult['error'] as String? ?? 'Failed to load tasks';
    }

    if (statsResult['success'] == true) {
      stats = WorkerStats.fromJson(statsResult['stats']);
    }

    state = state.copyWith(
      tasks: tasks,
      stats: stats,
      isLoading: false,
      error: error,
    );
  }

  /// Change the active filter tab.
  void setFilter(String filter) {
    state = state.copyWith(selectedFilter: filter, clearError: true);
  }

  /// Update a task's status. Optimistically updates local state,
  /// then syncs with the server and refreshes on success.
  Future<bool> updateTaskStatus({
    required String taskId,
    required String newStatus,
    String? note,
  }) async {
    final token = _token;
    if (token == null) return false;

    // Optimistic update
    final updatedTasks = state.tasks.map((t) {
      if (t.id == taskId) return t.copyWith(status: newStatus, note: note);
      return t;
    }).toList();
    state = state.copyWith(tasks: updatedTasks);

    final result = await WorkerApiService.updateTaskStatus(
      token: token,
      taskId: taskId,
      status: newStatus,
      note: note,
    );

    if (result['success'] == true) {
      // Refresh to get latest server state
      await loadData();
      return true;
    } else {
      // Rollback on failure
      state = state.copyWith(
        error: result['error'] as String? ?? 'Failed to update status',
      );
      await loadData();
      return false;
    }
  }

  void clearError() => state = state.copyWith(clearError: true);
}

// ─────────────────────────────────────────────
// Provider
// ─────────────────────────────────────────────

final workerProvider = StateNotifierProvider<WorkerNotifier, WorkerState>((
  ref,
) {
  final notifier = WorkerNotifier(ref);
  // Auto-load when the provider is first read.
  notifier.loadData();
  return notifier;
});
