// lib/features/worker/models/worker_models.dart

class WorkerTask {
  final String id;
  final String clientId;
  final String clientName;
  final String? clientAvatar;
  final List<String> services;
  final String description;
  final DateTime assignedAt;
  final DateTime? deadline;
  final String status; // assigned, in_progress, completed
  final List<String>? uploadedFiles;
  final String? note;
  final DateTime? updatedAt;

  WorkerTask({
    required this.id,
    required this.clientId,
    required this.clientName,
    this.clientAvatar,
    required this.services,
    required this.description,
    required this.assignedAt,
    this.deadline,
    required this.status,
    this.uploadedFiles,
    this.note,
    this.updatedAt,
  });

  factory WorkerTask.fromJson(Map<String, dynamic> json) {
    return WorkerTask(
      id: json['_id'] ?? '',
      clientId: json['clientId'] ?? '',
      clientName: json['clientName'] ?? 'Unknown',
      clientAvatar: json['clientAvatar'],
      services: List<String>.from(json['services'] ?? []),
      description: json['description'] ?? '',
      assignedAt: DateTime.tryParse(json['assignedAt'] ?? '') ?? DateTime.now(),
      deadline: json['deadline'] != null
          ? DateTime.tryParse(json['deadline'])
          : null,
      status: json['status'] ?? 'assigned',
      uploadedFiles: json['uploadedFiles'] != null
          ? List<String>.from(json['uploadedFiles'])
          : null,
      note: json['note'],
      updatedAt: json['updatedAt'] != null
          ? DateTime.tryParse(json['updatedAt'])
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'clientId': clientId,
      'clientName': clientName,
      'clientAvatar': clientAvatar,
      'services': services,
      'description': description,
      'assignedAt': assignedAt.toIso8601String(),
      'deadline': deadline?.toIso8601String(),
      'status': status,
      'uploadedFiles': uploadedFiles,
      'note': note,
      'updatedAt': updatedAt?.toIso8601String(),
    };
  }

  WorkerTask copyWith({
    String? id,
    String? clientId,
    String? clientName,
    String? clientAvatar,
    List<String>? services,
    String? description,
    DateTime? assignedAt,
    DateTime? deadline,
    String? status,
    List<String>? uploadedFiles,
    String? note,
    DateTime? updatedAt,
  }) {
    return WorkerTask(
      id: id ?? this.id,
      clientId: clientId ?? this.clientId,
      clientName: clientName ?? this.clientName,
      clientAvatar: clientAvatar ?? this.clientAvatar,
      services: services ?? this.services,
      description: description ?? this.description,
      assignedAt: assignedAt ?? this.assignedAt,
      deadline: deadline ?? this.deadline,
      status: status ?? this.status,
      uploadedFiles: uploadedFiles ?? this.uploadedFiles,
      note: note ?? this.note,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}

class WorkerStats {
  final int totalTasks;
  final int assigned;
  final int inProgress;
  final int completed;
  final double rating;

  WorkerStats({
    required this.totalTasks,
    required this.assigned,
    required this.inProgress,
    required this.completed,
    required this.rating,
  });

  factory WorkerStats.fromJson(Map<String, dynamic> json) {
    return WorkerStats(
      totalTasks: json['totalTasks'] ?? 0,
      assigned: json['assigned'] ?? 0,
      inProgress: json['inProgress'] ?? 0,
      completed: json['completed'] ?? 0,
      rating: (json['rating'] ?? 0.0).toDouble(),
    );
  }
}
