import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:nes/core/widgets/clay_container.dart';
import 'package:nes/features/worker/pages/worker_dashboard.dart';
import 'package:nes/features/worker/pages/worker_chat_list_page.dart';
import 'package:nes/features/worker/pages/worker_profile_page.dart';

class WorkerMainLayout extends StatefulWidget {
  const WorkerMainLayout({super.key});

  @override
  State<WorkerMainLayout> createState() => _WorkerMainLayoutState();
}

class _WorkerMainLayoutState extends State<WorkerMainLayout> {
  int _selectedIndex = 0;

  static final _items = [
    _NavItemData(
      PhosphorIconsFill.squaresFour,
      PhosphorIconsRegular.squaresFour,
      'Dashboard',
    ),
    _NavItemData(
      PhosphorIconsFill.chatCircleDots,
      PhosphorIconsRegular.chatCircleDots,
      'Chat',
    ),
    _NavItemData(
      PhosphorIconsFill.userCircle,
      PhosphorIconsRegular.userCircle,
      'Profile',
    ),
  ];

  late final List<Widget> _screens = const [
    WorkerDashboard(),
    WorkerChatListPage(),
    WorkerProfilePage(),
  ];

  void _onItemTapped(int index) {
    if (_selectedIndex == index) return;
    setState(() => _selectedIndex = index);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final bottomPadding = MediaQuery.of(context).padding.bottom;

    final baseColor = isDark
        ? const Color(0xFF2D2D2D)
        : const Color(0xFFDEE4EA);

    return PopScope(
      canPop: _selectedIndex == 0,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) {
          setState(() => _selectedIndex = 0);
        }
      },
      child: Scaffold(
        body: AnimatedSwitcher(
          duration: const Duration(milliseconds: 200),
          switchInCurve: Curves.easeOutCubic,
          switchOutCurve: Curves.easeInCubic,
          transitionBuilder: (child, animation) {
            return FadeTransition(opacity: animation, child: child);
          },
          child: KeyedSubtree(
            key: ValueKey(_selectedIndex),
            child: _screens[_selectedIndex],
          ),
        ),
        extendBody: true,
        bottomNavigationBar: RepaintBoundary(
          child: Padding(
            padding: EdgeInsets.fromLTRB(16, 0, 16, 12 + bottomPadding),
            child: ClayContainer(
              color: baseColor,
              borderRadius: 28,
              depth: 25,
              spread: 2,
              height: 72,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: List.generate(
                  _items.length,
                  (i) => _ClayNavItem(
                    data: _items[i],
                    isSelected: _selectedIndex == i,
                    onTap: () => _onItemTapped(i),
                    color: theme.colorScheme.primary,
                    isDark: isDark,
                    baseColor: baseColor,
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _NavItemData {
  final IconData activeIcon;
  final IconData inactiveIcon;
  final String label;

  const _NavItemData(this.activeIcon, this.inactiveIcon, this.label);
}

class _ClayNavItem extends StatelessWidget {
  final _NavItemData data;
  final bool isSelected;
  final VoidCallback onTap;
  final Color color;
  final bool isDark;
  final Color baseColor;

  const _ClayNavItem({
    required this.data,
    required this.isSelected,
    required this.onTap,
    required this.color,
    required this.isDark,
    required this.baseColor,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: SizedBox(
        width: 80,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ClayContainer(
              color: baseColor,
              borderRadius: 50,
              depth: isSelected ? -15 : 10,
              spread: 1,
              emboss: isSelected,
              width: 48,
              height: 48,
              child: Icon(
                isSelected ? data.activeIcon : data.inactiveIcon,
                color: isSelected
                    ? color
                    : (isDark ? Colors.white38 : const Color(0xFF9CA3AF)),
                size: 24,
              ),
            ),
            const SizedBox(height: 4),
            if (isSelected)
              Text(
                data.label,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  color: color,
                  letterSpacing: 0.2,
                ),
              ),
          ],
        ),
      ),
    );
  }
}
