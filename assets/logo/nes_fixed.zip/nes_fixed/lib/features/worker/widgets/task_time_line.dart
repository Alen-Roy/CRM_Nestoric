import 'package:flutter/material.dart';
import 'package:nes/features/worker/models/worker_model.dart';

class TaskTimeline extends StatelessWidget {
  final WorkerTask task;
  final String currentStatus;

  const TaskTimeline({
    super.key,
    required this.task,
    required this.currentStatus,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final steps = [
      _TimelineStep(
        title: 'Task Assigned',
        description: 'Task has been assigned to you',
        timestamp: task.assignedAt,
        isCompleted: true,
        isCurrent: currentStatus == 'assigned',
      ),
      _TimelineStep(
        title: 'Work In Progress',
        description: 'Currently working on the task',
        timestamp:
            currentStatus == 'in_progress' || currentStatus == 'completed'
            ? task.assignedAt.add(const Duration(hours: 1))
            : null,
        isCompleted:
            currentStatus == 'in_progress' || currentStatus == 'completed',
        isCurrent: currentStatus == 'in_progress',
      ),
      _TimelineStep(
        title: 'Task Completed',
        description: 'Work delivered to client',
        timestamp: currentStatus == 'completed' ? DateTime.now() : null,
        isCompleted: currentStatus == 'completed',
        isCurrent: currentStatus == 'completed',
      ),
    ];

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: theme.colorScheme.outline.withValues(alpha: 0.2)),
      ),
      child: Column(
        children: List.generate(steps.length, (index) {
          return _TimelineItem(
            step: steps[index],
            isLast: index == steps.length - 1,
            theme: theme,
          );
        }),
      ),
    );
  }
}

class _TimelineStep {
  final String title;
  final String description;
  final DateTime? timestamp;
  final bool isCompleted;
  final bool isCurrent;

  _TimelineStep({
    required this.title,
    required this.description,
    this.timestamp,
    required this.isCompleted,
    required this.isCurrent,
  });
}

class _TimelineItem extends StatelessWidget {
  final _TimelineStep step;
  final bool isLast;
  final ThemeData theme;

  const _TimelineItem({
    required this.step,
    required this.isLast,
    required this.theme,
  });

  Color _getColor() {
    if (step.isCompleted) {
      return Colors.green;
    } else if (step.isCurrent) {
      return theme.colorScheme.primary;
    } else {
      return theme.colorScheme.outline;
    }
  }

  IconData _getIcon() {
    if (step.isCompleted) {
      return Icons.check_circle_rounded;
    } else if (step.isCurrent) {
      return Icons.radio_button_checked_rounded;
    } else {
      return Icons.radio_button_unchecked_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = _getColor();
    final icon = _getIcon();

    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: step.isCompleted || step.isCurrent
                      ? color.withValues(alpha: 0.15)
                      : Colors.transparent,
                  shape: BoxShape.circle,
                  border: Border.all(color: color.withValues(alpha: 0.3), width: 2),
                ),
                child: Icon(icon, color: color, size: 24),
              ),
              if (!isLast)
                Expanded(
                  child: Container(
                    width: 2,
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          color.withValues(alpha: step.isCompleted ? 0.5 : 0.3),
                          color.withValues(alpha: 0.1),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(bottom: isLast ? 0 : 24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    step.title,
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                      color: step.isCompleted || step.isCurrent
                          ? theme.colorScheme.onSurface
                          : theme.colorScheme.onSurface.withValues(alpha: 0.5),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    step.description,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                      height: 1.4,
                    ),
                  ),
                  if (step.timestamp != null) ...[
                    const SizedBox(height: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: color.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            Icons.access_time_rounded,
                            size: 12,
                            color: color,
                          ),
                          const SizedBox(width: 6),
                          Text(
                            _formatTimestamp(step.timestamp!),
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.w600,
                              color: color,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _formatTimestamp(DateTime timestamp) {
    final hour = timestamp.hour.toString().padLeft(2, '0');
    final minute = timestamp.minute.toString().padLeft(2, '0');
    final day = timestamp.day.toString().padLeft(2, '0');
    final month = timestamp.month.toString().padLeft(2, '0');
    return '$hour:$minute • $day/$month/${timestamp.year}';
  }
}
