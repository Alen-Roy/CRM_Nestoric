import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';
import 'package:nes/services/worker_api_service.dart';
import 'package:file_picker/file_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:cached_network_image/cached_network_image.dart';

class UploadFilesSection extends ConsumerStatefulWidget {
  final String taskId;
  final List<String> uploadedFiles;
  final VoidCallback? onFilesChanged;

  const UploadFilesSection({
    super.key,
    required this.taskId,
    required this.uploadedFiles,
    this.onFilesChanged,
  });

  @override
  ConsumerState<UploadFilesSection> createState() => _UploadFilesSectionState();
}

class _UploadFilesSectionState extends ConsumerState<UploadFilesSection> {
  List<String> _localFiles = [];
  bool isUploading = false;

  @override
  void initState() {
    super.initState();
    _localFiles = List.from(widget.uploadedFiles);
  }

  @override
  void didUpdateWidget(UploadFilesSection oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.uploadedFiles != oldWidget.uploadedFiles) {
      setState(() {
        _localFiles = List.from(widget.uploadedFiles);
      });
    }
  }

  bool _isImage(String path) {
    // Basic check. Can be improved.
    // Handles URL parameters effectively by splitting "?" first.
    String filename = path.split('/').last;
    if (filename.contains('?')) {
      filename = filename.split('?').first;
    }
    final ext = filename.split('.').last.toLowerCase();
    return ['jpg', 'jpeg', 'png', 'gif', 'webp'].contains(ext);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    // Separate files
    final images = _localFiles.where(_isImage).toList();
    final documents = _localFiles.where((f) => !_isImage(f)).toList();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'Uploaded Files',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w700,
                fontSize: 20,
              ),
            ),
            TextButton.icon(
              onPressed: isUploading ? null : _showUploadOptions,
              icon: isUploading
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.add_rounded, size: 18),
              label: Text(isUploading ? 'Uploading...' : 'Add'),
              style: TextButton.styleFrom(
                foregroundColor: theme.colorScheme.primary,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),

        if (_localFiles.isEmpty)
          _buildEmptyState(theme)
        else
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (images.isNotEmpty) _buildImageGrid(images, theme),
              if (images.isNotEmpty && documents.isNotEmpty)
                const SizedBox(height: 16),
              if (documents.isNotEmpty) ...[
                if (images.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8.0),
                    child: Text(
                      'Documents',
                      style: theme.textTheme.titleSmall?.copyWith(
                        color: theme.colorScheme.onSurface.withValues(
                          alpha: 0.6,
                        ),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                _buildDocumentList(documents, theme),
              ],
            ],
          ),
      ],
    );
  }

  Widget _buildEmptyState(ThemeData theme) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
        ),
      ),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Icon(
                Icons.cloud_upload_rounded,
                size: 48,
                color: theme.colorScheme.outline.withValues(alpha: 0.3),
              ),
              const SizedBox(height: 12),
              Text(
                'No files uploaded yet',
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                ),
              ),
              const SizedBox(height: 8),
              ElevatedButton.icon(
                onPressed: isUploading ? null : _showUploadOptions,
                icon: const Icon(Icons.upload_file_rounded, size: 18),
                label: const Text('Upload Files'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: theme.colorScheme.primary,
                  foregroundColor: Colors.white,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildImageGrid(List<String> images, ThemeData theme) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
        childAspectRatio: 1.0,
      ),
      itemCount: images.length,
      itemBuilder: (context, index) {
        final url = images[index];
        return ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: Stack(
            fit: StackFit.expand,
            children: [
              GestureDetector(
                onTap: () => _openFile(url),
                child: CachedNetworkImage(
                  imageUrl: url,
                  fit: BoxFit.cover,
                  placeholder: (context, url) => Container(
                    color: theme.colorScheme.surfaceContainerHighest,
                    child: const Center(child: CircularProgressIndicator()),
                  ),
                  errorWidget: (context, url, error) => Container(
                    color: theme.colorScheme.surfaceContainerHighest,
                    child: const Icon(Icons.error),
                  ),
                ),
              ),
              Positioned(
                top: 6,
                right: 6,
                child: Material(
                  color: Colors.black.withValues(alpha: 0.5),
                  shape: const CircleBorder(),
                  child: InkWell(
                    customBorder: const CircleBorder(),
                    onTap: () => _deleteFile(url),
                    child: const Padding(
                      padding: EdgeInsets.all(6),
                      child: Icon(Icons.close, color: Colors.white, size: 16),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildDocumentList(List<String> documents, ThemeData theme) {
    return Column(
      children: documents.map((doc) => _buildDocumentItem(doc, theme)).toList(),
    );
  }

  Widget _buildDocumentItem(String fileUrl, ThemeData theme) {
    String filename = fileUrl.split('/').last;
    if (filename.contains('?')) {
      filename = filename.split('?').first;
    }

    final extension = filename.split('.').last.toUpperCase();
    final IconData fileIcon = _getFileIcon(extension);
    final Color fileColor = _getFileColor(extension);

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: fileColor.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: fileColor.withValues(alpha: 0.3)),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: fileColor.withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(fileIcon, color: fileColor, size: 24),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: InkWell(
              onTap: () => _openFile(fileUrl),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    filename,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      decoration: TextDecoration.underline,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    extension,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.download_rounded),
            onPressed: () => _openFile(fileUrl),
            color: fileColor,
            iconSize: 20,
            tooltip: 'Download/Open',
          ),
          IconButton(
            icon: const Icon(Icons.delete_outline_rounded),
            onPressed: () => _deleteFile(fileUrl),
            color: Colors.red,
            iconSize: 20,
            tooltip: 'Delete',
          ),
        ],
      ),
    );
  }

  Future<void> _openFile(String url) async {
    try {
      final uri = Uri.parse(url);
      debugPrint('Attempting to launch: $uri');

      // Try launching directly. canLaunchUrl can be flaky or require strict queries.
      // launchUrl returns true if successful.
      bool launched = false;
      try {
        launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
      } catch (e) {
        debugPrint('External launch failed: $e');
      }

      if (!launched) {
        debugPrint(
          'External launch failed or returned false. Trying platform default...',
        );
        try {
          launched = await launchUrl(uri, mode: LaunchMode.platformDefault);
        } catch (e) {
          debugPrint('Platform default launch failed: $e');
        }
      }

      if (!launched) {
        if (mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text('Could not launch URL: $url')));
        }
      }
    } catch (e) {
      debugPrint('Error processing URL: $e');
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Error opening file: $e')));
      }
    }
  }

  IconData _getFileIcon(String extension) {
    switch (extension.toLowerCase()) {
      case 'pdf':
        return Icons.picture_as_pdf_rounded;
      case 'doc':
      case 'docx':
        return Icons.description_rounded;
      case 'xls':
      case 'xlsx':
        return Icons.table_chart_rounded;
      case 'jpg':
      case 'jpeg':
      case 'png':
      case 'gif':
        return Icons.image_rounded;
      case 'zip':
      case 'rar':
        return Icons.folder_zip_rounded;
      case 'fig':
        return Icons.design_services_rounded;
      default:
        return Icons.insert_drive_file_rounded;
    }
  }

  Color _getFileColor(String extension) {
    switch (extension.toLowerCase()) {
      case 'pdf':
        return Colors.red;
      case 'doc':
      case 'docx':
        return Colors.blue;
      case 'xls':
      case 'xlsx':
        return Colors.green;
      case 'jpg':
      case 'jpeg':
      case 'png':
      case 'gif':
        return Colors.purple;
      case 'zip':
      case 'rar':
        return Colors.orange;
      case 'fig':
        return Colors.pink;
      default:
        return Colors.grey;
    }
  }

  void _showUploadOptions() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.insert_drive_file_rounded),
                title: const Text('Upload Document'),
                onTap: () {
                  Navigator.pop(context);
                  _pickAndUploadFile();
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo_library_rounded),
                title: const Text('Upload Image'),
                onTap: () {
                  Navigator.pop(context);
                  _pickAndUploadFile(type: FileType.image);
                },
              ),
              ListTile(
                leading: const Icon(Icons.attach_file_rounded),
                title: const Text('Upload Any File'),
                onTap: () {
                  Navigator.pop(context);
                  _pickAndUploadFile(type: FileType.any);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _pickAndUploadFile({FileType type = FileType.any}) async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: type,
        allowMultiple: false,
      );

      if (result == null || result.files.isEmpty) return;

      final file = result.files.first;
      if (file.bytes == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Could not read file'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }

      await _uploadFile(file.name, file.bytes!);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error picking file: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _uploadFile(String filename, List<int> fileBytes) async {
    setState(() => isUploading = true);

    final token = ref.read(authProvider).token;
    if (token == null) {
      setState(() => isUploading = false);
      return;
    }

    final result = await WorkerApiService.uploadFile(
      token: token,
      taskId: widget.taskId,
      fileName: filename,
      fileBytes: fileBytes,
    );

    if (mounted) {
      setState(() => isUploading = false);

      if (result['success']) {
        setState(() {
          _localFiles.add(filename);
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('$filename uploaded successfully'),
            backgroundColor: Colors.green,
          ),
        );

        widget.onFilesChanged?.call();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(result['error'] ?? 'Failed to upload file'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _deleteFile(String fileUrl) {
    // Extract filename from URL for display and API logic usually needs exact filename
    String filename = fileUrl.split('/').last;
    if (filename.contains('?')) {
      filename = filename.split('?').first;
    }

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Text('Delete File'),
        content: Text('Are you sure you want to delete $filename?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);

              final token = ref.read(authProvider).token;
              if (token == null) return;

              final result = await WorkerApiService.deleteFile(
                token: token,
                taskId: widget.taskId,
                fileName: filename,
              );

              if (mounted) {
                if (result['success']) {
                  setState(() {
                    _localFiles.remove(fileUrl);
                  });
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('File deleted successfully')),
                  );
                  widget.onFilesChanged?.call();
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(result['error'] ?? 'Failed to delete file'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              }
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
  }
}
