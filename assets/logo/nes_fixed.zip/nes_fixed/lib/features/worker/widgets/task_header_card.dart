import 'package:flutter/material.dart';
import 'package:nes/features/worker/models/worker_model.dart';

class TaskHeaderCard extends StatelessWidget {
  final WorkerTask task;
  final String currentStatus;

  const TaskHeaderCard({
    super.key,
    required this.task,
    required this.currentStatus,
  });

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'completed':
        return Colors.green;
      case 'assigned':
        return Colors.blue;
      case 'in_progress':
        return Colors.purple;
      default:
        return Colors.grey;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'completed':
        return Icons.check_circle_rounded;
      case 'assigned':
        return Icons.assignment_rounded;
      case 'in_progress':
        return Icons.trending_up_rounded;
      default:
        return Icons.info_rounded;
    }
  }

  String _formatDate(DateTime? date) {
    if (date == null) return 'No deadline';
    final now = DateTime.now();
    final difference = date.difference(now);

    if (difference.isNegative) {
      return 'Overdue by ${-difference.inDays} days';
    } else if (difference.inDays == 0) {
      return 'Due today';
    } else if (difference.inDays == 1) {
      return 'Due tomorrow';
    } else {
      return 'Due in ${difference.inDays} days';
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final statusColor = _getStatusColor(currentStatus);
    final statusIcon = _getStatusIcon(currentStatus);
    final isOverdue =
        task.deadline != null && task.deadline!.isBefore(DateTime.now());

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [statusColor.withValues(alpha: 0.1), statusColor.withValues(alpha: 0.05)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: statusColor.withValues(alpha: 0.3), width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: statusColor,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(statusIcon, color: Colors.white, size: 24),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      currentStatus[0].toUpperCase() +
                          currentStatus.substring(1).replaceAll('_', ' '),
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                        color: statusColor,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(
                          Icons.calendar_today_rounded,
                          size: 14,
                          color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                        ),
                        const SizedBox(width: 6),
                        Text(
                          'Assigned ${_formatAssignedDate(task.assignedAt)}',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Divider(color: statusColor.withValues(alpha: 0.2), thickness: 1),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildInfoItem(
                icon: Icons.access_time_rounded,
                label: 'Deadline',
                value: _formatDate(task.deadline),
                theme: theme,
                color: isOverdue ? Colors.red : null,
              ),
              Container(
                height: 40,
                width: 1,
                color: theme.colorScheme.outline.withValues(alpha: 0.2),
              ),
              _buildInfoItem(
                icon: Icons.upload_file_rounded,
                label: 'Uploaded',
                value: '${task.uploadedFiles?.length ?? 0} files',
                theme: theme,
              ),
              Container(
                height: 40,
                width: 1,
                color: theme.colorScheme.outline.withValues(alpha: 0.2),
              ),
              _buildInfoItem(
                icon: Icons.priority_high_rounded,
                label: 'Priority',
                value: _getPriority(),
                theme: theme,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildInfoItem({
    required IconData icon,
    required String label,
    required String value,
    required ThemeData theme,
    Color? color,
  }) {
    return Column(
      children: [
        Icon(icon, size: 20, color: color ?? theme.colorScheme.primary),
        const SizedBox(height: 6),
        Text(
          value,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w700,
            color: color ?? theme.colorScheme.onSurface,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: theme.textTheme.bodySmall?.copyWith(
            color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
            fontSize: 11,
          ),
        ),
      ],
    );
  }

  String _formatAssignedDate(DateTime date) {
    final difference = DateTime.now().difference(date);
    if (difference.inDays == 0) {
      return 'today';
    } else if (difference.inDays == 1) {
      return 'yesterday';
    } else if (difference.inDays < 7) {
      return '${difference.inDays} days ago';
    } else {
      return '${date.day}/${date.month}/${date.year}';
    }
  }

  String _getPriority() {
    if (task.deadline == null) return 'Normal';
    final daysUntilDeadline = task.deadline!.difference(DateTime.now()).inDays;
    if (daysUntilDeadline < 0) return 'Overdue';
    if (daysUntilDeadline <= 2) return 'Urgent';
    if (daysUntilDeadline <= 7) return 'High';
    return 'Normal';
  }
}
