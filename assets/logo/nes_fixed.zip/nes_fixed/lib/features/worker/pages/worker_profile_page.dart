import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:nes/core/providers/theme_provider.dart';
import 'package:nes/core/widgets/clay_container.dart';
import 'package:nes/features/auth/presentation/login_signup.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';
import 'package:nes/services/app_info_service.dart';

class WorkerProfilePage extends ConsumerWidget {
  const WorkerProfilePage({super.key});

  Future<void> _logout(BuildContext context, WidgetRef ref) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) {
        final theme = Theme.of(context);
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
          title: Text(
            'Logout',
            style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w800),
          ),
          content: const Text('Are you sure you want to logout?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context, true),
              style: TextButton.styleFrom(
                foregroundColor: theme.colorScheme.error,
              ),
              child: const Text('Logout'),
            ),
          ],
        );
      },
    );

    if (confirm == true && context.mounted) {
      await ref.read(authProvider.notifier).logout();
      if (context.mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LoginSignup()),
          (route) => false,
        );
      }
    }
  }

  /// Gradient divider
  Widget _buildDivider(Color dividerColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 20),
      child: Container(
        height: 1,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              dividerColor.withValues(alpha: 0),
              dividerColor,
              dividerColor,
              dividerColor.withValues(alpha: 0),
            ],
            stops: const [0.0, 0.2, 0.8, 1.0],
          ),
        ),
      ),
    );
  }

  /// Section header with icon
  Widget _buildSectionHeader(
    String title,
    IconData icon,
    Color textColor,
    ThemeData theme,
  ) {
    return Row(
      children: [
        Icon(
          icon,
          size: 16,
          color: theme.colorScheme.primary.withValues(alpha: 0.6),
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 12,
            fontWeight: FontWeight.w700,
            color: textColor.withValues(alpha: 0.4),
            letterSpacing: 1.2,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final user = ref.watch(currentUserProvider);
    final themeMode = ref.watch(themeModeProvider);

    final baseColor = isDark
        ? const Color(0xFF2D2D2D)
        : const Color(0xFFDEE4EA);
    final textColor = isDark ? Colors.white70 : const Color(0xFF485057);
    final dividerColor = isDark
        ? Colors.white.withValues(alpha: 0.06)
        : Colors.black.withValues(alpha: 0.06);

    return Scaffold(
      backgroundColor: baseColor,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 100),
          physics: const BouncingScrollPhysics(),
          children: [
            // ── Title ──
            Text(
              'My Profile',
              style: GoogleFonts.plusJakartaSans(
                fontSize: 28,
                fontWeight: FontWeight.w800,
                color: textColor,
                letterSpacing: -0.5,
              ),
            ),

            _buildDivider(dividerColor),

            // ── Avatar + Info Card ──
            ClayContainer(
              color: baseColor,
              borderRadius: 24,
              depth: 20,
              spread: 2,
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  ClayContainer(
                    color: baseColor,
                    borderRadius: 34,
                    depth: 15,
                    spread: 1,
                    width: 68,
                    height: 68,
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            theme.colorScheme.primary,
                            theme.colorScheme.primary.withValues(alpha: 0.7),
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        shape: BoxShape.circle,
                      ),
                      child: user?.avatarUrl != null
                          ? ClipOval(
                              child: CachedNetworkImage(
                                imageUrl: user!.avatarUrl!,
                                fit: BoxFit.cover,
                                width: 68,
                                height: 68,
                                placeholder: (_, __) => const Center(
                                  child: SizedBox(
                                    width: 24,
                                    height: 24,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      color: Colors.white70,
                                    ),
                                  ),
                                ),
                                errorWidget: (_, __, ___) => const Icon(
                                  PhosphorIconsFill.user,
                                  color: Colors.white,
                                  size: 30,
                                ),
                              ),
                            )
                          : const Icon(
                              PhosphorIconsFill.user,
                              color: Colors.white,
                              size: 30,
                            ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          user?.fullName ?? 'Worker',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                            color: textColor,
                            letterSpacing: -0.3,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          user?.email ?? '',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 13,
                            color: textColor.withValues(alpha: 0.5),
                          ),
                        ),
                        if (user?.workerProfile?.rating != null) ...[
                          const SizedBox(height: 6),
                          Row(
                            children: [
                              Icon(
                                PhosphorIconsFill.star,
                                size: 16,
                                color: Colors.amber.shade600,
                              ),
                              const SizedBox(width: 4),
                              Text(
                                '${user!.workerProfile!.rating.toStringAsFixed(1)} Rating',
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.amber.shade600,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // ── Stats Row ──
            Row(
              children: [
                Expanded(
                  child: _ClayStatChip(
                    icon: PhosphorIconsFill.briefcase,
                    label: 'Active',
                    value: '${user?.workerProfile?.activeProjects ?? 0}',
                    color: Colors.orange,
                    baseColor: baseColor,
                    textColor: textColor,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _ClayStatChip(
                    icon: PhosphorIconsFill.checkCircle,
                    label: 'Done',
                    value: '${user?.workerProfile?.completedProjects ?? 0}',
                    color: Colors.green,
                    baseColor: baseColor,
                    textColor: textColor,
                  ),
                ),
              ],
            ),

            // ── Skills ──
            if (user?.workerProfile?.skills?.isNotEmpty ?? false) ...[
              _buildDivider(dividerColor),
              _buildSectionHeader(
                'SKILLS',
                PhosphorIconsRegular.code,
                textColor,
                theme,
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: user!.workerProfile!.skills!.map((skill) {
                  return ClayContainer(
                    color: theme.colorScheme.primary,
                    borderRadius: 12,
                    depth: 10,
                    spread: 1,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 8,
                    ),
                    child: Text(
                      skill,
                      style: GoogleFonts.plusJakartaSans(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 13,
                      ),
                    ),
                  );
                }).toList(),
              ),
            ],

            _buildDivider(dividerColor),

            // ── Appearance ──
            _buildSectionHeader(
              'APPEARANCE',
              PhosphorIconsRegular.palette,
              textColor,
              theme,
            ),
            const SizedBox(height: 12),
            _ClayThemeSelector(
              currentMode: themeMode,
              onChanged: (mode) {
                ref.read(themeModeProvider.notifier).setThemeMode(mode);
              },
              baseColor: baseColor,
              textColor: textColor,
              theme: theme,
            ),

            _buildDivider(dividerColor),

            // ── General ──
            _buildSectionHeader(
              'GENERAL',
              PhosphorIconsRegular.gear,
              textColor,
              theme,
            ),
            const SizedBox(height: 12),
            _ClaySettingsItem(
              icon: PhosphorIconsRegular.info,
              title: 'About Nexify',
              subtitle: 'Version ${AppInfoService.version}',
              onTap: () {
                showAboutDialog(
                  context: context,
                  applicationName: 'Nexify',
                  applicationVersion: AppInfoService.version,
                  applicationIcon: Container(
                    width: 56,
                    height: 56,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          theme.colorScheme.primary,
                          theme.colorScheme.primary.withValues(alpha: 0.7),
                        ],
                      ),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Icon(
                      PhosphorIconsFill.buildings,
                      color: Colors.white,
                      size: 28,
                    ),
                  ),
                );
              },
              baseColor: baseColor,
              textColor: textColor,
              theme: theme,
            ),

            _buildDivider(dividerColor),

            // ── Logout ──
            Material(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(18),
              child: InkWell(
                onTap: () => _logout(context, ref),
                borderRadius: BorderRadius.circular(18),
                splashColor: Colors.redAccent.withValues(alpha: 0.1),
                highlightColor: Colors.redAccent.withValues(alpha: 0.05),
                child: ClayContainer(
                  color: baseColor,
                  borderRadius: 18,
                  depth: 15,
                  spread: 1,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(
                        PhosphorIconsRegular.signOut,
                        color: Colors.redAccent,
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'Logout',
                        style: GoogleFonts.plusJakartaSans(
                          color: Colors.redAccent,
                          fontWeight: FontWeight.w700,
                          fontSize: 15,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Helper Widgets ──

class _ClayStatChip extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  final Color baseColor;
  final Color textColor;

  const _ClayStatChip({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
    required this.baseColor,
    required this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    return ClayContainer(
      color: baseColor,
      borderRadius: 18,
      depth: 15,
      spread: 1,
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Icon(icon, color: color, size: 26),
          const SizedBox(width: 12),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: color,
                ),
              ),
              Text(
                label,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 12,
                  color: textColor.withValues(alpha: 0.5),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _ClayThemeSelector extends StatelessWidget {
  final ThemeMode currentMode;
  final ValueChanged<ThemeMode> onChanged;
  final Color baseColor;
  final Color textColor;
  final ThemeData theme;

  const _ClayThemeSelector({
    required this.currentMode,
    required this.onChanged,
    required this.baseColor,
    required this.textColor,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return ClayContainer(
      color: baseColor,
      borderRadius: 18,
      depth: -8,
      spread: 1,
      emboss: true,
      padding: const EdgeInsets.all(6),
      child: Row(
        children: [
          _ClayThemeOption(
            icon: PhosphorIconsRegular.sun,
            label: 'Light',
            isSelected: currentMode == ThemeMode.light,
            onTap: () => onChanged(ThemeMode.light),
            baseColor: baseColor,
            textColor: textColor,
            theme: theme,
          ),
          _ClayThemeOption(
            icon: PhosphorIconsRegular.moon,
            label: 'Dark',
            isSelected: currentMode == ThemeMode.dark,
            onTap: () => onChanged(ThemeMode.dark),
            baseColor: baseColor,
            textColor: textColor,
            theme: theme,
          ),
          _ClayThemeOption(
            icon: PhosphorIconsRegular.monitor,
            label: 'System',
            isSelected: currentMode == ThemeMode.system,
            onTap: () => onChanged(ThemeMode.system),
            baseColor: baseColor,
            textColor: textColor,
            theme: theme,
          ),
        ],
      ),
    );
  }
}

class _ClayThemeOption extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  final Color baseColor;
  final Color textColor;
  final ThemeData theme;

  const _ClayThemeOption({
    required this.icon,
    required this.label,
    required this.isSelected,
    required this.onTap,
    required this.baseColor,
    required this.textColor,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? theme.colorScheme.primary : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: [
              Icon(
                icon,
                size: 20,
                color: isSelected
                    ? Colors.white
                    : textColor.withValues(alpha: 0.5),
              ),
              const SizedBox(height: 4),
              Text(
                label,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 12,
                  fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                  color: isSelected
                      ? Colors.white
                      : textColor.withValues(alpha: 0.5),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ClaySettingsItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  final Color baseColor;
  final Color textColor;
  final ThemeData theme;

  const _ClaySettingsItem({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
    required this.baseColor,
    required this.textColor,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: ClayContainer(
        color: baseColor,
        borderRadius: 18,
        depth: 15,
        spread: 1,
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            ClayContainer(
              color: baseColor,
              borderRadius: 12,
              depth: -8,
              spread: 0,
              emboss: true,
              width: 40,
              height: 40,
              child: Icon(icon, color: theme.colorScheme.primary, size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: GoogleFonts.plusJakartaSans(
                      fontWeight: FontWeight.w700,
                      fontSize: 15,
                      color: textColor,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 13,
                      color: textColor.withValues(alpha: 0.45),
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              PhosphorIconsRegular.caretRight,
              color: textColor.withValues(alpha: 0.25),
              size: 18,
            ),
          ],
        ),
      ),
    );
  }
}
