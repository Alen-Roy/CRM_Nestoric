import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:nes/core/widgets/clay_container.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';
import 'package:nes/features/worker/pages/worker_chat_page.dart';

import 'package:nes/services/worker_api_service.dart';
import 'package:nes/features/worker/models/worker_model.dart';

class WorkerChatListPage extends ConsumerStatefulWidget {
  const WorkerChatListPage({super.key});

  @override
  ConsumerState<WorkerChatListPage> createState() => _WorkerChatListPageState();
}

class _WorkerChatListPageState extends ConsumerState<WorkerChatListPage> {
  bool _isLoading = true;
  List<WorkerTask> _tasks = [];
  String? _error;

  @override
  void initState() {
    super.initState();
    _loadChats();
  }

  Future<void> _loadChats() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final token = ref.read(authProvider).token;
      if (token == null) {
        setState(() => _error = 'Not authenticated');
        return;
      }

      final result = await WorkerApiService.getMyTasks(token);

      if (mounted) {
        if (result['success']) {
          setState(() {
            _tasks = (result['tasks'] as List)
                .map((t) => WorkerTask.fromJson(t))
                .toList();
            _isLoading = false;
          });
        } else {
          setState(() {
            _error = result['error'];
            _isLoading = false;
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _error = 'Failed to load chats: $e';
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    final baseColor = isDark
        ? const Color(0xFF2D2D2D)
        : const Color(0xFFDEE4EA);
    final textColor = isDark ? Colors.white70 : const Color(0xFF485057);

    return Scaffold(
      backgroundColor: baseColor,
      body: SafeArea(
        child: Column(
          children: [
            // ── Header ──
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 16, 20, 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Messages',
                    style: GoogleFonts.plusJakartaSans(
                      fontWeight: FontWeight.w800,
                      fontSize: 28,
                      color: textColor,
                      letterSpacing: -0.5,
                    ),
                  ),
                  ClayContainer(
                    color: baseColor,
                    borderRadius: 16,
                    depth: 15,
                    spread: 1,
                    width: 40,
                    height: 40,
                    child: IconButton(
                      icon: Icon(
                        PhosphorIconsRegular.arrowsClockwise,
                        size: 18,
                        color: textColor,
                      ),
                      onPressed: _loadChats,
                    ),
                  ),
                ],
              ),
            ),

            // ── Body ──
            Expanded(
              child: _isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : _error != null
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            PhosphorIconsRegular.warningCircle,
                            size: 48,
                            color: Colors.redAccent,
                          ),
                          const SizedBox(height: 16),
                          Text(
                            _error!,
                            style: GoogleFonts.plusJakartaSans(
                              color: Colors.redAccent,
                            ),
                          ),
                        ],
                      ),
                    )
                  : _tasks.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            PhosphorIconsRegular.chatCircleDots,
                            size: 64,
                            color: textColor.withValues(alpha: 0.2),
                          ),
                          const SizedBox(height: 16),
                          Text(
                            'No active chats',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 16,
                              color: textColor.withValues(alpha: 0.4),
                            ),
                          ),
                        ],
                      ),
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 20,
                        vertical: 8,
                      ),
                      physics: const BouncingScrollPhysics(),
                      itemCount: _tasks.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (context, index) {
                        final task = _tasks[index];
                        return _buildChatTile(
                          context,
                          task,
                          theme,
                          baseColor,
                          textColor,
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildChatTile(
    BuildContext context,
    WorkerTask task,
    ThemeData theme,
    Color baseColor,
    Color textColor,
  ) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => WorkerChatPage(
              taskId: task.id,
              clientName: task.clientName,
              clientAvatar: task.clientAvatar,
            ),
          ),
        );
      },
      child: ClayContainer(
        color: baseColor,
        depth: 15,
        borderRadius: 20,
        spread: 1,
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            // ── Avatar ──
            ClayContainer(
              color: baseColor,
              borderRadius: 25,
              depth: 12,
              spread: 1,
              width: 50,
              height: 50,
              child: Container(
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [
                      theme.colorScheme.primary,
                      theme.colorScheme.primary.withValues(alpha: 0.7),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  image: task.clientAvatar != null
                      ? DecorationImage(
                          image: NetworkImage(task.clientAvatar!),
                          fit: BoxFit.cover,
                        )
                      : null,
                ),
                child: task.clientAvatar == null
                    ? Center(
                        child: Text(
                          task.clientName.substring(0, 1).toUpperCase(),
                          style: GoogleFonts.plusJakartaSans(
                            fontWeight: FontWeight.w700,
                            fontSize: 20,
                            color: Colors.white,
                          ),
                        ),
                      )
                    : null,
              ),
            ),
            const SizedBox(width: 16),

            // ── Info ──
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    task.clientName,
                    style: GoogleFonts.plusJakartaSans(
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                      color: textColor,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    task.services.isNotEmpty
                        ? task.services.first
                        : 'Service Request',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 13,
                      color: textColor.withValues(alpha: 0.45),
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),

            const SizedBox(width: 12),

            Icon(
              PhosphorIconsRegular.caretRight,
              size: 16,
              color: textColor.withValues(alpha: 0.25),
            ),
          ],
        ),
      ),
    );
  }
}
