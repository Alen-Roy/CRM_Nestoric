import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:nes/core/widgets/clay_container.dart';

import 'package:nes/features/worker/pages/task_detail_page.dart';
import 'package:nes/features/worker/providers/worker_provider.dart';
import 'package:nes/features/worker/widgets/worker_task_card.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';

class WorkerDashboard extends ConsumerStatefulWidget {
  const WorkerDashboard({super.key});

  @override
  ConsumerState<WorkerDashboard> createState() => _WorkerDashboardState();
}

class _WorkerDashboardState extends ConsumerState<WorkerDashboard> {
  // No local state — all state lives in workerProvider (ViewModel).

  /// Gradient divider
  Widget _buildDivider(Color dividerColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Container(
        height: 1,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              dividerColor.withValues(alpha: 0),
              dividerColor,
              dividerColor,
              dividerColor.withValues(alpha: 0),
            ],
            stops: const [0.0, 0.2, 0.8, 1.0],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final user = ref.watch(currentUserProvider);

    // ── Read state from ViewModel ──
    final workerState = ref.watch(workerProvider);
    final notifier = ref.read(workerProvider.notifier);
    final isLoading = workerState.isLoading;
    final filteredTasks = workerState.filteredTasks;
    final allTasks = workerState.tasks;
    final stats = workerState.stats;
    final selectedFilter = workerState.selectedFilter;

    final baseColor = isDark
        ? const Color(0xFF2D2D2D)
        : const Color(0xFFDEE4EA);
    final textColor = isDark ? Colors.white70 : const Color(0xFF485057);
    final dividerColor = isDark
        ? Colors.white.withValues(alpha: 0.06)
        : Colors.black.withValues(alpha: 0.06);
    final shadowColor1 = isDark
        ? Colors.black.withValues(alpha: 0.4)
        : Colors.black.withValues(alpha: 0.12);
    final shadowColor2 = isDark
        ? Colors.white.withValues(alpha: 0.04)
        : Colors.white.withValues(alpha: 0.7);

    return Scaffold(
      backgroundColor: baseColor,
      body: SafeArea(
        bottom: false,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
              child: Column(
                children: [
                  // ── Greeting + Avatar ──
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Welcome back,',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 15,
                                fontWeight: FontWeight.w500,
                                color: textColor.withValues(alpha: 0.6),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              user?.fullName ?? 'Worker',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 28,
                                fontWeight: FontWeight.w800,
                                color: theme.colorScheme.primary,
                                letterSpacing: -0.8,
                              ),
                            ),
                          ],
                        ),
                      ),
                      ClayContainer(
                        color: baseColor,
                        borderRadius: 20,
                        depth: 20,
                        spread: 1,
                        width: 52,
                        height: 52,
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                theme.colorScheme.primary,
                                theme.colorScheme.primary.withValues(
                                  alpha: 0.7,
                                ),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            shape: BoxShape.circle,
                          ),
                          child: user?.avatarUrl != null
                              ? ClipOval(
                                  child: Image.network(
                                    user!.avatarUrl!,
                                    fit: BoxFit.cover,
                                    width: 52,
                                    height: 52,
                                    errorBuilder: (_, __, ___) => const Icon(
                                      PhosphorIconsFill.user,
                                      color: Colors.white,
                                      size: 24,
                                    ),
                                  ),
                                )
                              : const Icon(
                                  PhosphorIconsFill.user,
                                  color: Colors.white,
                                  size: 24,
                                ),
                        ),
                      ),
                    ],
                  ),

                  _buildDivider(dividerColor),

                  // ── Stats ──
                  if (isLoading)
                    const Center(
                      child: Padding(
                        padding: EdgeInsets.all(40),
                        child: CircularProgressIndicator(),
                      ),
                    )
                  else
                    Column(
                      children: [
                        Row(
                          children: [
                            _ClayStatTile(
                              label: 'Total',
                              value: '${allTasks.length}',
                              icon: PhosphorIconsRegular.briefcase,
                              baseColor: baseColor,
                              textColor: textColor,
                              shadowColor1: shadowColor1,
                              shadowColor2: shadowColor2,
                              theme: theme,
                              onTap: () => notifier.setFilter('all'),
                            ),
                            const SizedBox(width: 12),
                            _ClayStatTile(
                              label: 'Assigned',
                              value:
                                  '${allTasks.where((t) => t.status == 'assigned').length}',
                              icon: PhosphorIconsFill.clipboardText,
                              baseColor: baseColor,
                              textColor: textColor,
                              shadowColor1: shadowColor1,
                              shadowColor2: shadowColor2,
                              theme: theme,
                              onTap: () => notifier.setFilter('assigned'),
                            ),
                            const SizedBox(width: 12),
                            _ClayStatTile(
                              label: 'Progress',
                              value:
                                  '${allTasks.where((t) => t.status == 'in_progress').length}',
                              icon: PhosphorIconsFill.trendUp,
                              baseColor: baseColor,
                              textColor: textColor,
                              shadowColor1: shadowColor1,
                              shadowColor2: shadowColor2,
                              theme: theme,
                              onTap: () => notifier.setFilter('in_progress'),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            _ClayStatTile(
                              label: 'Completed',
                              value:
                                  '${allTasks.where((t) => t.status == 'completed').length}',
                              icon: PhosphorIconsFill.checkCircle,
                              baseColor: baseColor,
                              textColor: textColor,
                              shadowColor1: shadowColor1,
                              shadowColor2: shadowColor2,
                              theme: theme,
                              onTap: () => notifier.setFilter('completed'),
                            ),
                            const SizedBox(width: 12),
                            _ClayStatTile(
                              label: 'Rating',
                              value: (stats?.rating ?? 0.0).toStringAsFixed(1),
                              icon: PhosphorIconsFill.star,
                              baseColor: baseColor,
                              textColor: textColor,
                              shadowColor1: shadowColor1,
                              shadowColor2: shadowColor2,
                              theme: theme,
                              onTap: () {},
                            ),
                          ],
                        ),
                      ],
                    ),
                  const SizedBox(height: 16),
                ],
              ),
            ),

            _buildDivider(dividerColor),

            // ── "My Tasks" Header ──
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Icon(
                        PhosphorIconsRegular.listChecks,
                        size: 20,
                        color: theme.colorScheme.primary.withValues(alpha: 0.7),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        'My Tasks',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                          color: textColor,
                          letterSpacing: -0.3,
                        ),
                      ),
                    ],
                  ),
                  ClayContainer(
                    color: baseColor,
                    borderRadius: 16,
                    depth: 15,
                    spread: 1,
                    width: 40,
                    height: 40,
                    child: IconButton(
                      icon: Icon(
                        PhosphorIconsRegular.arrowsClockwise,
                        size: 18,
                        color: textColor,
                      ),
                      onPressed: notifier.loadData,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),

            // ── Filter Chips ──
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: _buildFilterChips(theme, baseColor, textColor),
            ),
            const SizedBox(height: 12),

            // ── Task List ──
            Expanded(
              child: isLoading
                  ? const Center(child: CircularProgressIndicator())
                  : filteredTasks.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            PhosphorIconsRegular.tray,
                            size: 70,
                            color: textColor.withValues(alpha: 0.2),
                          ),
                          const SizedBox(height: 16),
                          Text(
                            selectedFilter == 'all'
                                ? 'No tasks assigned yet'
                                : 'No ${selectedFilter.replaceAll('_', ' ')} tasks',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 16,
                              color: textColor.withValues(alpha: 0.4),
                            ),
                          ),
                        ],
                      ),
                    )
                  : ListView.separated(
                      physics: const BouncingScrollPhysics(),
                      padding: const EdgeInsets.fromLTRB(24, 6, 24, 100),
                      itemCount: filteredTasks.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (context, index) {
                        final task = filteredTasks[index];
                        return WorkerTaskCard(
                          task: task,
                          onTap: () async {
                            await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => TaskDetailPage(task: task),
                              ),
                            );
                            // Refresh after returning from detail page
                            notifier.loadData();
                          },
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChips(ThemeData theme, Color baseColor, Color textColor) {
    final notifier = ref.read(workerProvider.notifier);
    final selectedFilter = ref.watch(workerProvider).selectedFilter;
    final filters = [
      {'value': 'all', 'label': 'All', 'icon': PhosphorIconsRegular.list},
      {
        'value': 'assigned',
        'label': 'Assigned',
        'icon': PhosphorIconsFill.clipboardText,
      },
      {
        'value': 'in_progress',
        'label': 'In Progress',
        'icon': PhosphorIconsFill.trendUp,
      },
      {
        'value': 'completed',
        'label': 'Completed',
        'icon': PhosphorIconsFill.checkCircle,
      },
    ];

    return SizedBox(
      height: 42,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: filters.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final filter = filters[index];
          final isSelected = selectedFilter == filter['value'];

          return GestureDetector(
            onTap: () => notifier.setFilter(filter['value'] as String),
            child: ClayContainer(
              color: isSelected ? theme.colorScheme.primary : baseColor,
              borderRadius: 14,
              depth: isSelected ? 15 : 10,
              spread: 1,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    filter['icon'] as IconData,
                    size: 16,
                    color: isSelected
                        ? Colors.white
                        : theme.colorScheme.primary,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    filter['label'] as String,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: isSelected ? Colors.white : textColor,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ── Clay Stat Tile ──
class _ClayStatTile extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color baseColor;
  final Color textColor;
  final Color shadowColor1;
  final Color shadowColor2;
  final ThemeData theme;
  final VoidCallback onTap;

  const _ClayStatTile({
    required this.label,
    required this.value,
    required this.icon,
    required this.baseColor,
    required this.textColor,
    required this.shadowColor1,
    required this.shadowColor2,
    required this.theme,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: ClayContainer(
          color: baseColor,
          borderRadius: 20,
          depth: 18,
          spread: 1,
          shadowColor1: shadowColor1,
          shadowColor2: shadowColor2,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(
                icon,
                size: 20,
                color: theme.colorScheme.primary.withValues(alpha: 0.8),
              ),
              const SizedBox(height: 8),
              Text(
                value,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                  color: theme.colorScheme.primary,
                  letterSpacing: -0.5,
                ),
              ),
              Text(
                label,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: textColor.withValues(alpha: 0.5),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
