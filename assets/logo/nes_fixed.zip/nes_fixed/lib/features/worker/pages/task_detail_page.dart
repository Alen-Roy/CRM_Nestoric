import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:nes/core/widgets/clay_container.dart';
import 'package:nes/features/worker/models/worker_model.dart';
import 'package:nes/features/worker/pages/worker_chat_page.dart';
import 'package:nes/features/worker/widgets/client_info_card.dart';
import 'package:nes/features/worker/widgets/task_header_card.dart';
import 'package:nes/features/worker/widgets/task_time_line.dart';
import 'package:nes/features/worker/widgets/upload_file_section.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';
import 'package:nes/services/worker_api_service.dart';

class TaskDetailPage extends ConsumerStatefulWidget {
  final WorkerTask task;

  const TaskDetailPage({super.key, required this.task});

  @override
  ConsumerState<TaskDetailPage> createState() => _TaskDetailPageState();
}

class _TaskDetailPageState extends ConsumerState<TaskDetailPage> {
  late String _currentStatus;
  late WorkerTask _currentTask;
  bool isUpdating = false;

  @override
  void initState() {
    super.initState();
    _currentStatus = widget.task.status;
    _currentTask = widget.task;
  }

  /// Gradient divider
  Widget _buildDivider(Color dividerColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 18),
      child: Container(
        height: 1,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              dividerColor.withValues(alpha: 0),
              dividerColor,
              dividerColor,
              dividerColor.withValues(alpha: 0),
            ],
            stops: const [0.0, 0.2, 0.8, 1.0],
          ),
        ),
      ),
    );
  }

  /// Section header with icon
  Widget _buildSectionHeader(
    String title,
    IconData icon,
    Color textColor,
    ThemeData theme,
  ) {
    return Row(
      children: [
        Icon(
          icon,
          size: 18,
          color: theme.colorScheme.primary.withValues(alpha: 0.7),
        ),
        const SizedBox(width: 8),
        Text(
          title,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: textColor,
            letterSpacing: -0.3,
          ),
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    final baseColor = isDark
        ? const Color(0xFF2D2D2D)
        : const Color(0xFFDEE4EA);
    final textColor = isDark ? Colors.white70 : const Color(0xFF485057);
    final dividerColor = isDark
        ? Colors.white.withValues(alpha: 0.06)
        : Colors.black.withValues(alpha: 0.06);

    return Scaffold(
      backgroundColor: baseColor,
      body: SafeArea(
        child: Column(
          children: [
            // ── Header ──
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: Row(
                children: [
                  ClayContainer(
                    color: baseColor,
                    borderRadius: 22,
                    depth: 20,
                    spread: 1,
                    width: 44,
                    height: 44,
                    child: IconButton(
                      icon: Icon(
                        PhosphorIconsRegular.caretLeft,
                        size: 22,
                        color: textColor,
                      ),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Text(
                      'Task #${_currentTask.id.substring(_currentTask.id.length - 6).toUpperCase()}',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                        color: textColor,
                        letterSpacing: -0.5,
                      ),
                    ),
                  ),
                  ClayContainer(
                    color: baseColor,
                    borderRadius: 22,
                    depth: 20,
                    spread: 1,
                    width: 44,
                    height: 44,
                    child: IconButton(
                      icon: Icon(
                        PhosphorIconsRegular.dotsThreeVertical,
                        size: 22,
                        color: textColor,
                      ),
                      onPressed: () => _showOptionsMenu(context),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // ── Content ──
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Header Card
                      TaskHeaderCard(
                        task: _currentTask,
                        currentStatus: _currentStatus,
                      ),

                      const SizedBox(height: 20),

                      // Client Info
                      ClientInfoCard(
                        clientName: _currentTask.clientName,
                        clientAvatar:
                            _currentTask.clientAvatar ??
                            'https://ui-avatars.com/api/?name=${Uri.encodeComponent(_currentTask.clientName)}',
                        onMessageTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => WorkerChatPage(
                                taskId: _currentTask.id,
                                clientName: _currentTask.clientName,
                                clientAvatar:
                                    _currentTask.clientAvatar ??
                                    'https://ui-avatars.com/api/?name=${Uri.encodeComponent(_currentTask.clientName)}',
                              ),
                            ),
                          );
                        },
                      ),

                      _buildDivider(dividerColor),

                      // Progress Timeline
                      _buildSectionHeader(
                        'Progress Timeline',
                        PhosphorIconsRegular.clockCounterClockwise,
                        textColor,
                        theme,
                      ),
                      const SizedBox(height: 16),
                      TaskTimeline(
                        task: _currentTask,
                        currentStatus: _currentStatus,
                      ),

                      _buildDivider(dividerColor),

                      // Description
                      _buildDescriptionSection(
                        theme,
                        baseColor,
                        textColor,
                        dividerColor,
                      ),

                      _buildDivider(dividerColor),

                      // Services
                      _buildServicesSection(theme, baseColor, textColor),

                      _buildDivider(dividerColor),

                      // Upload Files Section
                      UploadFilesSection(
                        taskId: _currentTask.id,
                        uploadedFiles: _currentTask.uploadedFiles ?? [],
                        onFilesChanged: () {
                          setState(() {});
                        },
                      ),

                      // Notes section
                      if (_currentTask.note != null &&
                          _currentTask.note!.isNotEmpty) ...[
                        _buildDivider(dividerColor),
                        _buildNotesSection(theme, baseColor, textColor),
                      ],

                      const SizedBox(height: 100),
                    ],
                  ),
                ),
              ),
            ),

            // Bottom action buttons
            _buildBottomActionBar(theme, baseColor, textColor),
          ],
        ),
      ),
    );
  }

  Widget _buildDescriptionSection(
    ThemeData theme,
    Color baseColor,
    Color textColor,
    Color dividerColor,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader(
          'Task Description',
          PhosphorIconsRegular.textAlignLeft,
          textColor,
          theme,
        ),
        const SizedBox(height: 12),
        ClayContainer(
          color: baseColor,
          borderRadius: 18,
          depth: -10,
          spread: 1,
          emboss: true,
          padding: const EdgeInsets.all(16),
          child: Text(
            _currentTask.description,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 14,
              height: 1.6,
              color: textColor,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildServicesSection(
    ThemeData theme,
    Color baseColor,
    Color textColor,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildSectionHeader(
          'Services Required',
          PhosphorIconsRegular.briefcase,
          textColor,
          theme,
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          runSpacing: 8,
          children: _currentTask.services.map((service) {
            return ClayContainer(
              color: theme.colorScheme.primary,
              borderRadius: 14,
              depth: 10,
              spread: 1,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Icon(
                    PhosphorIconsFill.checkCircle,
                    color: Colors.white,
                    size: 16,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    service,
                    style: GoogleFonts.plusJakartaSans(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildNotesSection(ThemeData theme, Color baseColor, Color textColor) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _buildSectionHeader(
              'My Notes',
              PhosphorIconsRegular.notepad,
              textColor,
              theme,
            ),
            ClayContainer(
              color: baseColor,
              borderRadius: 14,
              depth: 12,
              spread: 1,
              width: 36,
              height: 36,
              child: IconButton(
                icon: Icon(
                  PhosphorIconsRegular.pencilSimple,
                  size: 16,
                  color: textColor,
                ),
                onPressed: () => _showAddNoteDialog(context),
                padding: EdgeInsets.zero,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ClayContainer(
          color: baseColor,
          borderRadius: 16,
          depth: -8,
          spread: 1,
          emboss: true,
          padding: const EdgeInsets.all(16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(
                PhosphorIconsFill.note,
                color: theme.colorScheme.primary,
                size: 20,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  _currentTask.note!,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 14,
                    color: textColor,
                    height: 1.6,
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildBottomActionBar(
    ThemeData theme,
    Color baseColor,
    Color textColor,
  ) {
    return SafeArea(
      top: false,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
        child: Row(
          children: [
            if (_currentStatus != 'completed') ...[
              Expanded(
                child: GestureDetector(
                  onTap: isUpdating
                      ? null
                      : () => _showStatusUpdateDialog(context),
                  child: ClayContainer(
                    color: baseColor,
                    borderRadius: 18,
                    depth: 20,
                    spread: 1,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        isUpdating
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                ),
                              )
                            : Icon(
                                PhosphorIconsRegular.arrowsClockwise,
                                size: 18,
                                color: theme.colorScheme.primary,
                              ),
                        const SizedBox(width: 8),
                        Text(
                          isUpdating ? 'Updating...' : 'Update',
                          style: GoogleFonts.plusJakartaSans(
                            fontWeight: FontWeight.w700,
                            fontSize: 14,
                            color: theme.colorScheme.primary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
            ],
            Expanded(
              child: GestureDetector(
                onTap: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => WorkerChatPage(
                        taskId: _currentTask.id,
                        clientName: _currentTask.clientName,
                        clientAvatar:
                            _currentTask.clientAvatar ??
                            'https://ui-avatars.com/api/?name=${Uri.encodeComponent(_currentTask.clientName)}',
                      ),
                    ),
                  );
                },
                child: ClayContainer(
                  color: baseColor,
                  borderRadius: 18,
                  depth: 25,
                  spread: 2,
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          theme.colorScheme.primary,
                          theme.colorScheme.primary.withValues(alpha: 0.8),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(18),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(
                          PhosphorIconsFill.chatCircle,
                          size: 18,
                          color: Colors.white,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          'Chat',
                          style: GoogleFonts.plusJakartaSans(
                            fontWeight: FontWeight.w700,
                            fontSize: 14,
                            color: Colors.white,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showStatusUpdateDialog(BuildContext context) {
    final statuses = [
      {
        'value': 'assigned',
        'label': 'Assigned',
        'icon': PhosphorIconsFill.clipboardText,
      },
      {
        'value': 'in_progress',
        'label': 'In Progress',
        'icon': PhosphorIconsFill.trendUp,
      },
      {
        'value': 'completed',
        'label': 'Completed',
        'icon': PhosphorIconsFill.checkCircle,
      },
    ];

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Text(
          'Update Task Status',
          style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w800),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: statuses.map((status) {
            return RadioListTile<String>(
              title: Row(
                children: [
                  Icon(
                    status['icon'] as IconData,
                    size: 20,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                  const SizedBox(width: 12),
                  Text(
                    status['label'] as String,
                    style: GoogleFonts.plusJakartaSans(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
              value: status['value'] as String,
              groupValue: _currentStatus,
              onChanged: (value) {
                Navigator.pop(context);
                if (value != null) {
                  _updateStatus(value);
                }
              },
            );
          }).toList(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
        ],
      ),
    );
  }

  Future<void> _updateStatus(String newStatus) async {
    setState(() => isUpdating = true);

    final token = ref.read(authProvider).token;
    if (token == null) {
      setState(() => isUpdating = false);
      return;
    }

    final result = await WorkerApiService.updateTaskStatus(
      token: token,
      taskId: _currentTask.id,
      status: newStatus,
    );

    if (mounted) {
      setState(() => isUpdating = false);

      if (result['success']) {
        setState(() {
          _currentStatus = newStatus;
          _currentTask = _currentTask.copyWith(
            status: newStatus,
            updatedAt: DateTime.now(),
          );
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Status updated to ${newStatus.replaceAll('_', ' ')}',
              style: GoogleFonts.plusJakartaSans(color: Colors.white),
            ),
            backgroundColor: Colors.green,
            behavior: SnackBarBehavior.floating,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(14),
            ),
          ),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(result['error'] ?? 'Failed to update status'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _showOptionsMenu(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: Icon(
                  PhosphorIconsRegular.notePencil,
                  color: Theme.of(context).colorScheme.primary,
                ),
                title: Text(
                  _currentTask.note != null ? 'Edit Note' : 'Add Note',
                  style: GoogleFonts.plusJakartaSans(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                onTap: () {
                  Navigator.pop(context);
                  _showAddNoteDialog(context);
                },
              ),
              ListTile(
                leading: Icon(
                  PhosphorIconsRegular.calendarBlank,
                  color: Theme.of(context).colorScheme.primary,
                ),
                title: Text(
                  'View Deadline',
                  style: GoogleFonts.plusJakartaSans(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                onTap: () {
                  Navigator.pop(context);
                  _showDeadlineInfo();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showAddNoteDialog(BuildContext context) {
    final noteController = TextEditingController(text: _currentTask.note);
    bool isSaving = false;

    showDialog(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
          title: Text(
            'Add Note',
            style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w800),
          ),
          content: TextField(
            controller: noteController,
            maxLines: 4,
            style: GoogleFonts.plusJakartaSans(fontSize: 14),
            decoration: InputDecoration(
              hintText: 'Enter your notes...',
              hintStyle: GoogleFonts.plusJakartaSans(fontSize: 14),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: isSaving ? null : () => Navigator.pop(context),
              child: const Text('Cancel'),
            ),
            TextButton(
              onPressed: isSaving
                  ? null
                  : () async {
                      final note = noteController.text.trim();
                      if (note.isEmpty) {
                        Navigator.pop(context);
                        return;
                      }

                      setDialogState(() => isSaving = true);

                      final token = ref.read(authProvider).token;
                      if (token == null) {
                        setDialogState(() => isSaving = false);
                        return;
                      }

                      final result = await WorkerApiService.updateTaskNote(
                        token: token,
                        taskId: _currentTask.id,
                        note: note,
                      );

                      if (mounted) {
                        Navigator.pop(context);

                        if (result['success']) {
                          setState(() {
                            _currentTask = _currentTask.copyWith(note: note);
                          });
                          ScaffoldMessenger.of(this.context).showSnackBar(
                            SnackBar(
                              content: Text(
                                'Note saved successfully',
                                style: GoogleFonts.plusJakartaSans(
                                  color: Colors.white,
                                ),
                              ),
                              backgroundColor: Colors.green,
                              behavior: SnackBarBehavior.floating,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(14),
                              ),
                            ),
                          );
                        } else {
                          ScaffoldMessenger.of(this.context).showSnackBar(
                            SnackBar(
                              content: Text(
                                result['error'] ?? 'Failed to save note',
                              ),
                              backgroundColor: Colors.red,
                            ),
                          );
                        }
                      }
                    },
              child: isSaving
                  ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Text('Save'),
            ),
          ],
        ),
      ),
    );
  }

  void _showDeadlineInfo() {
    final deadline = _currentTask.deadline;
    final message = deadline == null
        ? 'No deadline set for this task'
        : 'Deadline: ${deadline.day}/${deadline.month}/${deadline.year}';

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Text(
          'Deadline Information',
          style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w800),
        ),
        content: Text(message, style: GoogleFonts.plusJakartaSans()),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }
}
