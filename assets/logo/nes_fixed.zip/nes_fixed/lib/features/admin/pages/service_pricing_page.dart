import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:nes/core/theme/app_colors.dart';
import 'package:nes/core/widgets/clay_container.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';
import 'package:nes/services/admin_api_service.dart';

// ── Data model for a single service price ──
class ServicePrice {
  final String id;
  final String serviceName;
  double price;
  bool isActive;

  ServicePrice({
    required this.id,
    required this.serviceName,
    required this.price,
    required this.isActive,
  });

  factory ServicePrice.fromJson(Map<String, dynamic> json) => ServicePrice(
    id: json['_id'] ?? '',
    serviceName: json['serviceName'] ?? '',
    price: (json['price'] ?? 0).toDouble(),
    isActive: json['isActive'] ?? true,
  );
}

// ── Data model for a plan tier ──
class PlanTierData {
  final String tierId; // 'basic' | 'standard' | 'premium'
  final String label;
  final String emoji;
  double multiplier;
  List<String> perks;
  final Color color;

  PlanTierData({
    required this.tierId,
    required this.label,
    required this.emoji,
    required this.multiplier,
    required this.perks,
    required this.color,
  });

  factory PlanTierData.fromJson(Map<String, dynamic> json) {
    Color parseColor(String hex) {
      final h = hex.replaceAll('#', '');
      return Color(int.parse('FF$h', radix: 16));
    }

    return PlanTierData(
      tierId: json['tierId'] as String,
      label: json['label'] as String,
      emoji: json['emoji'] as String,
      multiplier: (json['multiplier'] as num).toDouble(),
      perks: (json['perks'] as List<dynamic>?)?.cast<String>() ?? [],
      color: parseColor(json['color'] as String? ?? '#68D391'),
    );
  }
}

class ServicePricingPage extends ConsumerStatefulWidget {
  const ServicePricingPage({super.key});

  @override
  ConsumerState<ServicePricingPage> createState() => _ServicePricingPageState();
}

class _ServicePricingPageState extends ConsumerState<ServicePricingPage>
    with SingleTickerProviderStateMixin {
  // ── Tab controller ──
  late TabController _tabController;

  // ── Services tab state ──
  List<ServicePrice> _services = [];
  bool _isLoading = true;
  bool _isSaving = false;
  String? _error;

  // ── Plan tiers tab state ──
  List<PlanTierData> _tiers = [];
  bool _tiersLoading = true;
  bool _tierSaving = false;
  String? _tiersError;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadPrices();
    _loadTiers();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  // ════════════════════════════════════════
  // SERVICES TAB — data loading / actions
  // ════════════════════════════════════════

  Future<void> _loadPrices() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });
    final token = ref.read(authProvider).token ?? '';
    final result = await AdminApiService.getAllServicePrices(token);
    if (result['success']) {
      final list = result['prices'] as List;
      setState(() {
        _services = list.map((e) => ServicePrice.fromJson(e)).toList();
        _isLoading = false;
      });
    } else {
      setState(() {
        _error = result['error'];
        _isLoading = false;
      });
    }
  }

  Future<void> _updatePrice(ServicePrice service, double newPrice) async {
    setState(() => _isSaving = true);
    final token = ref.read(authProvider).token ?? '';
    final result = await AdminApiService.updateServicePrice(
      token: token,
      serviceId: service.id,
      price: newPrice,
    );
    if (result['success']) {
      setState(() => service.price = newPrice);
      _showSnack(
        '${service.serviceName} updated to ₹${newPrice.toStringAsFixed(0)}',
      );
    } else {
      _showSnack(result['error'] ?? 'Update failed', isError: true);
    }
    setState(() => _isSaving = false);
  }

  Future<void> _toggleActive(ServicePrice service) async {
    setState(() => _isSaving = true);
    final token = ref.read(authProvider).token ?? '';
    final newIsActive = !service.isActive;
    final result = await AdminApiService.updateServicePrice(
      token: token,
      serviceId: service.id,
      isActive: newIsActive,
    );
    if (result['success']) {
      setState(() => service.isActive = newIsActive);
      _showSnack(
        newIsActive
            ? '${service.serviceName} is now active'
            : '${service.serviceName} hidden from clients',
      );
    } else {
      _showSnack(result['error'] ?? 'Update failed', isError: true);
    }
    setState(() => _isSaving = false);
  }

  Future<void> _deleteService(ServicePrice service) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(
          'Delete Service',
          style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w800),
        ),
        content: Text(
          'Remove "${service.serviceName}" permanently?',
          style: GoogleFonts.plusJakartaSans(),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(
              'Delete',
              style: GoogleFonts.plusJakartaSans(color: AppColors.error),
            ),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    setState(() => _isSaving = true);
    final token = ref.read(authProvider).token ?? '';
    final result = await AdminApiService.deleteServicePrice(
      token: token,
      serviceId: service.id,
    );
    if (result['success']) {
      setState(() => _services.removeWhere((s) => s.id == service.id));
      _showSnack('${service.serviceName} deleted');
    } else {
      _showSnack(result['error'] ?? 'Delete failed', isError: true);
    }
    setState(() => _isSaving = false);
  }

  void _showAddServiceDialog() {
    final nameController = TextEditingController();
    final priceController = TextEditingController();
    final formKey = GlobalKey<FormState>();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          'Add New Service',
          style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w800),
        ),
        content: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: nameController,
                decoration: InputDecoration(
                  labelText: 'Service Name',
                  labelStyle: GoogleFonts.plusJakartaSans(),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                style: GoogleFonts.plusJakartaSans(),
                validator: (v) =>
                    v == null || v.trim().isEmpty ? 'Required' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: priceController,
                keyboardType: TextInputType.number,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: InputDecoration(
                  labelText: 'Price (₹)',
                  prefixText: '₹ ',
                  labelStyle: GoogleFonts.plusJakartaSans(),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                style: GoogleFonts.plusJakartaSans(),
                validator: (v) =>
                    v == null || v.trim().isEmpty ? 'Required' : null,
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: GoogleFonts.plusJakartaSans()),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            onPressed: () async {
              if (!formKey.currentState!.validate()) return;
              Navigator.pop(context);
              setState(() => _isSaving = true);
              final token = ref.read(authProvider).token ?? '';
              final result = await AdminApiService.addServicePrice(
                token: token,
                serviceName: nameController.text.trim(),
                price: double.parse(priceController.text.trim()),
              );
              if (result['success']) {
                final newService = ServicePrice.fromJson(result['pricing']);
                setState(() => _services.add(newService));
                _showSnack('${newService.serviceName} added');
              } else {
                _showSnack(result['error'] ?? 'Failed', isError: true);
              }
              setState(() => _isSaving = false);
            },
            child: Text(
              'Add',
              style: GoogleFonts.plusJakartaSans(
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showEditPriceDialog(ServicePrice service) {
    final controller = TextEditingController(
      text: service.price.toStringAsFixed(0),
    );
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          service.serviceName,
          style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w800),
        ),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          inputFormatters: [FilteringTextInputFormatter.digitsOnly],
          autofocus: true,
          decoration: InputDecoration(
            labelText: 'New Price (₹)',
            prefixText: '₹ ',
            labelStyle: GoogleFonts.plusJakartaSans(),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          ),
          style: GoogleFonts.plusJakartaSans(
            fontSize: 20,
            fontWeight: FontWeight.w700,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancel', style: GoogleFonts.plusJakartaSans()),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
            ),
            onPressed: () {
              final val = double.tryParse(controller.text);
              if (val == null || val < 0) return;
              Navigator.pop(context);
              _updatePrice(service, val);
            },
            child: Text(
              'Save',
              style: GoogleFonts.plusJakartaSans(
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ════════════════════════════════════════
  // PLAN TIERS TAB — data loading / actions
  // ════════════════════════════════════════

  Future<void> _loadTiers() async {
    setState(() {
      _tiersLoading = true;
      _tiersError = null;
    });
    final result = await AdminApiService.getPlanTiers();
    if (result['success']) {
      final list = result['tiers'] as List;
      setState(() {
        _tiers = list.map((e) => PlanTierData.fromJson(e)).toList();
        _tiersLoading = false;
      });
    } else {
      setState(() {
        _tiersError = result['error'];
        _tiersLoading = false;
      });
    }
  }

  void _showEditTierSheet(PlanTierData tier) {
    final multiplierController = TextEditingController(
      text: tier.multiplier.toStringAsFixed(1),
    );
    final perkControllers = tier.perks
        .map((p) => TextEditingController(text: p))
        .toList();
    // We use a StatefulBuilder so we can add/remove perk rows inside the sheet
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setSheetState) {
            final theme = Theme.of(ctx);
            final isDark = theme.brightness == Brightness.dark;
            final sheetColor = isDark
                ? const Color(0xFF2D2D2D)
                : const Color(0xFFF0F4F8);

            return Padding(
              padding: EdgeInsets.only(
                bottom: MediaQuery.of(ctx).viewInsets.bottom,
              ),
              child: Container(
                decoration: BoxDecoration(
                  color: sheetColor,
                  borderRadius: const BorderRadius.vertical(
                    top: Radius.circular(28),
                  ),
                ),
                padding: const EdgeInsets.fromLTRB(24, 16, 24, 32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Handle
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        decoration: BoxDecoration(
                          color: theme.colorScheme.onSurface.withValues(
                            alpha: 0.15,
                          ),
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),
                    // Title row
                    Row(
                      children: [
                        Text(tier.emoji, style: const TextStyle(fontSize: 28)),
                        const SizedBox(width: 12),
                        Text(
                          'Edit ${tier.label} Plan',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 20,
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),

                    // Multiplier field
                    Text(
                      'Price Multiplier',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 13,
                        fontWeight: FontWeight.w600,
                        color: theme.colorScheme.onSurface.withValues(
                          alpha: 0.6,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: multiplierController,
                      keyboardType: const TextInputType.numberWithOptions(
                        decimal: true,
                      ),
                      decoration: InputDecoration(
                        prefixText: '×',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        hintText: 'e.g. 1.5',
                        hintStyle: GoogleFonts.plusJakartaSans(),
                      ),
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Perks section
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          'Perks / Features',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: theme.colorScheme.onSurface.withValues(
                              alpha: 0.6,
                            ),
                          ),
                        ),
                        TextButton.icon(
                          onPressed: () {
                            setSheetState(() {
                              perkControllers.add(TextEditingController());
                            });
                          },
                          icon: Icon(
                            PhosphorIconsRegular.plus,
                            size: 14,
                            color: tier.color,
                          ),
                          label: Text(
                            'Add Perk',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: tier.color,
                            ),
                          ),
                          style: TextButton.styleFrom(
                            padding: EdgeInsets.zero,
                            tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    ConstrainedBox(
                      constraints: const BoxConstraints(maxHeight: 200),
                      child: SingleChildScrollView(
                        child: Column(
                          children: perkControllers.asMap().entries.map((
                            entry,
                          ) {
                            final i = entry.key;
                            final c = entry.value;
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: Row(
                                children: [
                                  Icon(
                                    PhosphorIconsRegular.checkCircle,
                                    size: 14,
                                    color: tier.color,
                                  ),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: TextField(
                                      controller: c,
                                      decoration: InputDecoration(
                                        hintText: 'Perk description',
                                        hintStyle: GoogleFonts.plusJakartaSans(
                                          fontSize: 13,
                                        ),
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(
                                            10,
                                          ),
                                        ),
                                        contentPadding:
                                            const EdgeInsets.symmetric(
                                              horizontal: 12,
                                              vertical: 10,
                                            ),
                                      ),
                                      style: GoogleFonts.plusJakartaSans(
                                        fontSize: 13,
                                      ),
                                    ),
                                  ),
                                  const SizedBox(width: 8),
                                  IconButton(
                                    icon: Icon(
                                      PhosphorIconsRegular.trash,
                                      size: 16,
                                      color: AppColors.error.withValues(
                                        alpha: 0.7,
                                      ),
                                    ),
                                    onPressed: () {
                                      setSheetState(() {
                                        perkControllers.removeAt(i);
                                      });
                                    },
                                    padding: EdgeInsets.zero,
                                    constraints: const BoxConstraints(
                                      minWidth: 32,
                                      minHeight: 32,
                                    ),
                                  ),
                                ],
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                    const SizedBox(height: 20),

                    // Save button
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: tier.color,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                          ),
                        ),
                        onPressed: () async {
                          final multiplierVal = double.tryParse(
                            multiplierController.text.trim(),
                          );
                          if (multiplierVal == null || multiplierVal < 0.1) {
                            _showSnack(
                              'Multiplier must be at least 0.1',
                              isError: true,
                            );
                            return;
                          }
                          final perks = perkControllers
                              .map((c) => c.text.trim())
                              .where((t) => t.isNotEmpty)
                              .toList();

                          Navigator.pop(ctx);
                          setState(() => _tierSaving = true);
                          final token = ref.read(authProvider).token ?? '';
                          final result = await AdminApiService.updatePlanTier(
                            token: token,
                            tierId: tier.tierId,
                            multiplier: multiplierVal,
                            perks: perks,
                          );
                          if (result['success']) {
                            setState(() {
                              tier.multiplier = multiplierVal;
                              tier.perks = perks;
                            });
                            _showSnack('${tier.label} plan updated');
                          } else {
                            _showSnack(
                              result['error'] ?? 'Failed to update',
                              isError: true,
                            );
                          }
                          setState(() => _tierSaving = false);
                        },
                        child: Text(
                          'Save Changes',
                          style: GoogleFonts.plusJakartaSans(
                            fontWeight: FontWeight.w700,
                            fontSize: 15,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ════════════════════════════════════════
  // SHARED
  // ════════════════════════════════════════

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          msg,
          style: GoogleFonts.plusJakartaSans(color: Colors.white),
        ),
        backgroundColor: isError ? AppColors.error : AppColors.success,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final baseColor = isDark
        ? const Color(0xFF2D2D2D)
        : const Color(0xFFDEE4EA);
    final textColor = isDark ? Colors.white70 : const Color(0xFF485057);

    return Scaffold(
      backgroundColor: baseColor,
      body: SafeArea(
        child: Column(
          children: [
            // ── Header ──────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
              child: Row(
                children: [
                  ClayContainer(
                    color: baseColor,
                    borderRadius: 22,
                    depth: 20,
                    spread: 1,
                    width: 44,
                    height: 44,
                    child: IconButton(
                      icon: Icon(
                        PhosphorIconsRegular.caretLeft,
                        size: 22,
                        color: textColor,
                      ),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Pricing Manager',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 22,
                            fontWeight: FontWeight.w800,
                            color: textColor,
                            letterSpacing: -0.5,
                          ),
                        ),
                        Text(
                          'Services & plan tiers',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 12,
                            color: textColor.withValues(alpha: 0.5),
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Add service button (only on Services tab)
                  AnimatedBuilder(
                    animation: _tabController,
                    builder: (_, __) => _tabController.index == 0
                        ? ClayContainer(
                            color: baseColor,
                            borderRadius: 22,
                            depth: 20,
                            spread: 1,
                            width: 44,
                            height: 44,
                            child: IconButton(
                              icon: Icon(
                                PhosphorIconsRegular.plus,
                                size: 22,
                                color: theme.colorScheme.primary,
                              ),
                              onPressed: _showAddServiceDialog,
                              tooltip: 'Add new service',
                            ),
                          )
                        : const SizedBox(width: 44),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 12),

            // ── Tab bar ──────────────────────────────
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: ClayContainer(
                color: baseColor,
                depth: 8,
                spread: 1,
                borderRadius: 16,
                padding: const EdgeInsets.all(4),
                child: TabBar(
                  controller: _tabController,
                  indicator: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        theme.colorScheme.primary,
                        theme.colorScheme.primary.withValues(alpha: 0.8),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(13),
                  ),
                  indicatorSize: TabBarIndicatorSize.tab,
                  dividerColor: Colors.transparent,
                  labelStyle: GoogleFonts.plusJakartaSans(
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  ),
                  unselectedLabelStyle: GoogleFonts.plusJakartaSans(
                    fontWeight: FontWeight.w500,
                    fontSize: 13,
                  ),
                  labelColor: Colors.white,
                  unselectedLabelColor: textColor.withValues(alpha: 0.6),
                  tabs: const [
                    Tab(text: 'Services'),
                    Tab(text: 'Plan Tiers'),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 8),

            // ── Tab views ────────────────────────────
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: [
                  _buildServicesTab(baseColor, textColor, theme),
                  _buildPlanTiersTab(baseColor, textColor, theme),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════ SERVICES TAB ═══════════════

  Widget _buildServicesTab(Color baseColor, Color textColor, ThemeData theme) {
    return Column(
      children: [
        // Summary bar
        if (!_isLoading && _services.isNotEmpty)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
            child: ClayContainer(
              color: baseColor,
              depth: 10,
              spread: 1,
              borderRadius: 14,
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Row(
                children: [
                  Icon(
                    PhosphorIconsRegular.tag,
                    size: 16,
                    color: theme.colorScheme.primary,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    '${_services.where((s) => s.isActive).length} active services',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: textColor,
                    ),
                  ),
                  const Spacer(),
                  if (_isSaving)
                    SizedBox(
                      width: 14,
                      height: 14,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: theme.colorScheme.primary,
                      ),
                    ),
                ],
              ),
            ),
          ),

        Expanded(
          child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _error != null
              ? _buildError(_error!, _loadPrices, textColor, theme)
              : _services.isEmpty
              ? _buildEmpty(
                  'No services yet',
                  'Tap + to add your first service',
                  PhosphorIconsRegular.tag,
                  textColor,
                )
              : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
                  itemCount: _services.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (_, i) => _buildServiceCard(
                    _services[i],
                    baseColor,
                    textColor,
                    theme,
                  ),
                ),
        ),
      ],
    );
  }

  Widget _buildServiceCard(
    ServicePrice service,
    Color baseColor,
    Color textColor,
    ThemeData theme,
  ) {
    return ClayContainer(
      color: baseColor,
      depth: service.isActive ? 14 : 6,
      spread: 1,
      borderRadius: 18,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Container(
              width: 10,
              height: 10,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: service.isActive
                    ? AppColors.success
                    : textColor.withValues(alpha: 0.25),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    service.serviceName,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: service.isActive
                          ? textColor
                          : textColor.withValues(alpha: 0.4),
                    ),
                  ),
                  if (!service.isActive)
                    Text(
                      'Hidden from clients',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 11,
                        color: AppColors.error.withValues(alpha: 0.7),
                      ),
                    ),
                ],
              ),
            ),
            GestureDetector(
              onTap: _isSaving ? null : () => _showEditPriceDialog(service),
              child: Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 14,
                  vertical: 8,
                ),
                decoration: BoxDecoration(
                  color: theme.colorScheme.primary.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: theme.colorScheme.primary.withValues(alpha: 0.3),
                    width: 1,
                  ),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      '₹${service.price.toStringAsFixed(0)}',
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                        color: theme.colorScheme.primary,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Icon(
                      PhosphorIconsRegular.pencilSimple,
                      size: 13,
                      color: theme.colorScheme.primary.withValues(alpha: 0.7),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 8),
            PopupMenuButton<String>(
              icon: Icon(
                PhosphorIconsRegular.dotsThreeVertical,
                size: 20,
                color: textColor.withValues(alpha: 0.5),
              ),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              onSelected: (val) {
                if (val == 'toggle') _toggleActive(service);
                if (val == 'delete') _deleteService(service);
                if (val == 'edit') _showEditPriceDialog(service);
              },
              itemBuilder: (_) => [
                PopupMenuItem(
                  value: 'edit',
                  child: Row(
                    children: [
                      Icon(
                        PhosphorIconsRegular.pencilSimple,
                        size: 16,
                        color: AppColors.primary,
                      ),
                      const SizedBox(width: 10),
                      Text('Edit Price', style: GoogleFonts.plusJakartaSans()),
                    ],
                  ),
                ),
                PopupMenuItem(
                  value: 'toggle',
                  child: Row(
                    children: [
                      Icon(
                        service.isActive
                            ? PhosphorIconsRegular.eyeSlash
                            : PhosphorIconsRegular.eye,
                        size: 16,
                        color: service.isActive
                            ? AppColors.warning
                            : AppColors.success,
                      ),
                      const SizedBox(width: 10),
                      Text(
                        service.isActive ? 'Hide from clients' : 'Make active',
                        style: GoogleFonts.plusJakartaSans(),
                      ),
                    ],
                  ),
                ),
                PopupMenuItem(
                  value: 'delete',
                  child: Row(
                    children: [
                      Icon(
                        PhosphorIconsRegular.trash,
                        size: 16,
                        color: AppColors.error,
                      ),
                      const SizedBox(width: 10),
                      Text(
                        'Delete',
                        style: GoogleFonts.plusJakartaSans(
                          color: AppColors.error,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ═══════════════ PLAN TIERS TAB ═══════════════

  Widget _buildPlanTiersTab(Color baseColor, Color textColor, ThemeData theme) {
    if (_tiersLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (_tiersError != null) {
      return _buildError(_tiersError!, _loadTiers, textColor, theme);
    }
    if (_tiers.isEmpty) {
      return _buildEmpty(
        'No tiers found',
        'Try reloading',
        PhosphorIconsRegular.star,
        textColor,
      );
    }

    return Column(
      children: [
        if (_tierSaving)
          LinearProgressIndicator(
            color: theme.colorScheme.primary,
            backgroundColor: theme.colorScheme.primary.withValues(alpha: 0.1),
          ),
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
            itemCount: _tiers.length,
            separatorBuilder: (_, __) => const SizedBox(height: 16),
            itemBuilder: (_, i) =>
                _buildTierCard(_tiers[i], baseColor, textColor, theme),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 16),
          child: Text(
            'Changes take effect immediately for all clients',
            textAlign: TextAlign.center,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 12,
              color: textColor.withValues(alpha: 0.4),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildTierCard(
    PlanTierData tier,
    Color baseColor,
    Color textColor,
    ThemeData theme,
  ) {
    return ClayContainer(
      color: baseColor,
      depth: 18,
      spread: 1,
      borderRadius: 22,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: tier.color.withValues(alpha: 0.25),
            width: 1.5,
          ),
        ),
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Title row
            Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: tier.color.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Center(
                    child: Text(
                      tier.emoji,
                      style: const TextStyle(fontSize: 24),
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        tier.label,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          color: textColor,
                        ),
                      ),
                      Container(
                        margin: const EdgeInsets.only(top: 4),
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: tier.color.withValues(alpha: 0.15),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Text(
                          '×${tier.multiplier % 1 == 0 ? tier.multiplier.toStringAsFixed(0) : tier.multiplier.toStringAsFixed(1)} price multiplier',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 12,
                            fontWeight: FontWeight.w700,
                            color: tier.color,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                OutlinedButton.icon(
                  onPressed: _tierSaving
                      ? null
                      : () => _showEditTierSheet(tier),
                  style: OutlinedButton.styleFrom(
                    side: BorderSide(color: tier.color.withValues(alpha: 0.5)),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 10,
                    ),
                  ),
                  icon: Icon(
                    PhosphorIconsRegular.pencilSimple,
                    size: 14,
                    color: tier.color,
                  ),
                  label: Text(
                    'Edit',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: tier.color,
                    ),
                  ),
                ),
              ],
            ),

            if (tier.perks.isNotEmpty) ...[
              const SizedBox(height: 16),
              Divider(color: tier.color.withValues(alpha: 0.15)),
              const SizedBox(height: 10),
              // Perks list
              ...tier.perks.map(
                (perk) => Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Row(
                    children: [
                      Icon(
                        PhosphorIconsRegular.checkCircle,
                        size: 13,
                        color: tier.color,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        perk,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 13,
                          color: textColor.withValues(alpha: 0.75),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  // ═══════════════ SHARED WIDGETS ═══════════════

  Widget _buildError(
    String error,
    VoidCallback onRetry,
    Color textColor,
    ThemeData theme,
  ) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            PhosphorIconsRegular.wifiSlash,
            size: 48,
            color: textColor.withValues(alpha: 0.3),
          ),
          const SizedBox(height: 16),
          Text(
            error,
            style: GoogleFonts.plusJakartaSans(
              color: textColor.withValues(alpha: 0.5),
            ),
          ),
          const SizedBox(height: 16),
          ElevatedButton(
            onPressed: onRetry,
            style: ElevatedButton.styleFrom(
              backgroundColor: theme.colorScheme.primary,
            ),
            child: Text(
              'Retry',
              style: GoogleFonts.plusJakartaSans(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmpty(
    String title,
    String subtitle,
    IconData icon,
    Color textColor,
  ) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 48, color: textColor.withValues(alpha: 0.3)),
          const SizedBox(height: 16),
          Text(
            title,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 16,
              fontWeight: FontWeight.w700,
              color: textColor.withValues(alpha: 0.5),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            subtitle,
            style: GoogleFonts.plusJakartaSans(
              color: textColor.withValues(alpha: 0.4),
            ),
          ),
        ],
      ),
    );
  }
}
