import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:nes/core/widgets/clay_container.dart';
import 'package:nes/features/admin/pages/widgets/admin_request_card.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';
import 'package:nes/features/admin/models/admin_models.dart';
import 'package:nes/features/admin/pages/workers_management_page.dart';
import 'package:nes/features/admin/pages/service_pricing_page.dart';
import 'package:nes/features/admin/pages/assign_worker_page.dart';
import 'package:nes/features/admin/pages/admin_profile_page.dart';
import 'package:nes/features/admin/pages/admin_request_detail_page.dart';
import 'package:nes/features/admin/providers/admin_provider.dart';

class AdminDashboard extends ConsumerStatefulWidget {
  const AdminDashboard({super.key});

  @override
  ConsumerState<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends ConsumerState<AdminDashboard> {
  // No local state — all state lives in adminProvider (ViewModel).

  void _handleRequestTap(BuildContext context, AdminRequest request) {
    _showRequestOptions(context, request);
  }

  void _showRequestOptions(BuildContext ctx, AdminRequest request) {
    final theme = Theme.of(ctx);
    final isDark = theme.brightness == Brightness.dark;
    final baseColor = isDark
        ? const Color(0xFF2D2D2D)
        : const Color(0xFFDEE4EA);
    final notifier = ref.read(adminProvider.notifier);

    showModalBottomSheet(
      context: ctx,
      backgroundColor: baseColor,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(bottom: 20),
                decoration: BoxDecoration(
                  color: theme.colorScheme.onSurface.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              _BottomSheetTile(
                icon: PhosphorIconsRegular.listMagnifyingGlass,
                label: 'View Full Details',
                baseColor: baseColor,
                theme: theme,
                onTap: () {
                  Navigator.pop(ctx);
                  Navigator.push(
                    ctx,
                    MaterialPageRoute(
                      builder: (_) => AdminRequestDetailPage(request: request),
                    ),
                  ).then((_) => notifier.loadData());
                },
              ),
              const SizedBox(height: 10),
              _BottomSheetTile(
                icon: PhosphorIconsRegular.arrowsLeftRight,
                label: 'Reassign Worker',
                baseColor: baseColor,
                theme: theme,
                onTap: () {
                  Navigator.pop(ctx);
                  Navigator.push(
                    ctx,
                    MaterialPageRoute(
                      builder: (_) => AssignWorkerPage(request: request),
                    ),
                  ).then((_) => notifier.loadData());
                },
              ),
              const SizedBox(height: 10),
              _BottomSheetTile(
                icon: PhosphorIconsRegular.pencilSimple,
                label: 'Update Status',
                baseColor: baseColor,
                theme: theme,
                onTap: () {
                  Navigator.pop(ctx);
                  _showStatusUpdateDialog(ctx, request);
                },
              ),
              const SizedBox(height: 10),
              _BottomSheetTile(
                icon: PhosphorIconsRegular.trash,
                label: 'Delete Request',
                baseColor: baseColor,
                theme: theme,
                isDestructive: true,
                onTap: () {
                  Navigator.pop(ctx);
                  _deleteRequest(ctx, request);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showStatusUpdateDialog(BuildContext ctx, AdminRequest request) {
    final statuses = ['pending', 'assigned', 'in_progress', 'completed'];
    showDialog(
      context: ctx,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          'Update Status',
          style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w800),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: statuses.map((status) {
            return RadioListTile<String>(
              title: Text(
                status[0].toUpperCase() +
                    status.substring(1).replaceAll('_', ' '),
              ),
              value: status,
              groupValue: request.status,
              onChanged: (value) async {
                if (value != null) {
                  Navigator.pop(context);
                  await _updateStatus(ctx, request.id, value);
                }
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  Future<void> _updateStatus(
    BuildContext ctx,
    String requestId,
    String newStatus,
  ) async {
    final notifier = ref.read(adminProvider.notifier);
    final success = await notifier.updateRequestStatus(
      requestId: requestId,
      newStatus: newStatus,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(ctx).showSnackBar(
      SnackBar(
        content: Text(
          success
              ? 'Status updated to ${newStatus.replaceAll('_', ' ')}'
              : 'Failed to update status',
        ),
        backgroundColor: success ? null : Colors.red,
      ),
    );
  }

  Future<void> _deleteRequest(BuildContext ctx, AdminRequest request) async {
    final confirmed = await showDialog<bool>(
      context: ctx,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          'Delete Request',
          style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w800),
        ),
        content: Text('Remove request from ${request.clientName}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      final notifier = ref.read(adminProvider.notifier);
      final success = await notifier.deleteRequest(request.id);
      if (!mounted) return;
      ScaffoldMessenger.of(ctx).showSnackBar(
        SnackBar(
          content: Text(success ? 'Request deleted' : 'Failed to delete'),
          backgroundColor: success ? null : Colors.red,
        ),
      );
    }
  }

  // DraggableScrollableSheet controller
  final DraggableScrollableController _sheetController =
      DraggableScrollableController();

  @override
  void dispose() {
    _sheetController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final user = ref.watch(currentUserProvider);

    // ── Read state from ViewModel ──
    final adminState = ref.watch(adminProvider);
    final notifier = ref.read(adminProvider.notifier);
    final isLoading = adminState.isLoading;
    final stats = adminState.stats;
    final filteredRequests = adminState.filteredRequests;

    final baseColor = isDark
        ? const Color(0xFF2D2D2D)
        : const Color(0xFFDEE4EA);
    final textColor = isDark ? Colors.white70 : const Color(0xFF485057);
    final shadowColor1 = isDark
        ? Colors.black.withValues(alpha: 0.4)
        : Colors.black.withValues(alpha: 0.12);
    final shadowColor2 = isDark
        ? Colors.white.withValues(alpha: 0.04)
        : Colors.white.withValues(alpha: 0.7);

    return Scaffold(
      backgroundColor: baseColor,
      body: SafeArea(
        bottom: false,
        child: Stack(
          children: [
            // ── Background: header + stats ──
            SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // ── Header ──
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Admin Dashboard',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                                color: textColor.withValues(alpha: 0.6),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              user?.fullName ?? 'Administrator',
                              style: GoogleFonts.plusJakartaSans(
                                fontSize: 28,
                                fontWeight: FontWeight.w800,
                                color: theme.colorScheme.primary,
                                letterSpacing: -0.8,
                              ),
                            ),
                          ],
                        ),
                      ),
                      GestureDetector(
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => const AdminProfilePage(),
                          ),
                        ),
                        child: Hero(
                          tag: 'admin_avatar',
                          child: ClayContainer(
                            color: baseColor,
                            borderRadius: 20,
                            depth: 20,
                            spread: 1,
                            width: 52,
                            height: 52,
                            shadowColor1: shadowColor1,
                            shadowColor2: shadowColor2,
                            child: Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    theme.colorScheme.primary,
                                    theme.colorScheme.primary.withValues(
                                      alpha: 0.7,
                                    ),
                                  ],
                                  begin: Alignment.topLeft,
                                  end: Alignment.bottomRight,
                                ),
                                shape: BoxShape.circle,
                              ),
                              child: user?.avatarUrl != null
                                  ? ClipOval(
                                      child: Image.network(
                                        user!.avatarUrl!,
                                        fit: BoxFit.cover,
                                        errorBuilder: (_, __, ___) =>
                                            const Icon(
                                              PhosphorIconsFill.user,
                                              color: Colors.white,
                                              size: 24,
                                            ),
                                      ),
                                    )
                                  : const Icon(
                                      PhosphorIconsFill.user,
                                      color: Colors.white,
                                      size: 24,
                                    ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 24),

                  // ── Stats ──
                  if (isLoading)
                    Center(
                      child: Padding(
                        padding: const EdgeInsets.all(30),
                        child: CircularProgressIndicator(
                          color: theme.colorScheme.primary,
                        ),
                      ),
                    )
                  else if (stats != null)
                    Column(
                      children: [
                        Row(
                          children: [
                            _ClayStatTile(
                              label: 'Total',
                              value: '${stats!.totalRequests}',
                              icon: PhosphorIconsRegular.chartBar,
                              baseColor: baseColor,
                              textColor: textColor,
                              shadowColor1: shadowColor1,
                              shadowColor2: shadowColor2,
                              theme: theme,
                              onTap: () {},
                            ),
                            const SizedBox(width: 12),
                            _ClayStatTile(
                              label: 'Pending',
                              value: '${stats!.pending}',
                              icon: PhosphorIconsRegular.clock,
                              baseColor: baseColor,
                              textColor: textColor,
                              shadowColor1: shadowColor1,
                              shadowColor2: shadowColor2,
                              theme: theme,
                              onTap: () {},
                            ),
                            const SizedBox(width: 12),
                            _ClayStatTile(
                              label: 'Progress',
                              value: '${stats!.inProgress}',
                              icon: PhosphorIconsRegular.trendUp,
                              baseColor: baseColor,
                              textColor: textColor,
                              shadowColor1: shadowColor1,
                              shadowColor2: shadowColor2,
                              theme: theme,
                              onTap: () {},
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        Row(
                          children: [
                            _ClayStatTile(
                              label: 'Completed',
                              value: '${stats!.completed}',
                              icon: PhosphorIconsFill.checkCircle,
                              baseColor: baseColor,
                              textColor: textColor,
                              shadowColor1: shadowColor1,
                              shadowColor2: shadowColor2,
                              theme: theme,
                              onTap: () {},
                            ),
                            const SizedBox(width: 12),
                            _ClayStatTile(
                              label: 'Workers',
                              value: '${stats!.workers}',
                              icon: PhosphorIconsRegular.users,
                              baseColor: baseColor,
                              textColor: textColor,
                              shadowColor1: shadowColor1,
                              shadowColor2: shadowColor2,
                              theme: theme,
                              onTap: () => Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) => const WorkersManagementPage(),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),

                        // ── Manage Pricing Banner ──
                        GestureDetector(
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) => const ServicePricingPage(),
                            ),
                          ),
                          child: ClayContainer(
                            color: baseColor,
                            borderRadius: 20,
                            depth: 20,
                            spread: 1,
                            shadowColor1: shadowColor1,
                            shadowColor2: shadowColor2,
                            padding: const EdgeInsets.symmetric(
                              horizontal: 20,
                              vertical: 16,
                            ),
                            child: Row(
                              children: [
                                ClayContainer(
                                  color: baseColor,
                                  borderRadius: 14,
                                  depth: -8,
                                  spread: 0,
                                  emboss: true,
                                  width: 42,
                                  height: 42,
                                  shadowColor1: shadowColor1,
                                  shadowColor2: shadowColor2,
                                  child: Icon(
                                    PhosphorIconsRegular.tag,
                                    color: theme.colorScheme.primary,
                                    size: 22,
                                  ),
                                ),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Manage Pricing',
                                        style: GoogleFonts.plusJakartaSans(
                                          fontWeight: FontWeight.w800,
                                          fontSize: 15,
                                          color: textColor,
                                        ),
                                      ),
                                      Text(
                                        'Edit prices, add or hide services',
                                        style: GoogleFonts.plusJakartaSans(
                                          fontSize: 12,
                                          color: textColor.withValues(
                                            alpha: 0.5,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Icon(
                                  PhosphorIconsRegular.caretRight,
                                  color: textColor.withValues(alpha: 0.3),
                                  size: 18,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),

                  // Bottom padding so stats don't hide under the sheet
                  const SizedBox(height: 420),
                ],
              ),
            ),

            // ── Draggable Requests Sheet ──
            DraggableScrollableSheet(
              controller: _sheetController,
              initialChildSize: 0.42,
              minChildSize: 0.38,
              maxChildSize: 1.0,
              snap: true,
              snapSizes: const [0.42, 1.0],
              builder: (context, scrollController) {
                return Container(
                  decoration: BoxDecoration(
                    color: theme.colorScheme.surface,
                    borderRadius: const BorderRadius.only(
                      topLeft: Radius.circular(32),
                      topRight: Radius.circular(32),
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: 0.08),
                        blurRadius: 20,
                        offset: const Offset(0, -8),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      // Drag handle
                      Padding(
                        padding: const EdgeInsets.only(top: 12, bottom: 4),
                        child: Container(
                          width: 40,
                          height: 4,
                          decoration: BoxDecoration(
                            color: theme.colorScheme.onSurface.withValues(
                              alpha: 0.15,
                            ),
                            borderRadius: BorderRadius.circular(2),
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.fromLTRB(24, 10, 24, 0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              'All Requests',
                              style: GoogleFonts.plusJakartaSans(
                                fontWeight: FontWeight.w800,
                                fontSize: 22,
                                letterSpacing: -0.5,
                                color: theme.colorScheme.onSurface,
                              ),
                            ),
                            ClayContainer(
                              color: baseColor,
                              borderRadius: 14,
                              depth: 15,
                              spread: 1,
                              width: 36,
                              height: 36,
                              shadowColor1: shadowColor1,
                              shadowColor2: shadowColor2,
                              child: IconButton(
                                padding: EdgeInsets.zero,
                                icon: Icon(
                                  PhosphorIconsRegular.arrowsClockwise,
                                  size: 18,
                                  color: theme.colorScheme.onSurface.withValues(
                                    alpha: 0.6,
                                  ),
                                ),
                                onPressed: notifier.loadData,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        child: _buildFilterChips(
                          theme,
                          baseColor,
                          textColor,
                          shadowColor1,
                          shadowColor2,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Expanded(
                        child: isLoading
                            ? Center(
                                child: CircularProgressIndicator(
                                  color: theme.colorScheme.primary,
                                ),
                              )
                            : filteredRequests.isEmpty
                            ? Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      PhosphorIconsRegular.tray,
                                      size: 70,
                                      color: theme.colorScheme.onSurface
                                          .withValues(alpha: 0.2),
                                    ),
                                    const SizedBox(height: 16),
                                    Text(
                                      'No requests found',
                                      style: GoogleFonts.plusJakartaSans(
                                        color: theme.colorScheme.onSurface
                                            .withValues(alpha: 0.4),
                                        fontSize: 15,
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            : ListView.separated(
                                controller: scrollController,
                                physics: const BouncingScrollPhysics(),
                                padding: const EdgeInsets.fromLTRB(
                                  24,
                                  4,
                                  24,
                                  100,
                                ),
                                itemCount: filteredRequests.length,
                                separatorBuilder: (_, __) =>
                                    const SizedBox(height: 12),
                                itemBuilder: (context, index) =>
                                    AdminRequestCard(
                                      request: filteredRequests[index],
                                      onTap: () => _handleRequestTap(
                                        context,
                                        filteredRequests[index],
                                      ),
                                    ),
                              ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFilterChips(
    ThemeData theme,
    Color baseColor,
    Color textColor,
    Color shadowColor1,
    Color shadowColor2,
  ) {
    final notifier = ref.read(adminProvider.notifier);
    final selectedFilter = ref.watch(adminProvider).selectedFilter;
    final filters = [
      {'value': 'all', 'label': 'All', 'icon': PhosphorIconsRegular.list},
      {
        'value': 'pending',
        'label': 'Pending',
        'icon': PhosphorIconsRegular.clock,
      },
      {
        'value': 'assigned',
        'label': 'Assigned',
        'icon': PhosphorIconsRegular.userPlus,
      },
      {
        'value': 'in_progress',
        'label': 'In Progress',
        'icon': PhosphorIconsRegular.trendUp,
      },
      {
        'value': 'completed',
        'label': 'Completed',
        'icon': PhosphorIconsFill.checkCircle,
      },
    ];

    return SizedBox(
      height: 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: filters.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final filter = filters[index];
          final isSelected = selectedFilter == filter['value'];

          return GestureDetector(
            onTap: () => notifier.setFilter(filter['value'] as String),
            child: ClayContainer(
              color: isSelected ? theme.colorScheme.primary : baseColor,
              borderRadius: 12,
              depth: 15,
              spread: 1,
              shadowColor1: shadowColor1,
              shadowColor2: shadowColor2,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    filter['icon'] as IconData,
                    size: 15,
                    color: isSelected
                        ? Colors.white
                        : theme.colorScheme.primary,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    filter['label'] as String,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: isSelected ? Colors.white : textColor,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ── Clay Stat Tile ──
class _ClayStatTile extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color baseColor;
  final Color textColor;
  final Color shadowColor1;
  final Color shadowColor2;
  final ThemeData theme;
  final VoidCallback onTap;

  const _ClayStatTile({
    required this.label,
    required this.value,
    required this.icon,
    required this.baseColor,
    required this.textColor,
    required this.shadowColor1,
    required this.shadowColor2,
    required this.theme,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: ClayContainer(
          color: baseColor,
          borderRadius: 20,
          depth: 18,
          spread: 1,
          shadowColor1: shadowColor1,
          shadowColor2: shadowColor2,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(
                icon,
                size: 20,
                color: theme.colorScheme.primary.withValues(alpha: 0.8),
              ),
              const SizedBox(height: 8),
              Text(
                value,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                  color: theme.colorScheme.primary,
                  letterSpacing: -0.5,
                ),
              ),
              Text(
                label,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                  color: textColor.withValues(alpha: 0.5),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Bottom Sheet Action Tile ──
class _BottomSheetTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color baseColor;
  final ThemeData theme;
  final VoidCallback onTap;
  final bool isDestructive;

  const _BottomSheetTile({
    required this.icon,
    required this.label,
    required this.baseColor,
    required this.theme,
    required this.onTap,
    this.isDestructive = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = isDestructive ? Colors.redAccent : theme.colorScheme.primary;
    return GestureDetector(
      onTap: onTap,
      child: ClayContainer(
        color: baseColor,
        borderRadius: 16,
        depth: 12,
        spread: 1,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Icon(icon, size: 20, color: color),
            const SizedBox(width: 14),
            Text(
              label,
              style: GoogleFonts.plusJakartaSans(
                fontWeight: FontWeight.w600,
                fontSize: 15,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
