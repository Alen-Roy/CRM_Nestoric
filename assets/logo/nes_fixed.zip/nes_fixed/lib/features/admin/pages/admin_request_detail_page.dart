import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:nes/core/widgets/clay_container.dart';
import 'package:nes/features/admin/models/admin_models.dart';
import 'package:nes/features/admin/pages/assign_worker_page.dart';
import 'package:nes/features/admin/providers/admin_provider.dart';

class AdminRequestDetailPage extends ConsumerWidget {
  final AdminRequest request;

  const AdminRequestDetailPage({super.key, required this.request});

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'completed':
        return Colors.green;
      case 'pending':
        return Colors.orange;
      case 'in_progress':
        return Colors.purple;
      case 'assigned':
        return Colors.blue;
      default:
        return Colors.grey;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'completed':
        return PhosphorIconsFill.checkCircle;
      case 'pending':
        return PhosphorIconsRegular.clock;
      case 'in_progress':
        return PhosphorIconsRegular.trendUp;
      case 'assigned':
        return PhosphorIconsRegular.userPlus;
      default:
        return PhosphorIconsRegular.info;
    }
  }

  String _formatDate(DateTime? date) {
    if (date == null) return 'Unknown';
    final months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return '${date.day} ${months[date.month - 1]} ${date.year}';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final baseColor = isDark
        ? const Color(0xFF2D2D2D)
        : const Color(0xFFDEE4EA);
    final textColor = isDark ? Colors.white70 : const Color(0xFF485057);
    final shadowColor1 = isDark
        ? Colors.black.withValues(alpha: 0.4)
        : Colors.black.withValues(alpha: 0.12);
    final shadowColor2 = isDark
        ? Colors.white.withValues(alpha: 0.04)
        : Colors.white.withValues(alpha: 0.7);
    final statusColor = _getStatusColor(request.status);
    final statusIcon = _getStatusIcon(request.status);
    final notifier = ref.read(adminProvider.notifier);

    return Scaffold(
      backgroundColor: baseColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: Center(
            child: ClayContainer(
              height: 44,
              width: 44,
              borderRadius: 22,
              depth: 20,
              spread: 1,
              color: baseColor,
              shadowColor1: shadowColor1,
              shadowColor2: shadowColor2,
              child: IconButton(
                icon: Icon(
                  PhosphorIconsRegular.caretLeft,
                  size: 22,
                  color: textColor,
                ),
                onPressed: () => Navigator.pop(context),
              ),
            ),
          ),
        ),
        title: Text(
          'Request Details',
          style: GoogleFonts.plusJakartaSans(
            fontWeight: FontWeight.w800,
            fontSize: 20,
            color: textColor,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 40),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Client Header ──
            ClayContainer(
              color: baseColor,
              borderRadius: 22,
              depth: 18,
              spread: 1,
              shadowColor1: shadowColor1,
              shadowColor2: shadowColor2,
              padding: const EdgeInsets.all(20),
              child: Row(
                children: [
                  // Avatar
                  ClayContainer(
                    color: baseColor,
                    borderRadius: 28,
                    depth: 16,
                    spread: 1,
                    width: 56,
                    height: 56,
                    shadowColor1: shadowColor1,
                    shadowColor2: shadowColor2,
                    child: request.clientAvatar != null
                        ? ClipOval(
                            child: Image.network(
                              request.clientAvatar!,
                              fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Icon(
                                PhosphorIconsFill.user,
                                color: theme.colorScheme.primary,
                                size: 26,
                              ),
                            ),
                          )
                        : Icon(
                            PhosphorIconsFill.user,
                            color: theme.colorScheme.primary,
                            size: 26,
                          ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          request.clientName,
                          style: GoogleFonts.plusJakartaSans(
                            fontWeight: FontWeight.w800,
                            fontSize: 18,
                            color: textColor,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '#${request.id.substring(request.id.length - 8).toUpperCase()}',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 12,
                            color: textColor.withValues(alpha: 0.45),
                            letterSpacing: 1,
                          ),
                        ),
                      ],
                    ),
                  ),
                  // Status Badge
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 12,
                      vertical: 6,
                    ),
                    decoration: BoxDecoration(
                      color: statusColor.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(statusIcon, color: statusColor, size: 14),
                        const SizedBox(width: 6),
                        Text(
                          request.status[0].toUpperCase() +
                              request.status.substring(1).replaceAll('_', ' '),
                          style: GoogleFonts.plusJakartaSans(
                            color: statusColor,
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // ── Dates ──
            Row(
              children: [
                Expanded(
                  child: _InfoCard(
                    baseColor: baseColor,
                    shadowColor1: shadowColor1,
                    shadowColor2: shadowColor2,
                    icon: PhosphorIconsRegular.calendarBlank,
                    label: 'Created',
                    value: _formatDate(request.createdAt),
                    textColor: textColor,
                    theme: theme,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _InfoCard(
                    baseColor: baseColor,
                    shadowColor1: shadowColor1,
                    shadowColor2: shadowColor2,
                    icon: PhosphorIconsRegular.timer,
                    label: 'Deadline',
                    value: request.deadline != null
                        ? _formatDate(request.deadline)
                        : 'Not set',
                    textColor: textColor,
                    theme: theme,
                    highlight:
                        request.deadline != null &&
                        request.deadline!.isBefore(DateTime.now()),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 16),

            // ── Services ──
            _SectionCard(
              baseColor: baseColor,
              shadowColor1: shadowColor1,
              shadowColor2: shadowColor2,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _SectionHeader(
                    icon: PhosphorIconsRegular.wrench,
                    label: 'Services Requested',
                    textColor: textColor,
                    theme: theme,
                  ),
                  const SizedBox(height: 12),
                  if (request.services.isEmpty)
                    Text(
                      'No services listed',
                      style: GoogleFonts.plusJakartaSans(
                        color: textColor.withValues(alpha: 0.5),
                        fontSize: 14,
                      ),
                    )
                  else
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: request.services.map((service) {
                        return Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 6,
                          ),
                          decoration: BoxDecoration(
                            color: theme.colorScheme.primary.withValues(
                              alpha: 0.1,
                            ),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text(
                            service,
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: theme.colorScheme.primary,
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // ── Description ──
            _SectionCard(
              baseColor: baseColor,
              shadowColor1: shadowColor1,
              shadowColor2: shadowColor2,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _SectionHeader(
                    icon: PhosphorIconsRegular.textAlignLeft,
                    label: 'Description',
                    textColor: textColor,
                    theme: theme,
                  ),
                  const SizedBox(height: 12),
                  Text(
                    request.description.isEmpty
                        ? 'No description provided.'
                        : request.description,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 14,
                      color: request.description.isEmpty
                          ? textColor.withValues(alpha: 0.5)
                          : textColor.withValues(alpha: 0.85),
                      height: 1.6,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // ── Assigned Worker ──
            _SectionCard(
              baseColor: baseColor,
              shadowColor1: shadowColor1,
              shadowColor2: shadowColor2,
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: theme.colorScheme.primary.withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(
                      PhosphorIconsRegular.userGear,
                      color: theme.colorScheme.primary,
                      size: 22,
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Assigned Worker',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 12,
                            color: textColor.withValues(alpha: 0.5),
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          request.assignedWorkerName ?? 'Unassigned',
                          style: GoogleFonts.plusJakartaSans(
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: request.assignedWorkerName != null
                                ? theme.colorScheme.primary
                                : Colors.orange.shade700,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (request.assignedWorkerName == null)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.orange.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(
                        PhosphorIconsRegular.warning,
                        size: 16,
                        color: Colors.orange.shade700,
                      ),
                    ),
                ],
              ),
            ),

            // ── Client Note ──
            if (request.note != null && request.note!.isNotEmpty) ...[
              const SizedBox(height: 16),
              _SectionCard(
                baseColor: baseColor,
                shadowColor1: shadowColor1,
                shadowColor2: shadowColor2,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _SectionHeader(
                      icon: PhosphorIconsRegular.notepad,
                      label: 'Client Note',
                      textColor: textColor,
                      theme: theme,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      request.note!,
                      style: GoogleFonts.plusJakartaSans(
                        fontSize: 14,
                        color: textColor.withValues(alpha: 0.85),
                        height: 1.6,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ],
                ),
              ),
            ],

            // ── Uploaded Files ──
            if (request.uploadedFiles != null &&
                request.uploadedFiles!.isNotEmpty) ...[
              const SizedBox(height: 16),
              _SectionCard(
                baseColor: baseColor,
                shadowColor1: shadowColor1,
                shadowColor2: shadowColor2,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _SectionHeader(
                      icon: PhosphorIconsRegular.paperclip,
                      label: 'Uploaded Files',
                      textColor: textColor,
                      theme: theme,
                    ),
                    const SizedBox(height: 12),
                    ...request.uploadedFiles!.asMap().entries.map((entry) {
                      final i = entry.key;
                      final url = entry.value;
                      final isImage =
                          url.contains('.jpg') ||
                          url.contains('.jpeg') ||
                          url.contains('.png') ||
                          url.contains('.gif') ||
                          url.contains('.webp');
                      return Padding(
                        padding: EdgeInsets.only(
                          bottom: i < request.uploadedFiles!.length - 1 ? 8 : 0,
                        ),
                        child: GestureDetector(
                          onTap: () => launchUrl(Uri.parse(url)),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 14,
                              vertical: 10,
                            ),
                            decoration: BoxDecoration(
                              color: theme.colorScheme.primary.withValues(
                                alpha: 0.07,
                              ),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Row(
                              children: [
                                Icon(
                                  isImage
                                      ? PhosphorIconsFill.image
                                      : PhosphorIconsFill.fileText,
                                  color: theme.colorScheme.primary,
                                  size: 20,
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Text(
                                    'File ${i + 1}',
                                    style: GoogleFonts.plusJakartaSans(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w600,
                                      color: theme.colorScheme.primary,
                                      decoration: TextDecoration.underline,
                                    ),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                                Icon(
                                  PhosphorIconsRegular.arrowSquareOut,
                                  size: 16,
                                  color: theme.colorScheme.primary.withValues(
                                    alpha: 0.6,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    }),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 28),

            // ── Action Buttons ──
            Text(
              'Actions',
              style: GoogleFonts.plusJakartaSans(
                fontWeight: FontWeight.w700,
                fontSize: 14,
                color: textColor.withValues(alpha: 0.5),
                letterSpacing: 0.5,
              ),
            ),
            const SizedBox(height: 12),

            _ActionButton(
              baseColor: baseColor,
              shadowColor1: shadowColor1,
              shadowColor2: shadowColor2,
              icon: PhosphorIconsRegular.arrowsLeftRight,
              label: 'Reassign Worker',
              color: theme.colorScheme.primary,
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => AssignWorkerPage(request: request),
                  ),
                ).then((_) => notifier.loadData());
              },
            ),

            const SizedBox(height: 10),

            _ActionButton(
              baseColor: baseColor,
              shadowColor1: shadowColor1,
              shadowColor2: shadowColor2,
              icon: PhosphorIconsRegular.pencilSimple,
              label: 'Update Status',
              color: Colors.blue,
              onTap: () => _showStatusUpdateDialog(context, ref),
            ),

            const SizedBox(height: 10),

            _ActionButton(
              baseColor: baseColor,
              shadowColor1: shadowColor1,
              shadowColor2: shadowColor2,
              icon: PhosphorIconsRegular.trash,
              label: 'Delete Request',
              color: Colors.red,
              isDestructive: true,
              onTap: () => _deleteRequest(context, ref),
            ),
          ],
        ),
      ),
    );
  }

  void _showStatusUpdateDialog(BuildContext context, WidgetRef ref) {
    final statuses = ['pending', 'assigned', 'in_progress', 'completed'];
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          'Update Status',
          style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w800),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: statuses.map((status) {
            return RadioListTile<String>(
              title: Text(
                status[0].toUpperCase() +
                    status.substring(1).replaceAll('_', ' '),
              ),
              value: status,
              groupValue: request.status,
              onChanged: (value) async {
                if (value != null) {
                  Navigator.pop(ctx);
                  final notifier = ref.read(adminProvider.notifier);
                  final success = await notifier.updateRequestStatus(
                    requestId: request.id,
                    newStatus: value,
                  );
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          success
                              ? 'Status updated to ${value.replaceAll('_', ' ')}'
                              : 'Failed to update status',
                        ),
                        backgroundColor: success ? null : Colors.red,
                      ),
                    );
                    if (success) Navigator.pop(context);
                  }
                }
              },
            );
          }).toList(),
        ),
      ),
    );
  }

  Future<void> _deleteRequest(BuildContext context, WidgetRef ref) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          'Delete Request',
          style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w800),
        ),
        content: Text('Remove request from ${request.clientName}?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed == true && context.mounted) {
      final notifier = ref.read(adminProvider.notifier);
      final success = await notifier.deleteRequest(request.id);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(success ? 'Request deleted' : 'Failed to delete'),
            backgroundColor: success ? null : Colors.red,
          ),
        );
        if (success) Navigator.pop(context);
      }
    }
  }
}

// ── Reusable Section Card ──
class _SectionCard extends StatelessWidget {
  final Color baseColor;
  final Color shadowColor1;
  final Color shadowColor2;
  final Widget child;

  const _SectionCard({
    required this.baseColor,
    required this.shadowColor1,
    required this.shadowColor2,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    return ClayContainer(
      color: baseColor,
      borderRadius: 20,
      depth: 16,
      spread: 1,
      shadowColor1: shadowColor1,
      shadowColor2: shadowColor2,
      padding: const EdgeInsets.all(18),
      child: child,
    );
  }
}

// ── Section Header ──
class _SectionHeader extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color textColor;
  final ThemeData theme;

  const _SectionHeader({
    required this.icon,
    required this.label,
    required this.textColor,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 17, color: theme.colorScheme.primary),
        const SizedBox(width: 8),
        Text(
          label,
          style: GoogleFonts.plusJakartaSans(
            fontWeight: FontWeight.w700,
            fontSize: 14,
            color: textColor,
          ),
        ),
      ],
    );
  }
}

// ── Info Card (dates) ──
class _InfoCard extends StatelessWidget {
  final Color baseColor;
  final Color shadowColor1;
  final Color shadowColor2;
  final IconData icon;
  final String label;
  final String value;
  final Color textColor;
  final ThemeData theme;
  final bool highlight;

  const _InfoCard({
    required this.baseColor,
    required this.shadowColor1,
    required this.shadowColor2,
    required this.icon,
    required this.label,
    required this.value,
    required this.textColor,
    required this.theme,
    this.highlight = false,
  });

  @override
  Widget build(BuildContext context) {
    return ClayContainer(
      color: baseColor,
      borderRadius: 18,
      depth: 16,
      spread: 1,
      shadowColor1: shadowColor1,
      shadowColor2: shadowColor2,
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                icon,
                size: 15,
                color: highlight ? Colors.red : theme.colorScheme.primary,
              ),
              const SizedBox(width: 6),
              Text(
                label,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 11,
                  color: textColor.withValues(alpha: 0.5),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            value,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 14,
              fontWeight: FontWeight.w700,
              color: highlight ? Colors.red : textColor,
            ),
          ),
        ],
      ),
    );
  }
}

// ── Action Button ──
class _ActionButton extends StatelessWidget {
  final Color baseColor;
  final Color shadowColor1;
  final Color shadowColor2;
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  final bool isDestructive;

  const _ActionButton({
    required this.baseColor,
    required this.shadowColor1,
    required this.shadowColor2,
    required this.icon,
    required this.label,
    required this.color,
    required this.onTap,
    this.isDestructive = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: ClayContainer(
        color: baseColor,
        borderRadius: 18,
        depth: 14,
        spread: 1,
        shadowColor1: shadowColor1,
        shadowColor2: shadowColor2,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: color, size: 20),
            ),
            const SizedBox(width: 14),
            Text(
              label,
              style: GoogleFonts.plusJakartaSans(
                fontWeight: FontWeight.w700,
                fontSize: 15,
                color: isDestructive ? color : color,
              ),
            ),
            const Spacer(),
            Icon(
              PhosphorIconsRegular.caretRight,
              size: 18,
              color: color.withValues(alpha: 0.5),
            ),
          ],
        ),
      ),
    );
  }
}
