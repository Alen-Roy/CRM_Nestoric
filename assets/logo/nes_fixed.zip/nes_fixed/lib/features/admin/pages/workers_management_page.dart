import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:nes/core/widgets/clay_container.dart';
import 'package:nes/features/admin/models/admin_models.dart';
import 'package:nes/features/admin/pages/add_worker_page.dart';
import 'package:nes/features/admin/pages/worker_detail_page.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';
import 'package:nes/services/admin_api_service.dart';

class WorkersManagementPage extends ConsumerStatefulWidget {
  const WorkersManagementPage({super.key});

  @override
  ConsumerState<WorkersManagementPage> createState() =>
      _WorkersManagementPageState();
}

class _WorkersManagementPageState extends ConsumerState<WorkersManagementPage> {
  String _searchQuery = '';
  String _filterStatus = 'all';
  bool isLoading = true;
  List<Worker> allWorkers = [];

  @override
  void initState() {
    super.initState();
    _loadWorkers();
  }

  Future<void> _loadWorkers() async {
    setState(() => isLoading = true);

    final token = ref.read(authProvider).token;
    if (token == null) {
      setState(() => isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Authentication required'),
            backgroundColor: Colors.red,
          ),
        );
      }
      return;
    }

    final result = await AdminApiService.getAllWorkers(token);

    if (result['success']) {
      final workersData = result['workers'] as List;
      allWorkers = workersData.map((w) => Worker.fromJson(w)).toList();
    } else {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(result['error'] ?? 'Failed to load workers'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }

    if (mounted) setState(() => isLoading = false);
  }

  List<Worker> _getFilteredWorkers() {
    var workers = allWorkers;
    if (_searchQuery.isNotEmpty) {
      workers = workers.where((w) {
        return w.name.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            w.email.toLowerCase().contains(_searchQuery.toLowerCase()) ||
            w.skills.any(
              (s) => s.toLowerCase().contains(_searchQuery.toLowerCase()),
            );
      }).toList();
    }
    if (_filterStatus == 'available') {
      workers = workers.where((w) => w.isAvailable).toList();
    } else if (_filterStatus == 'busy') {
      workers = workers.where((w) => !w.isAvailable).toList();
    }
    return workers;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final filteredWorkers = _getFilteredWorkers();

    final baseColor = isDark
        ? const Color(0xFF2D2D2D)
        : const Color(0xFFDEE4EA);
    final textColor = isDark ? Colors.white70 : const Color(0xFF485057);
    final shadowColor1 = isDark
        ? Colors.black.withValues(alpha: 0.4)
        : Colors.black.withValues(alpha: 0.12);
    final shadowColor2 = isDark
        ? Colors.white.withValues(alpha: 0.04)
        : Colors.white.withValues(alpha: 0.7);

    return Scaffold(
      backgroundColor: baseColor,
      appBar: AppBar(
        title: Text(
          'Workers',
          style: GoogleFonts.plusJakartaSans(
            fontWeight: FontWeight.w800,
            letterSpacing: -0.5,
            color: textColor,
          ),
        ),
        elevation: 0,
        backgroundColor: Colors.transparent,
        foregroundColor: textColor,
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8),
            child: GestureDetector(
              onTap: _loadWorkers,
              child: ClayContainer(
                color: baseColor,
                borderRadius: 14,
                depth: 12,
                spread: 1,
                width: 38,
                height: 38,
                shadowColor1: shadowColor1,
                shadowColor2: shadowColor2,
                child: Icon(
                  PhosphorIconsRegular.arrowsClockwise,
                  size: 18,
                  color: textColor.withValues(alpha: 0.6),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: GestureDetector(
              onTap: () async {
                final result = await Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const AddWorkerPage()),
                );
                if (result == true) _loadWorkers();
              },
              child: ClayContainer(
                color: baseColor,
                borderRadius: 14,
                depth: 12,
                spread: 1,
                width: 38,
                height: 38,
                shadowColor1: shadowColor1,
                shadowColor2: shadowColor2,
                child: Icon(
                  PhosphorIconsRegular.plus,
                  size: 18,
                  color: theme.colorScheme.primary,
                ),
              ),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
            child: Column(
              children: [
                // ── Search ──
                ClayContainer(
                  color: baseColor,
                  borderRadius: 16,
                  depth: -8,
                  spread: 1,
                  emboss: true,
                  shadowColor1: shadowColor1,
                  shadowColor2: shadowColor2,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 14,
                    vertical: 12,
                  ),
                  child: Row(
                    children: [
                      Icon(
                        PhosphorIconsRegular.magnifyingGlass,
                        size: 18,
                        color: textColor.withValues(alpha: 0.4),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: TextField(
                          onChanged: (value) =>
                              setState(() => _searchQuery = value),
                          style: GoogleFonts.plusJakartaSans(
                            color: textColor,
                            fontSize: 14,
                          ),
                          decoration: InputDecoration(
                            hintText: 'Search workers…',
                            hintStyle: GoogleFonts.plusJakartaSans(
                              color: textColor.withValues(alpha: 0.35),
                              fontSize: 14,
                            ),
                            border: InputBorder.none,
                            isDense: true,
                            contentPadding: EdgeInsets.zero,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),

                // ── Filter Chips ──
                Row(
                  children: [
                    _FilterChip(
                      label: 'All',
                      value: 'all',
                      selectedValue: _filterStatus,
                      icon: PhosphorIconsRegular.list,
                      baseColor: baseColor,
                      textColor: textColor,
                      theme: theme,
                      shadowColor1: shadowColor1,
                      shadowColor2: shadowColor2,
                      onSelected: (v) => setState(() => _filterStatus = v),
                    ),
                    const SizedBox(width: 8),
                    _FilterChip(
                      label: 'Available',
                      value: 'available',
                      selectedValue: _filterStatus,
                      icon: PhosphorIconsFill.checkCircle,
                      baseColor: baseColor,
                      textColor: textColor,
                      theme: theme,
                      shadowColor1: shadowColor1,
                      shadowColor2: shadowColor2,
                      onSelected: (v) => setState(() => _filterStatus = v),
                    ),
                    const SizedBox(width: 8),
                    _FilterChip(
                      label: 'Busy',
                      value: 'busy',
                      selectedValue: _filterStatus,
                      icon: PhosphorIconsRegular.prohibit,
                      baseColor: baseColor,
                      textColor: textColor,
                      theme: theme,
                      shadowColor1: shadowColor1,
                      shadowColor2: shadowColor2,
                      onSelected: (v) => setState(() => _filterStatus = v),
                    ),
                  ],
                ),
              ],
            ),
          ),

          // ── Workers List ──
          Expanded(
            child: isLoading
                ? Center(
                    child: CircularProgressIndicator(
                      color: theme.colorScheme.primary,
                    ),
                  )
                : filteredWorkers.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          PhosphorIconsRegular.usersFour,
                          size: 70,
                          color: textColor.withValues(alpha: 0.2),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          _searchQuery.isNotEmpty || _filterStatus != 'all'
                              ? 'No workers found'
                              : 'No workers yet',
                          style: GoogleFonts.plusJakartaSans(
                            color: textColor.withValues(alpha: 0.4),
                            fontSize: 15,
                          ),
                        ),
                        if (allWorkers.isEmpty) ...[
                          const SizedBox(height: 6),
                          Text(
                            'Tap + to add workers',
                            style: GoogleFonts.plusJakartaSans(
                              color: textColor.withValues(alpha: 0.3),
                              fontSize: 13,
                            ),
                          ),
                        ],
                      ],
                    ),
                  )
                : ListView.separated(
                    physics: const BouncingScrollPhysics(),
                    padding: const EdgeInsets.fromLTRB(20, 0, 20, 100),
                    itemCount: filteredWorkers.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (context, index) {
                      final worker = filteredWorkers[index];
                      return _WorkerCard(
                        worker: worker,
                        baseColor: baseColor,
                        textColor: textColor,
                        shadowColor1: shadowColor1,
                        shadowColor2: shadowColor2,
                        theme: theme,
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => WorkerDetailPage(worker: worker),
                          ),
                        ).then((_) => _loadWorkers()),
                        onToggleStatus: () => _toggleWorkerStatus(worker),
                        onDelete: () => _deleteWorker(context, worker),
                      );
                    },
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddWorkerPage()),
          );
          if (result == true) _loadWorkers();
        },
        icon: const Icon(PhosphorIconsRegular.userPlus),
        label: Text(
          'Add Worker',
          style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w600),
        ),
        backgroundColor: theme.colorScheme.primary,
        foregroundColor: Colors.white,
      ),
    );
  }

  Future<void> _toggleWorkerStatus(Worker worker) async {
    final token = ref.read(authProvider).token;
    if (token == null) return;

    final result = await AdminApiService.updateWorker(
      token: token,
      workerId: worker.id,
      isAvailable: !worker.isAvailable,
    );

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            result['success']
                ? '${worker.name} is now ${!worker.isAvailable ? "available" : "busy"}'
                : result['error'] ?? 'Failed to update status',
          ),
          backgroundColor: result['success'] ? null : Colors.red,
        ),
      );
      if (result['success']) _loadWorkers();
    }
  }

  void _deleteWorker(BuildContext context, Worker worker) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(
          'Remove Worker',
          style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w800),
        ),
        content: Text('Remove ${worker.name} from the team?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              Navigator.pop(context);
              final token = ref.read(authProvider).token;
              if (token == null) return;
              final result = await AdminApiService.deleteWorker(
                token: token,
                workerId: worker.id,
              );
              if (!mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text(
                    result['success']
                        ? '${worker.name} removed'
                        : result['error'] ?? 'Failed',
                  ),
                  backgroundColor: result['success'] ? null : Colors.red,
                ),
              );
              if (result['success']) _loadWorkers();
            },
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Remove'),
          ),
        ],
      ),
    );
  }
}

// ── Filter Chip ──
class _FilterChip extends StatelessWidget {
  final String label;
  final String value;
  final String selectedValue;
  final IconData icon;
  final Color baseColor;
  final Color textColor;
  final ThemeData theme;
  final Color shadowColor1;
  final Color shadowColor2;
  final ValueChanged<String> onSelected;

  const _FilterChip({
    required this.label,
    required this.value,
    required this.selectedValue,
    required this.icon,
    required this.baseColor,
    required this.textColor,
    required this.theme,
    required this.shadowColor1,
    required this.shadowColor2,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    final isSelected = selectedValue == value;
    return GestureDetector(
      onTap: () => onSelected(value),
      child: ClayContainer(
        color: isSelected ? theme.colorScheme.primary : baseColor,
        borderRadius: 12,
        depth: 12,
        spread: 1,
        shadowColor1: shadowColor1,
        shadowColor2: shadowColor2,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 15,
              color: isSelected ? Colors.white : theme.colorScheme.primary,
            ),
            const SizedBox(width: 6),
            Text(
              label,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: isSelected ? Colors.white : textColor,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Worker Card ──
class _WorkerCard extends StatelessWidget {
  final Worker worker;
  final Color baseColor;
  final Color textColor;
  final Color shadowColor1;
  final Color shadowColor2;
  final ThemeData theme;
  final VoidCallback onTap;
  final VoidCallback onToggleStatus;
  final VoidCallback onDelete;

  const _WorkerCard({
    required this.worker,
    required this.baseColor,
    required this.textColor,
    required this.shadowColor1,
    required this.shadowColor2,
    required this.theme,
    required this.onTap,
    required this.onToggleStatus,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: ClayContainer(
        color: baseColor,
        borderRadius: 20,
        depth: 18,
        spread: 1,
        shadowColor1: shadowColor1,
        shadowColor2: shadowColor2,
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                // ── Avatar + status dot ──
                Stack(
                  children: [
                    ClayContainer(
                      color: baseColor,
                      borderRadius: 30,
                      depth: 12,
                      spread: 1,
                      width: 52,
                      height: 52,
                      shadowColor1: shadowColor1,
                      shadowColor2: shadowColor2,
                      child: worker.avatar != null
                          ? ClipOval(
                              child: Image.network(
                                worker.avatar!,
                                fit: BoxFit.cover,
                                width: 52,
                                height: 52,
                                errorBuilder: (_, __, ___) => Icon(
                                  PhosphorIconsFill.user,
                                  size: 24,
                                  color: theme.colorScheme.primary,
                                ),
                              ),
                            )
                          : Icon(
                              PhosphorIconsFill.user,
                              size: 24,
                              color: theme.colorScheme.primary,
                            ),
                    ),
                    Positioned(
                      bottom: 2,
                      right: 2,
                      child: Container(
                        width: 13,
                        height: 13,
                        decoration: BoxDecoration(
                          color: worker.isAvailable
                              ? Colors.green
                              : Colors.redAccent,
                          shape: BoxShape.circle,
                          border: Border.all(color: baseColor, width: 2),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              worker.name,
                              style: GoogleFonts.plusJakartaSans(
                                fontWeight: FontWeight.w700,
                                fontSize: 15,
                                color: textColor,
                              ),
                            ),
                          ),
                          Row(
                            children: [
                              Icon(
                                PhosphorIconsFill.star,
                                size: 14,
                                color: Colors.amber.shade600,
                              ),
                              const SizedBox(width: 3),
                              Text(
                                worker.rating.toStringAsFixed(1),
                                style: GoogleFonts.plusJakartaSans(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 13,
                                  color: Colors.amber.shade600,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 2),
                      Text(
                        worker.email,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 12,
                          color: textColor.withValues(alpha: 0.5),
                        ),
                      ),
                    ],
                  ),
                ),
                PopupMenuButton(
                  icon: Icon(
                    PhosphorIconsRegular.dotsThreeVertical,
                    color: textColor.withValues(alpha: 0.4),
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                  itemBuilder: (context) => [
                    PopupMenuItem(
                      value: 'toggle',
                      child: Row(
                        children: [
                          Icon(
                            worker.isAvailable
                                ? PhosphorIconsRegular.prohibit
                                : PhosphorIconsFill.checkCircle,
                            size: 18,
                            color: worker.isAvailable
                                ? Colors.orange
                                : Colors.green,
                          ),
                          const SizedBox(width: 10),
                          Text(
                            worker.isAvailable ? 'Mark Busy' : 'Mark Available',
                          ),
                        ],
                      ),
                    ),
                    PopupMenuItem(
                      value: 'delete',
                      child: Row(
                        children: [
                          Icon(
                            PhosphorIconsRegular.trash,
                            size: 18,
                            color: Colors.red,
                          ),
                          const SizedBox(width: 10),
                          const Text(
                            'Remove',
                            style: TextStyle(color: Colors.red),
                          ),
                        ],
                      ),
                    ),
                  ],
                  onSelected: (value) {
                    if (value == 'delete') {
                      onDelete();
                    } else if (value == 'toggle') {
                      onToggleStatus();
                    }
                  },
                ),
              ],
            ),

            if (worker.skills.isNotEmpty) ...[
              const SizedBox(height: 12),
              Align(
                alignment: Alignment.centerLeft,
                child: Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: worker.skills.map((skill) {
                    return Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: theme.colorScheme.primary.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        skill,
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: theme.colorScheme.primary,
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ],

            const SizedBox(height: 12),

            // ── Stats ──
            Row(
              children: [
                _MiniStat(
                  icon: PhosphorIconsRegular.briefcase,
                  label: 'Active',
                  value: worker.activeProjects.toString(),
                  textColor: textColor,
                  theme: theme,
                ),
                Container(
                  height: 28,
                  width: 1,
                  color: textColor.withValues(alpha: 0.1),
                ),
                _MiniStat(
                  icon: PhosphorIconsFill.checkCircle,
                  label: 'Done',
                  value: worker.completedProjects.toString(),
                  textColor: textColor,
                  theme: theme,
                ),
                Container(
                  height: 28,
                  width: 1,
                  color: textColor.withValues(alpha: 0.1),
                ),
                _MiniStat(
                  icon: worker.isAvailable
                      ? PhosphorIconsFill.checkCircle
                      : PhosphorIconsRegular.prohibit,
                  label: 'Status',
                  value: worker.isAvailable ? 'Free' : 'Busy',
                  textColor: textColor,
                  theme: theme,
                  valueColor: worker.isAvailable
                      ? Colors.green
                      : Colors.redAccent,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color textColor;
  final ThemeData theme;
  final Color? valueColor;

  const _MiniStat({
    required this.icon,
    required this.label,
    required this.value,
    required this.textColor,
    required this.theme,
    this.valueColor,
  });

  @override
  Widget build(BuildContext context) {
    final color = valueColor ?? theme.colorScheme.primary;
    return Expanded(
      child: Column(
        children: [
          Icon(icon, size: 16, color: color.withValues(alpha: 0.7)),
          const SizedBox(height: 3),
          Text(
            value,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: color,
            ),
          ),
          Text(
            label,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 10,
              color: textColor.withValues(alpha: 0.4),
            ),
          ),
        ],
      ),
    );
  }
}
