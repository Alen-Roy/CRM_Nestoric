import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:nes/core/providers/theme_provider.dart';
import 'package:nes/core/widgets/clay_container.dart';
import 'package:nes/features/admin/pages/workers_management_page.dart';
import 'package:nes/features/admin/pages/service_pricing_page.dart';
import 'package:nes/features/auth/presentation/login_signup.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';
import 'package:nes/services/app_info_service.dart';

class AdminProfilePage extends ConsumerWidget {
  const AdminProfilePage({super.key});

  Future<void> _logout(BuildContext context, WidgetRef ref) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Text(
          'Logout',
          style: GoogleFonts.plusJakartaSans(fontWeight: FontWeight.w800),
        ),
        content: const Text('Are you sure you want to logout?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Logout'),
          ),
        ],
      ),
    );

    if (confirm == true && context.mounted) {
      await ref.read(authProvider.notifier).logout();
      if (context.mounted) {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LoginSignup()),
          (route) => false,
        );
      }
    }
  }

  Widget _buildDivider(Color dividerColor) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 24),
      child: Container(
        height: 1,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              dividerColor.withValues(alpha: 0),
              dividerColor,
              dividerColor,
              dividerColor.withValues(alpha: 0),
            ],
            stops: const [0.0, 0.2, 0.8, 1.0],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final user = ref.watch(currentUserProvider);
    final themeMode = ref.watch(themeModeProvider);

    final baseColor = isDark
        ? const Color(0xFF2D2D2D)
        : const Color(0xFFDEE4EA);
    final textColor = isDark ? Colors.white70 : const Color(0xFF485057);
    final dividerColor = isDark
        ? Colors.white.withValues(alpha: 0.06)
        : Colors.black.withValues(alpha: 0.06);
    final shadowColor1 = isDark
        ? Colors.black.withValues(alpha: 0.4)
        : Colors.black.withValues(alpha: 0.12);
    final shadowColor2 = isDark
        ? Colors.white.withValues(alpha: 0.04)
        : Colors.white.withValues(alpha: 0.7);

    return Scaffold(
      backgroundColor: baseColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: textColor,
        title: Text(
          'Profile',
          style: GoogleFonts.plusJakartaSans(
            fontWeight: FontWeight.w800,
            letterSpacing: -0.5,
            color: textColor,
          ),
        ),
      ),
      body: ListView(
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 60),
        children: [
          // ── Avatar Card ──
          ClayContainer(
            color: baseColor,
            borderRadius: 24,
            depth: 20,
            spread: 1,
            padding: const EdgeInsets.all(24),
            shadowColor1: shadowColor1,
            shadowColor2: shadowColor2,
            child: Row(
              children: [
                Hero(
                  tag: 'admin_avatar',
                  child: ClayContainer(
                    color: baseColor,
                    borderRadius: 34,
                    depth: 15,
                    spread: 1,
                    width: 68,
                    height: 68,
                    shadowColor1: shadowColor1,
                    shadowColor2: shadowColor2,
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            theme.colorScheme.primary,
                            theme.colorScheme.primary.withValues(alpha: 0.7),
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        shape: BoxShape.circle,
                      ),
                      child: user?.avatarUrl != null
                          ? ClipOval(
                              child: Image.network(
                                user!.avatarUrl!,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => const Icon(
                                  PhosphorIconsFill.user,
                                  color: Colors.white,
                                  size: 30,
                                ),
                              ),
                            )
                          : const Icon(
                              PhosphorIconsFill.user,
                              color: Colors.white,
                              size: 30,
                            ),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        user?.fullName ?? 'Administrator',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                          color: textColor,
                          letterSpacing: -0.3,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        user?.email ?? '',
                        style: GoogleFonts.plusJakartaSans(
                          fontSize: 13,
                          color: textColor.withValues(alpha: 0.5),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 10,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          color: theme.colorScheme.primary.withValues(
                            alpha: 0.12,
                          ),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              PhosphorIconsFill.shieldStar,
                              size: 13,
                              color: theme.colorScheme.primary,
                            ),
                            const SizedBox(width: 5),
                            Text(
                              'Administrator',
                              style: GoogleFonts.plusJakartaSans(
                                color: theme.colorScheme.primary,
                                fontWeight: FontWeight.w600,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          _buildDivider(dividerColor),

          // ── Appearance ──
          _SectionHeader(
            icon: PhosphorIconsRegular.paintBrush,
            label: 'APPEARANCE',
            textColor: textColor,
            theme: theme,
          ),
          const SizedBox(height: 12),
          _ClayThemeSelector(
            currentMode: themeMode,
            onChanged: (mode) =>
                ref.read(themeModeProvider.notifier).setThemeMode(mode),
            baseColor: baseColor,
            textColor: textColor,
            theme: theme,
            shadowColor1: shadowColor1,
            shadowColor2: shadowColor2,
          ),

          _buildDivider(dividerColor),

          // ── Management ──
          _SectionHeader(
            icon: PhosphorIconsRegular.usersThree,
            label: 'MANAGEMENT',
            textColor: textColor,
            theme: theme,
          ),
          const SizedBox(height: 12),
          _ClaySettingsItem(
            icon: PhosphorIconsRegular.usersThree,
            title: 'Manage Workers',
            subtitle: 'Add, edit or remove workers',
            baseColor: baseColor,
            textColor: textColor,
            theme: theme,
            shadowColor1: shadowColor1,
            shadowColor2: shadowColor2,
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const WorkersManagementPage()),
            ),
          ),
          const SizedBox(height: 12),
          _ClaySettingsItem(
            icon: PhosphorIconsRegular.tag,
            title: 'Service Pricing',
            subtitle: 'Manage service prices & availability',
            baseColor: baseColor,
            textColor: textColor,
            theme: theme,
            shadowColor1: shadowColor1,
            shadowColor2: shadowColor2,
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ServicePricingPage()),
            ),
          ),

          _buildDivider(dividerColor),

          // ── General ──
          _SectionHeader(
            icon: PhosphorIconsRegular.gear,
            label: 'GENERAL',
            textColor: textColor,
            theme: theme,
          ),
          const SizedBox(height: 12),
          _ClaySettingsItem(
            icon: PhosphorIconsRegular.info,
            title: 'About Nexify',
            subtitle: 'Version ${AppInfoService.version}',
            baseColor: baseColor,
            textColor: textColor,
            theme: theme,
            shadowColor1: shadowColor1,
            shadowColor2: shadowColor2,
            onTap: () => showAboutDialog(
              context: context,
              applicationName: 'Nexify',
              applicationVersion: AppInfoService.version,
              applicationIcon: Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      theme.colorScheme.primary,
                      theme.colorScheme.primary.withValues(alpha: 0.7),
                    ],
                  ),
                  borderRadius: BorderRadius.circular(14),
                ),
                child: const Icon(
                  PhosphorIconsFill.buildings,
                  color: Colors.white,
                  size: 28,
                ),
              ),
            ),
          ),

          _buildDivider(dividerColor),

          // ── Logout ──
          Material(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(18),
            child: InkWell(
              onTap: () => _logout(context, ref),
              borderRadius: BorderRadius.circular(18),
              splashColor: Colors.redAccent.withValues(alpha: 0.1),
              highlightColor: Colors.redAccent.withValues(alpha: 0.05),
              child: ClayContainer(
                color: baseColor,
                borderRadius: 18,
                depth: 15,
                spread: 1,
                shadowColor1: shadowColor1,
                shadowColor2: shadowColor2,
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      PhosphorIconsFill.signOut,
                      color: Colors.redAccent,
                      size: 22,
                    ),
                    const SizedBox(width: 10),
                    Text(
                      'Logout',
                      style: GoogleFonts.plusJakartaSans(
                        color: Colors.redAccent,
                        fontWeight: FontWeight.w700,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Section Header ──
class _SectionHeader extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color textColor;
  final ThemeData theme;

  const _SectionHeader({
    required this.icon,
    required this.label,
    required this.textColor,
    required this.theme,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(
          icon,
          size: 14,
          color: theme.colorScheme.primary.withValues(alpha: 0.6),
        ),
        const SizedBox(width: 8),
        Text(
          label,
          style: GoogleFonts.plusJakartaSans(
            fontSize: 12,
            fontWeight: FontWeight.w700,
            color: textColor.withValues(alpha: 0.4),
            letterSpacing: 1.5,
          ),
        ),
      ],
    );
  }
}

// ── Clay Settings Item ──
class _ClaySettingsItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color baseColor;
  final Color textColor;
  final ThemeData theme;
  final Color shadowColor1;
  final Color shadowColor2;
  final VoidCallback onTap;

  const _ClaySettingsItem({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.baseColor,
    required this.textColor,
    required this.theme,
    required this.shadowColor1,
    required this.shadowColor2,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: ClayContainer(
        color: baseColor,
        borderRadius: 18,
        depth: 15,
        spread: 1,
        shadowColor1: shadowColor1,
        shadowColor2: shadowColor2,
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            ClayContainer(
              color: baseColor,
              borderRadius: 12,
              depth: -8,
              spread: 0,
              emboss: true,
              width: 40,
              height: 40,
              shadowColor1: shadowColor1,
              shadowColor2: shadowColor2,
              child: Icon(icon, color: theme.colorScheme.primary, size: 20),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: GoogleFonts.plusJakartaSans(
                      fontWeight: FontWeight.w700,
                      fontSize: 15,
                      color: textColor,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 13,
                      color: textColor.withValues(alpha: 0.45),
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              PhosphorIconsRegular.caretRight,
              color: textColor.withValues(alpha: 0.25),
              size: 18,
            ),
          ],
        ),
      ),
    );
  }
}

// ── Clay Theme Selector ──
class _ClayThemeSelector extends StatelessWidget {
  final ThemeMode currentMode;
  final ValueChanged<ThemeMode> onChanged;
  final Color baseColor;
  final Color textColor;
  final ThemeData theme;
  final Color shadowColor1;
  final Color shadowColor2;

  const _ClayThemeSelector({
    required this.currentMode,
    required this.onChanged,
    required this.baseColor,
    required this.textColor,
    required this.theme,
    required this.shadowColor1,
    required this.shadowColor2,
  });

  @override
  Widget build(BuildContext context) {
    return ClayContainer(
      color: baseColor,
      borderRadius: 18,
      depth: -8,
      spread: 1,
      emboss: true,
      shadowColor1: shadowColor1,
      shadowColor2: shadowColor2,
      padding: const EdgeInsets.all(6),
      child: Row(
        children: [
          _ThemeOption(
            icon: PhosphorIconsRegular.sun,
            label: 'Light',
            isSelected: currentMode == ThemeMode.light,
            onTap: () => onChanged(ThemeMode.light),
            theme: theme,
            textColor: textColor,
          ),
          _ThemeOption(
            icon: PhosphorIconsRegular.moon,
            label: 'Dark',
            isSelected: currentMode == ThemeMode.dark,
            onTap: () => onChanged(ThemeMode.dark),
            theme: theme,
            textColor: textColor,
          ),
          _ThemeOption(
            icon: PhosphorIconsRegular.monitor,
            label: 'System',
            isSelected: currentMode == ThemeMode.system,
            onTap: () => onChanged(ThemeMode.system),
            theme: theme,
            textColor: textColor,
          ),
        ],
      ),
    );
  }
}

class _ThemeOption extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  final ThemeData theme;
  final Color textColor;

  const _ThemeOption({
    required this.icon,
    required this.label,
    required this.isSelected,
    required this.onTap,
    required this.theme,
    required this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? theme.colorScheme.primary : Colors.transparent,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            children: [
              Icon(
                icon,
                size: 20,
                color: isSelected
                    ? Colors.white
                    : textColor.withValues(alpha: 0.5),
              ),
              const SizedBox(height: 4),
              Text(
                label,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 12,
                  fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                  color: isSelected
                      ? Colors.white
                      : textColor.withValues(alpha: 0.5),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
