// lib/features/admin/providers/admin_provider.dart
// ViewModel layer for the Admin feature — MVVM pattern via Riverpod.

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';
import 'package:nes/features/admin/models/admin_models.dart';
import 'package:nes/services/admin_api_service.dart';

// ─────────────────────────────────────────────
// State
// ─────────────────────────────────────────────

class AdminState {
  final List<AdminRequest> requests;
  final AdminStats? stats;
  final bool isLoading;
  final String? error;
  final String
  selectedFilter; // 'all' | 'pending' | 'in_progress' | 'completed'

  const AdminState({
    this.requests = const [],
    this.stats,
    this.isLoading = false,
    this.error,
    this.selectedFilter = 'all',
  });

  List<AdminRequest> get filteredRequests {
    if (selectedFilter == 'all') return requests;
    return requests.where((r) => r.status == selectedFilter).toList();
  }

  AdminState copyWith({
    List<AdminRequest>? requests,
    AdminStats? stats,
    bool? isLoading,
    String? error,
    String? selectedFilter,
    bool clearError = false,
  }) {
    return AdminState(
      requests: requests ?? this.requests,
      stats: stats ?? this.stats,
      isLoading: isLoading ?? this.isLoading,
      error: clearError ? null : (error ?? this.error),
      selectedFilter: selectedFilter ?? this.selectedFilter,
    );
  }
}

// ─────────────────────────────────────────────
// Notifier (ViewModel)
// ─────────────────────────────────────────────

class AdminNotifier extends StateNotifier<AdminState> {
  final Ref _ref;

  AdminNotifier(this._ref) : super(const AdminState());

  String? get _token => _ref.read(authProvider).token;

  /// Load requests and stats in parallel.
  Future<void> loadData() async {
    final token = _token;
    if (token == null) {
      state = state.copyWith(
        isLoading: false,
        error: 'Authentication required. Please log in again.',
      );
      return;
    }

    state = state.copyWith(isLoading: true, clearError: true);

    final results = await Future.wait([
      AdminApiService.getAllRequests(token),
      AdminApiService.getAdminStats(token),
    ]);

    final requestsResult = results[0];
    final statsResult = results[1];

    List<AdminRequest> requests = state.requests;
    AdminStats? stats = state.stats;
    String? error;

    if (requestsResult['success'] == true) {
      final raw = requestsResult['requests'] as List;
      requests = raw.map((r) => AdminRequest.fromJson(r)).toList();
    } else {
      error = requestsResult['error'] as String? ?? 'Failed to load requests';
    }

    if (statsResult['success'] == true) {
      stats = AdminStats.fromJson(statsResult['stats']);
    }

    state = state.copyWith(
      requests: requests,
      stats: stats,
      isLoading: false,
      error: error,
    );
  }

  /// Change the active filter tab.
  void setFilter(String filter) {
    state = state.copyWith(selectedFilter: filter, clearError: true);
  }

  /// Update a request's status. Optimistically updates local list, then syncs.
  Future<bool> updateRequestStatus({
    required String requestId,
    required String newStatus,
    String? note,
  }) async {
    final token = _token;
    if (token == null) return false;

    // Optimistic update
    final updated = state.requests.map((r) {
      if (r.id == requestId) {
        return AdminRequest(
          id: r.id,
          clientId: r.clientId,
          clientName: r.clientName,
          clientAvatar: r.clientAvatar,
          services: r.services,
          description: r.description,
          status: newStatus,
          assignedWorkerId: r.assignedWorkerId,
          assignedWorkerName: r.assignedWorkerName,
          createdAt: r.createdAt,
          deadline: r.deadline,
          uploadedFiles: r.uploadedFiles,
          note: note ?? r.note,
        );
      }
      return r;
    }).toList();
    state = state.copyWith(requests: updated);

    final result = await AdminApiService.updateRequestStatus(
      token: token,
      requestId: requestId,
      status: newStatus,
      note: note,
    );

    if (result['success'] == true) {
      await loadData();
      return true;
    } else {
      state = state.copyWith(
        error: result['error'] as String? ?? 'Failed to update status',
      );
      await loadData();
      return false;
    }
  }

  /// Delete a request.
  Future<bool> deleteRequest(String requestId) async {
    final token = _token;
    if (token == null) return false;

    final result = await AdminApiService.deleteRequest(
      token: token,
      requestId: requestId,
    );

    if (result['success'] == true) {
      state = state.copyWith(
        requests: state.requests.where((r) => r.id != requestId).toList(),
      );
      // Refresh stats too
      await loadData();
      return true;
    } else {
      state = state.copyWith(
        error: result['error'] as String? ?? 'Failed to delete request',
      );
      return false;
    }
  }

  void clearError() => state = state.copyWith(clearError: true);
}

// ─────────────────────────────────────────────
// Provider
// ─────────────────────────────────────────────

final adminProvider = StateNotifierProvider<AdminNotifier, AdminState>((ref) {
  final notifier = AdminNotifier(ref);
  // Auto-load when the provider is first read.
  notifier.loadData();
  return notifier;
});
