// lib/features/admin/models/admin_models.dart

class AdminRequest {
  final String id;
  final String clientId;
  final String clientName;
  final String? clientAvatar;
  final List<String> services;
  final String description;
  final String status;
  final String? assignedWorkerId;
  final String? assignedWorkerName;
  final DateTime createdAt;
  final DateTime? deadline;
  final List<String>? uploadedFiles;
  final String? note;

  AdminRequest({
    required this.id,
    required this.clientId,
    required this.clientName,
    this.clientAvatar,
    required this.services,
    required this.description,
    required this.status,
    this.assignedWorkerId,
    this.assignedWorkerName,
    required this.createdAt,
    this.deadline,
    this.uploadedFiles,
    this.note,
  });

  factory AdminRequest.fromJson(Map<String, dynamic> json) {
    return AdminRequest(
      id: json['_id'] ?? '',
      clientId: json['clientId'] ?? '',
      clientName: json['clientName'] ?? 'Unknown',
      clientAvatar: json['clientAvatar'],
      services: List<String>.from(json['services'] ?? []),
      description: json['description'] ?? '',
      status: json['status'] ?? 'pending',
      assignedWorkerId: json['assignedWorkerId'],
      assignedWorkerName: json['assignedWorkerName'],
      createdAt: DateTime.tryParse(json['createdAt'] ?? '') ?? DateTime.now(),
      deadline: json['deadline'] != null
          ? DateTime.tryParse(json['deadline'])
          : null,
      uploadedFiles: json['uploadedFiles'] != null
          ? List<String>.from(json['uploadedFiles'])
          : null,
      note: json['note'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'clientId': clientId,
      'clientName': clientName,
      'clientAvatar': clientAvatar,
      'services': services,
      'description': description,
      'status': status,
      'assignedWorkerId': assignedWorkerId,
      'assignedWorkerName': assignedWorkerName,
      'createdAt': createdAt.toIso8601String(),
      'deadline': deadline?.toIso8601String(),
      'uploadedFiles': uploadedFiles,
      'note': note,
    };
  }
}

class Worker {
  final String id;
  final String name;
  final String email;
  final String? avatar;
  final List<String> skills;
  final int activeProjects;
  final int completedProjects;
  final double rating;
  final bool isAvailable;
  final String? phone;

  Worker({
    required this.id,
    required this.name,
    required this.email,
    this.avatar,
    required this.skills,
    required this.activeProjects,
    required this.completedProjects,
    required this.rating,
    required this.isAvailable,
    this.phone,
  });

  factory Worker.fromJson(Map<String, dynamic> json) {
    final workerProfile = json['workerProfile'] ?? <String, dynamic>{};
    return Worker(
      id: json['_id']?.toString() ?? '',
      name: json['fullName']?.toString() ?? 'Unknown',
      email: json['email']?.toString() ?? '',
      avatar: json['avatarUrl']?.toString(),
      skills: List<String>.from(workerProfile['skills'] ?? []),
      activeProjects: workerProfile['activeProjects'] ?? 0,
      completedProjects: workerProfile['completedProjects'] ?? 0,
      rating: (workerProfile['rating'] ?? 0.0).toDouble(),
      isAvailable: workerProfile['isAvailable'] ?? true,
      phone: workerProfile['phone']?.toString(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      '_id': id,
      'fullName': name,
      'email': email,
      'avatarUrl': avatar,
      'workerProfile': {
        'skills': skills,
        'activeProjects': activeProjects,
        'completedProjects': completedProjects,
        'rating': rating,
        'isAvailable': isAvailable,
        'phone': phone,
      },
    };
  }

  // Helper method to get avatar URL with fallback
  String getAvatarUrl() {
    return avatar ??
        'https://ui-avatars.com/api/?name=${Uri.encodeComponent(name)}&background=random';
  }
}

class AdminStats {
  final int totalRequests;
  final int pending;
  final int inProgress;
  final int completed;
  final int workers;

  AdminStats({
    required this.totalRequests,
    required this.pending,
    required this.inProgress,
    required this.completed,
    required this.workers,
  });

  factory AdminStats.fromJson(Map<String, dynamic> json) {
    return AdminStats(
      totalRequests: json['totalRequests'] ?? 0,
      pending: json['pending'] ?? 0,
      inProgress: json['inProgress'] ?? 0,
      completed: json['completed'] ?? 0,
      workers: json['workers'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'totalRequests': totalRequests,
      'pending': pending,
      'inProgress': inProgress,
      'completed': completed,
      'workers': workers,
    };
  }
}
