// lib/features/auth/models/user_model.dart
// User model for the app

class UserModel {
  final String id;
  final String email;
  final String fullName;
  final String role; // 'client', 'worker', 'admin'
  final String? avatarUrl;
  final String? phone;
  final WorkerProfile? workerProfile;
  final DateTime createdAt;

  UserModel({
    required this.id,
    required this.email,
    required this.fullName,
    required this.role,
    this.avatarUrl,
    this.phone,
    this.workerProfile,
    required this.createdAt,
  });

  // Create from JSON (from API response)
  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['id'] ?? json['_id'] ?? '',
      email: json['email'] ?? '',
      fullName: json['fullName'] ?? '',
      role: json['role'] ?? 'client',
      avatarUrl: json['avatarUrl'],
      phone: json['phone'],
      workerProfile: json['workerProfile'] != null
          ? WorkerProfile.fromJson(json['workerProfile'])
          : null,
      createdAt: json['createdAt'] != null
          ? (DateTime.tryParse(json['createdAt'].toString()) ?? DateTime.now())
          : DateTime.now(),
    );
  }

  // Convert to JSON
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'email': email,
      'fullName': fullName,
      'role': role,
      'avatarUrl': avatarUrl,
      'phone': phone,
      'workerProfile': workerProfile?.toJson(),
      'createdAt': createdAt.toIso8601String(),
    };
  }

  // Helper getters
  bool get isClient => role == 'client';
  bool get isWorker => role == 'worker';
  bool get isAdmin => role == 'admin';

  // Copy with method
  UserModel copyWith({
    String? id,
    String? email,
    String? fullName,
    String? role,
    String? avatarUrl,
    String? phone,
    WorkerProfile? workerProfile,
    DateTime? createdAt,
  }) {
    return UserModel(
      id: id ?? this.id,
      email: email ?? this.email,
      fullName: fullName ?? this.fullName,
      role: role ?? this.role,
      avatarUrl: avatarUrl ?? this.avatarUrl,
      phone: phone ?? this.phone,
      workerProfile: workerProfile ?? this.workerProfile,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}

class WorkerProfile {
  final List<String> skills;
  final int activeProjects;
  final int completedProjects;
  final double rating;
  final bool isAvailable;
  final String? phone;

  WorkerProfile({
    required this.skills,
    required this.activeProjects,
    required this.completedProjects,
    required this.rating,
    required this.isAvailable,
    this.phone,
  });

  factory WorkerProfile.fromJson(Map<String, dynamic> json) {
    return WorkerProfile(
      skills: List<String>.from(json['skills'] ?? []),
      activeProjects: json['activeProjects'] ?? 0,
      completedProjects: json['completedProjects'] ?? 0,
      rating: (json['rating'] ?? 0).toDouble(),
      isAvailable: json['isAvailable'] ?? true,
      phone: json['phone'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'skills': skills,
      'activeProjects': activeProjects,
      'completedProjects': completedProjects,
      'rating': rating,
      'isAvailable': isAvailable,
      'phone': phone,
    };
  }
}
