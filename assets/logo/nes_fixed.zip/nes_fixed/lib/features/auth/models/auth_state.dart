// lib/features/auth/models/auth_state.dart
// Represents authentication state

import 'user_model.dart';

class AuthState {
  final UserModel? user;
  final String? token;
  final bool isLoading;
  final String? error;
  final bool hasSeenOnboarding;

  AuthState({
    this.user,
    this.token,
    this.isLoading = false,
    this.error,
    this.hasSeenOnboarding = false,
  });

  // Initial state - not logged in (w/ default false)
  factory AuthState.initial() {
    return AuthState(
      user: null,
      token: null,
      isLoading: false,
      error: null,
      hasSeenOnboarding: false,
    );
  }

  // Loading state (instance helper)
  AuthState loading() {
    return AuthState(
      user: user,
      token: token,
      isLoading: true,
      error: null,
      hasSeenOnboarding: hasSeenOnboarding,
    );
  }

  // Success state
  AuthState success({UserModel? user, String? token}) {
    return AuthState(
      user: user ?? this.user,
      token: token ?? this.token,
      isLoading: false,
      error: null,
      hasSeenOnboarding: hasSeenOnboarding,
    );
  }

  // Error state
  AuthState failure(String? error) {
    return AuthState(
      user: user,
      token: token,
      isLoading: false,
      error: error,
      hasSeenOnboarding: hasSeenOnboarding,
    );
  }

  // Logout state
  AuthState logout() {
    return AuthState(
      user: null,
      token: null,
      isLoading: false,
      error: null,
      hasSeenOnboarding: hasSeenOnboarding,
    );
  }

  // Helpers
  bool get isAuthenticated => user != null && token != null;
  bool get isClient => user?.isClient ?? false;
  bool get isWorker => user?.isWorker ?? false;
  bool get isAdmin => user?.isAdmin ?? false;
}
