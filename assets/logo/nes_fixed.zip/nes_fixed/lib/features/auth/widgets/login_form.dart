import 'package:flutter/material.dart';
import 'package:nes/core/widgets/clay_container.dart';

class LoginForm extends StatefulWidget {
  final GlobalKey<FormState> formKey;
  final TextEditingController emailController;
  final TextEditingController passwordController;
  final VoidCallback? onSubmit;
  final VoidCallback? onSwitchToRegister;
  final VoidCallback? onGoogleSubmit;
  final VoidCallback? onForgotPassword;
  final bool isLoading;

  const LoginForm({
    super.key,
    required this.formKey,
    required this.emailController,
    required this.passwordController,
    this.onSubmit,
    this.onSwitchToRegister,
    this.onGoogleSubmit,
    this.onForgotPassword,
    this.isLoading = false,
  });

  @override
  State<LoginForm> createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  bool _obscurePassword = true;

  String? _validateEmail(String? value) {
    if (value == null || value.trim().isEmpty) return 'Email is required';
    final emailRegex = RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$');
    if (!emailRegex.hasMatch(value.trim()))
      return 'Enter a valid email address';
    return null;
  }

  String? _validatePassword(String? value) {
    if (value == null || value.isEmpty) return 'Password is required';
    if (value.length < 6) return 'Password must be at least 6 characters';
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    return Form(
      key: widget.formKey,
      child: Column(
        key: const ValueKey('login'),
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Welcome text
          AnimatedListItem(
            index: 0,
            child: Text(
              'Welcome back',
              style: theme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const SizedBox(height: 6),
          AnimatedListItem(
            index: 1,
            child: Text(
              'Sign in to continue managing your services',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurface.withValues(alpha: 0.5),
              ),
            ),
          ),
          const SizedBox(height: 24),

          // Email field
          AnimatedListItem(
            index: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Email',
                  style: theme.textTheme.labelMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),
                TextFormField(
                  controller: widget.emailController,
                  enabled: !widget.isLoading,
                  keyboardType: TextInputType.emailAddress,
                  textInputAction: TextInputAction.next,
                  decoration: const InputDecoration(
                    hintText: 'you@example.com',
                    prefixIcon: Icon(Icons.email_outlined, size: 20),
                  ),
                  validator: _validateEmail,
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Password field with eye toggle
          AnimatedListItem(
            index: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Password',
                  style: theme.textTheme.labelMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),
                TextFormField(
                  controller: widget.passwordController,
                  enabled: !widget.isLoading,
                  obscureText: _obscurePassword,
                  textInputAction: TextInputAction.done,
                  decoration: InputDecoration(
                    hintText: 'Enter password',
                    prefixIcon: const Icon(Icons.lock_outline, size: 20),
                    suffixIcon: IconButton(
                      icon: Icon(
                        _obscurePassword
                            ? Icons.visibility_off_outlined
                            : Icons.visibility_outlined,
                        size: 20,
                        color: theme.colorScheme.onSurface.withValues(alpha: 0.5),
                      ),
                      onPressed: () =>
                          setState(() => _obscurePassword = !_obscurePassword),
                    ),
                  ),
                  validator: _validatePassword,
                  onFieldSubmitted: (_) {
                    if (!widget.isLoading) {
                      if (widget.formKey.currentState?.validate() ?? false) {
                        widget.onSubmit?.call();
                      }
                    }
                  },
                ),
              ],
            ),
          ),
          const SizedBox(height: 24),

          // Sign in button
          AnimatedListItem(
            index: 4,
            child: ClayButton(
              text: 'Sign in',
              isLoading: widget.isLoading,
              onPressed: widget.isLoading
                  ? null
                  : () {
                      if (widget.formKey.currentState?.validate() ?? false) {
                        widget.onSubmit?.call();
                      }
                    },
            ),
          ),

          const SizedBox(height: 12),

          // Forgot password and Create account
          AnimatedListItem(
            index: 5,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                TextButton(
                  onPressed: widget.isLoading ? null : widget.onForgotPassword,
                  child: const Text('Forgot password?'),
                ),
                TextButton(
                  onPressed: widget.isLoading ? null : widget.onSwitchToRegister,
                  child: const Text('Create account'),
                ),
              ],
            ),
          ),

          const SizedBox(height: 8),

          // Divider
          AnimatedListItem(
            index: 6,
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    height: 1,
                    color: isDark
                        ? Colors.white.withValues(alpha: 0.08)
                        : Colors.black.withValues(alpha: 0.06),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Text(
                    'or',
                    style: TextStyle(
                      color: theme.colorScheme.onSurface.withValues(alpha: 0.4),
                      fontSize: 13,
                    ),
                  ),
                ),
                Expanded(
                  child: Container(
                    height: 1,
                    color: isDark
                        ? Colors.white.withValues(alpha: 0.08)
                        : Colors.black.withValues(alpha: 0.06),
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 14),

          // Google Sign-In button
          AnimatedListItem(
            index: 7,
            child: SizedBox(
              height: 52,
              child: OutlinedButton.icon(
                onPressed: widget.isLoading ? null : widget.onGoogleSubmit,
                icon: Image.asset(
                  'assets/google_logo.png',
                  height: 22,
                  width: 22,
                  errorBuilder: (context, error, stackTrace) {
                    return const Icon(Icons.g_mobiledata, size: 22);
                  },
                ),
                label: const Text('Continue with Google'),
                style: OutlinedButton.styleFrom(
                  side: BorderSide(
                    color: isDark
                        ? Colors.white.withValues(alpha: 0.12)
                        : Colors.black.withValues(alpha: 0.08),
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
