import 'package:flutter/material.dart';

class SegmentedControl extends StatefulWidget {
  final bool isLoginSelected;
  final ValueChanged<bool> onSelectionChanged;

  const SegmentedControl({
    super.key,
    required this.isLoginSelected,
    required this.onSelectionChanged,
  });

  @override
  State<SegmentedControl> createState() => _SegmentedControlState();
}

class _SegmentedControlState extends State<SegmentedControl> {
  bool _isAnimating = false;

  void _handleTap(bool value) {
    if (_isAnimating) return;

    if (value != widget.isLoginSelected) {
      setState(() => _isAnimating = true);
      widget.onSelectionChanged(value);
      Future.delayed(const Duration(milliseconds: 250), () {
        if (mounted) setState(() => _isAnimating = false);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final primary = theme.colorScheme.primary;

    return Container(
      height: 56,
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: isDark
            ? Colors.white.withValues(alpha: 0.06)
            : Colors.black.withValues(alpha: 0.04),
        borderRadius: BorderRadius.circular(16),
        // Clay emboss
        boxShadow: [
          BoxShadow(
            color: isDark
                ? Colors.black.withValues(alpha: 0.3)
                : Colors.black.withValues(alpha: 0.06),
            offset: const Offset(2, 2),
            blurRadius: 4,
            spreadRadius: -1,
          ),
          BoxShadow(
            color: isDark
                ? Colors.white.withValues(alpha: 0.03)
                : Colors.white.withValues(alpha: 0.8),
            offset: const Offset(-1, -1),
            blurRadius: 4,
            spreadRadius: -1,
          ),
        ],
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final pillWidth = (constraints.maxWidth / 2) - 2;
          return Stack(
            children: [
              // Animated pill
              AnimatedAlign(
                duration: const Duration(milliseconds: 280),
                curve: Curves.easeOutCubic,
                alignment: widget.isLoginSelected
                    ? Alignment.centerLeft
                    : Alignment.centerRight,
                child: Container(
                  height: 48,
                  width: pillWidth,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(13),
                    gradient: LinearGradient(
                      colors: [
                        primary,
                        primary.withValues(alpha: 0.85),
                      ],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: primary.withValues(alpha: 0.35),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                    ],
                  ),
                ),
              ),
              // Buttons
              Row(
                children: [
                  _buildButton(
                    context: context,
                    label: 'Login',
                    isSelected: widget.isLoginSelected,
                    onTap: () => _handleTap(true),
                  ),
                  _buildButton(
                    context: context,
                    label: 'Register',
                    isSelected: !widget.isLoginSelected,
                    onTap: () => _handleTap(false),
                  ),
                ],
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildButton({
    required BuildContext context,
    required String label,
    required bool isSelected,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(13),
          onTap: onTap,
          child: SizedBox(
            height: 48,
            child: Center(
              child: AnimatedDefaultTextStyle(
                duration: const Duration(milliseconds: 200),
                style: Theme.of(context).textTheme.bodyLarge!.copyWith(
                  color: isSelected
                      ? Colors.white
                      : Theme.of(context)
                          .colorScheme
                          .onSurface
                          .withValues(alpha: 0.5),
                  fontWeight: isSelected ? FontWeight.w700 : FontWeight.w500,
                  fontSize: 15,
                ),
                child: Text(label),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
