// lib/features/auth/providers/auth_provider.dart
// Riverpod providers for authentication - FIXED VERSION (Option B)

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';
import '../models/auth_state.dart';
import '../models/user_model.dart';
import '../repositories/auth_repository.dart';

// ==================================
// AUTH REPOSITORY PROVIDER
// ==================================
final authRepositoryProvider = Provider<AuthRepository>((ref) {
  return AuthRepository();
});

// ==================================
// INITIAL AUTH CHECK STATE
// ==================================
final initialAuthCheckProvider = StateProvider<bool>((ref) => false);

// ==================================
// AUTH STATE PROVIDER
// ==================================
class AuthNotifier extends StateNotifier<AuthState> {
  final AuthRepository _repository;
  final Ref _ref;

  AuthNotifier(this._repository, this._ref) : super(AuthState.initial()) {
    // set loading immediately (instance method)
    state = state.loading();
    // Check if user is already logged in when app starts
    _checkAuthStatus();
  }

  // Check if user is logged in
  Future<void> _checkAuthStatus() async {
    // Read onboarding status first — we must preserve it in all branches
    bool hasSeenOnboarding = false;
    try {
      hasSeenOnboarding = await _repository.hasCompletedOnboarding();
    } catch (_) {
      // SharedPreferences failure on first install — treat as not seen
    }

    try {
      final token = await _repository.getToken();

      if (token != null && token.isNotEmpty) {
        // Get user profile
        final result = await _repository.getProfile(token);

        if (result['success']) {
          // Token is valid, user is logged in
          state = AuthState(
            user: result['user'],
            token: token,
            isLoading: false,
            hasSeenOnboarding: hasSeenOnboarding,
          );
        } else {
          // Token invalid, remove it
          await _repository.deleteToken();
          state = AuthState(hasSeenOnboarding: hasSeenOnboarding);
        }
      } else {
        // No token found, not authenticated
        state = AuthState(hasSeenOnboarding: hasSeenOnboarding);
      }
    } catch (e) {
      // Error checking auth — preserve onboarding flag so app doesn't
      // restart onboarding flow on network errors or cold-start timeouts
      try {
        await _repository.deleteToken();
      } catch (_) {}
      state = AuthState(hasSeenOnboarding: hasSeenOnboarding);
    } finally {
      // Mark auth check as complete
      _ref.read(initialAuthCheckProvider.notifier).state = true;
    }
  }

  // COMPLETE ONBOARDING
  Future<void> completeOnboarding() async {
    await _repository.completeOnboarding();
    state = AuthState(
      user: state.user,
      token: state.token,
      isLoading: false,
      error: null,
      hasSeenOnboarding: true,
    );
  }

  // Called by EmailVerificationPage after polling detects verification
  void setAuthenticatedState(UserModel user, String token) {
    state = state.success(user: user, token: token);
  }

  // SIGN UP
  // Returns a map so the UI can decide what to do:
  //   { 'requiresVerification': true, 'email': '...' } — navigate to verification page
  //   { 'error': '...' } — show error
  Future<Map<String, dynamic>> signUp({
    required String email,
    required String password,
    required String fullName,
    String? phone,
  }) async {
    state = state.loading();

    final result = await _repository.signUp(
      email: email,
      password: password,
      fullName: fullName,
      phone: phone,
    );

    if (result['success'] == true && result['requiresVerification'] == true) {
      // Not logged in yet — email verification required
      state = state.failure(null); // back to unauthenticated, no error text
      return {'requiresVerification': true, 'email': result['email']};
    } else {
      state = state.failure(result['error']);
      return {'error': result['error']};
    }
  }

  // LOGIN
  // Returns a map so the UI can handle EMAIL_NOT_VERIFIED specially
  Future<Map<String, dynamic>> login({
    required String email,
    required String password,
  }) async {
    state = state.loading();

    final result = await _repository.login(email: email, password: password);

    if (result['success'] == true) {
      final user = result['user'] as UserModel;
      final token = result['token'] as String;
      await _repository.saveToken(token);
      state = state.success(user: user, token: token);
      return {'success': true};
    } else if (result['error'] == 'EMAIL_NOT_VERIFIED') {
      state = state.failure(null);
      return {'error': 'EMAIL_NOT_VERIFIED', 'email': result['email']};
    } else {
      state = state.failure(result['error']);
      return {'error': result['error']};
    }
  }

  // FORGOT PASSWORD
  Future<bool> forgotPassword(String email) async {
    state = state.loading();
    final error = await _repository.forgotPassword(email);
    if (error == null) {
      state = state.failure(null); // Just clear loading state
      return true;
    } else {
      state = state.failure(error);
      return false;
    }
  }

  // GOOGLE SIGN-IN
  Future<void> googleSignIn() async {
    state = state.loading();

    final result = await _repository.signInWithGoogle();

    if (result['success']) {
      final user = result['user'] as UserModel;
      final token = result['token'] as String;

      // Save token
      await _repository.saveToken(token);

      // Update state
      state = state.success(user: user, token: token);
    } else {
      state = state.failure(result['error']);
    }
  }

  // LOGOUT
  Future<void> logout() async {
    await _repository.deleteToken();
    state = state.logout();
  }

  // UPDATE PROFILE
  Future<void> updateProfile({
    String? fullName,
    String? avatarUrl,
    String? phone,
  }) async {
    final token = state.token; // capture BEFORE loading() wipes it
    if (token == null) return;

    state = state.loading();

    final result = await _repository.updateProfile(
      token: token,
      fullName: fullName,
      avatarUrl: avatarUrl,
      phone: phone,
    );

    if (result['success']) {
      state = state.success(user: result['user']);
    } else {
      state = state.failure(result['error']);
    }
  }

  // CLEAR ERROR
  void clearError() {
    if (state.error != null) {
      state = AuthState(
        user: state.user,
        token: state.token,
        isLoading: false,
        error: null,
        hasSeenOnboarding: state.hasSeenOnboarding,
      );
    }
  }
}

// ==================================
// AUTH PROVIDER (Main provider)
// ==================================
final authProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  final repository = ref.watch(authRepositoryProvider);
  return AuthNotifier(repository, ref);
});

// ==================================
// CONVENIENCE PROVIDERS
// ==================================

// Current user
final currentUserProvider = Provider<UserModel?>((ref) {
  return ref.watch(authProvider).user;
});

// Is authenticated
final isAuthenticatedProvider = Provider<bool>((ref) {
  return ref.watch(authProvider).isAuthenticated;
});

// Is loading
final isLoadingProvider = Provider<bool>((ref) {
  return ref.watch(authProvider).isLoading;
});

// Current error
final authErrorProvider = Provider<String?>((ref) {
  return ref.watch(authProvider).error;
});

// Has completed initial auth check
final hasCheckedAuthProvider = Provider<bool>((ref) {
  return ref.watch(initialAuthCheckProvider);
});
