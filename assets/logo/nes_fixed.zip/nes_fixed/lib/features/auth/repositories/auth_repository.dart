// lib/features/auth/repositories/auth_repository.dart
// Handles all API calls for authentication

import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../models/user_model.dart';

class AuthRepository {
  // Backend deployed on Render - works from anywhere!
  static const String baseUrl =
      'https://nestoric-backend.onrender.com/api/auth';

  // Google Sign-In instance — serverClientId ensures idToken is always returned
  // This is the Web OAuth Client ID from the Firebase project
  final GoogleSignIn _googleSignIn = GoogleSignIn(
    serverClientId:
        '258491487709-qthfksr7s6pnf15ipuvjc3c8ddlivusu.apps.googleusercontent.com',
  );

  // ==================================
  // GOOGLE SIGN-IN
  // ==================================
  Future<Map<String, dynamic>> signInWithGoogle() async {
    try {
      // 1. Sign out first to force account picker to show
      await _googleSignIn.signOut();

      // 2. Trigger Google account picker
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();

      if (googleUser == null) {
        // User cancelled the picker
        return {'success': false, 'error': 'Google sign-in was cancelled'};
      }

      // 2. Get auth tokens from Google
      final GoogleSignInAuthentication googleAuth =
          await googleUser.authentication;

      // 3. Sign in to Firebase with Google credentials
      final OAuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleAuth.accessToken,
        idToken: googleAuth.idToken,
      );

      final UserCredential firebaseCredential = await FirebaseAuth.instance
          .signInWithCredential(credential);

      // 4. Get Firebase ID token to send to our backend
      final String? firebaseIdToken = await firebaseCredential.user
          ?.getIdToken();

      if (firebaseIdToken == null) {
        return {
          'success': false,
          'error': 'Failed to get authentication token',
        };
      }

      // 5. Send Firebase token to OUR backend
      final response = await http
          .post(
            Uri.parse('$baseUrl/google'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'idToken': firebaseIdToken}),
          )
          .timeout(const Duration(seconds: 30));

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return {
          'success': true,
          'user': UserModel.fromJson(data['user']),
          'token': data['token'],
        };
      } else {
        return {
          'success': false,
          'error': data['error'] ?? 'Google sign-in failed',
        };
      }
    } on FirebaseAuthException catch (e) {
      if (kDebugMode)
        print('🔴 FirebaseAuthException: code=${e.code}, message=${e.message}');
      return {
        'success': false,
        'error':
            '[Firebase] ${e.code}: ${e.message ?? 'Firebase authentication error'}',
      };
    } catch (e) {
      if (kDebugMode) print('🔴 Google sign-in error: $e');
      return {'success': false, 'error': 'Error: $e'};
    }
  }

  // ==================================
  // SIGN UP
  // ==================================
  Future<Map<String, dynamic>> signUp({
    required String email,
    required String password,
    required String fullName,
    String? phone,
  }) async {
    try {
      final response = await http
          .post(
            Uri.parse('$baseUrl/signup'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({
              'email': email,
              'password': password,
              'fullName': fullName,
              if (phone != null && phone.isNotEmpty) 'phone': phone,
            }),
          )
          .timeout(const Duration(seconds: 30));

      final data = jsonDecode(response.body);

      if (response.statusCode == 201 && data['requiresVerification'] == true) {
        // Email verification required — no JWT issued yet
        return {
          'success': true,
          'requiresVerification': true,
          'email': data['email'],
        };
      } else {
        return {
          'success': false,
          'error': data['error'] ?? 'Failed to sign up',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'error': 'Network error. Please check your connection.',
      };
    }
  }

  // ==================================
  // FORGOT / RESET PASSWORD
  // ==================================
  Future<String?> forgotPassword(String email) async {
    try {
      final response = await http
          .post(
            Uri.parse('$baseUrl/forgot-password'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'email': email}),
          )
          .timeout(const Duration(seconds: 30));

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return null; // success
      } else {
        return data['error'] ?? 'Failed to send reset email';
      }
    } catch (e) {
      return 'Network error. Please check your connection.';
    }
  }

  Future<String?> resetPassword(String token, String newPassword) async {
    try {
      final response = await http
          .post(
            Uri.parse('$baseUrl/reset-password'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'token': token, 'newPassword': newPassword}),
          )
          .timeout(const Duration(seconds: 30));

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return null; // success
      } else {
        return data['error'] ?? 'Failed to reset password';
      }
    } catch (e) {
      return 'Network error. Please check your connection.';
    }
  }

  // ==================================
  // LOGIN
  // ==================================
  Future<Map<String, dynamic>> login({
    required String email,
    required String password,
  }) async {
    try {
      final response = await http
          .post(
            Uri.parse('$baseUrl/login'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'email': email, 'password': password}),
          )
          .timeout(const Duration(seconds: 30));

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return {
          'success': true,
          'user': UserModel.fromJson(data['user']),
          'token': data['token'],
        };
      } else if (response.statusCode == 403 &&
          data['error'] == 'EMAIL_NOT_VERIFIED') {
        // Special case: account exists but email not yet verified
        return {
          'success': false,
          'error': 'EMAIL_NOT_VERIFIED',
          'email': data['email'],
        };
      } else {
        return {'success': false, 'error': data['error'] ?? 'Failed to login'};
      }
    } catch (e) {
      return {
        'success': false,
        'error': 'Network error. Please check your connection.',
      };
    }
  }

  // ==================================
  // RESEND VERIFICATION EMAIL
  // ==================================
  Future<Map<String, dynamic>> resendVerificationEmail(String email) async {
    try {
      final response = await http
          .post(
            Uri.parse('$baseUrl/resend-verification'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'email': email}),
          )
          .timeout(const Duration(seconds: 30));

      final data = jsonDecode(response.body);
      if (response.statusCode == 200) {
        return {'success': true, 'message': data['message']};
      } else {
        return {'success': false, 'error': data['error'] ?? 'Failed to resend'};
      }
    } catch (e) {
      return {
        'success': false,
        'error': 'Network error. Please check your connection.',
      };
    }
  }

  // ==================================
  // POLL: CHECK IF EMAIL WAS VERIFIED
  // ==================================
  Future<Map<String, dynamic>> checkVerification(String email) async {
    try {
      final response = await http
          .get(
            Uri.parse(
              '$baseUrl/check-verification?email=${Uri.encodeComponent(email)}',
            ),
            headers: {'Content-Type': 'application/json'},
          )
          .timeout(const Duration(seconds: 10));

      final data = jsonDecode(response.body);
      if (response.statusCode == 200 && data['verified'] == true) {
        return {
          'verified': true,
          'user': UserModel.fromJson(data['user']),
          'token': data['token'],
        };
      }
      return {'verified': false};
    } catch (_) {
      return {'verified': false};
    }
  }

  // ==================================
  // GET PROFILE
  // ==================================
  Future<Map<String, dynamic>> getProfile(String token) async {
    try {
      final response = await http
          .get(
            Uri.parse('$baseUrl/me'),
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer $token',
            },
          )
          .timeout(const Duration(seconds: 30));

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return {'success': true, 'user': UserModel.fromJson(data['user'])};
      } else {
        return {
          'success': false,
          'error': data['error'] ?? 'Failed to get profile',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'error': 'Network error. Please check your connection.',
      };
    }
  }

  // ==================================
  // UPDATE PROFILE
  // ==================================
  Future<Map<String, dynamic>> updateProfile({
    required String token,
    String? fullName,
    String? avatarUrl,
    String? phone,
  }) async {
    try {
      final response = await http
          .put(
            Uri.parse('$baseUrl/profile'),
            headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Bearer $token',
            },
            body: jsonEncode({
              if (fullName != null) 'fullName': fullName,
              if (avatarUrl != null) 'avatarUrl': avatarUrl,
              if (phone != null) 'phone': phone,
            }),
          )
          .timeout(const Duration(seconds: 30));

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return {'success': true, 'user': UserModel.fromJson(data['user'])};
      } else {
        return {
          'success': false,
          'error': data['error'] ?? 'Failed to update profile',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'error': 'Network error. Please check your connection.',
      };
    }
  }

  // ==================================
  // SAVE TOKEN TO LOCAL STORAGE
  // ==================================
  Future<void> saveToken(String token) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_token', token);
  }

  // ==================================
  // GET TOKEN FROM LOCAL STORAGE
  // ==================================
  Future<String?> getToken() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString('auth_token');
  }

  // ==================================
  // DELETE TOKEN (LOGOUT)
  // ==================================
  Future<void> deleteToken() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_token');

    // Also sign out from Google to clear cached account
    try {
      await _googleSignIn.signOut();
      await FirebaseAuth.instance.signOut();
    } catch (e) {
      // Ignore errors - token already deleted
    }
  }

  // ==================================
  // ONBOARDING STATUS
  // ==================================
  Future<void> completeOnboarding() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('onboarding_complete', true);
  }

  Future<bool> hasCompletedOnboarding() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('onboarding_complete') ?? false;
  }

  // ==================================
  // CHECK IF LOGGED IN
  // ==================================
  Future<bool> isLoggedIn() async {
    final token = await getToken();
    return token != null;
  }
}
