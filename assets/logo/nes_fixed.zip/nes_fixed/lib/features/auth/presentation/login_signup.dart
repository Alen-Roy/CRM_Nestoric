// lib/features/auth/presentation/login_signup.dart
// Premium clay-styled login/signup with Riverpod

import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nes/core/const.dart';
import 'package:nes/core/theme/app_colors.dart';
import 'package:nes/core/widgets/clay_container.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';
import 'package:nes/features/auth/models/user_model.dart';
import 'package:nes/features/auth/widgets/hero_banner.dart';
import 'package:nes/features/auth/widgets/login_form.dart';
import 'package:nes/features/auth/widgets/register_form.dart';
import 'package:nes/features/auth/widgets/segmented_control.dart';
import 'package:nes/app.dart';
import 'package:nes/features/auth/presentation/email_verification_page.dart';
import 'package:nes/features/auth/presentation/google_profile_setup_page.dart';
import 'package:nes/features/auth/presentation/forgot_password_page.dart';

class LoginSignup extends ConsumerStatefulWidget {
  const LoginSignup({super.key});

  @override
  ConsumerState<LoginSignup> createState() => _LoginSignupState();
}

class _LoginSignupState extends ConsumerState<LoginSignup>
    with SingleTickerProviderStateMixin {
  // Text controllers
  final _loginEmail = TextEditingController();
  final _loginPassword = TextEditingController();
  final _regName = TextEditingController();
  final _regEmail = TextEditingController();
  final _regPassword = TextEditingController();
  final _regPhone = TextEditingController();

  // Form keys
  final _loginKey = GlobalKey<FormState>();
  final _regKey = GlobalKey<FormState>();

  // UI state
  bool _isLoginSelected = true;

  // Background orb animation
  late AnimationController _orbController;

  @override
  void initState() {
    super.initState();
    _orbController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat();
  }

  @override
  void dispose() {
    _loginEmail.dispose();
    _loginPassword.dispose();
    _regName.dispose();
    _regEmail.dispose();
    _regPassword.dispose();
    _regPhone.dispose();
    _orbController.dispose();
    super.dispose();
  }

  Future<void> _googleSignIn() async {
    FocusScope.of(context).unfocus();
    await ref.read(authProvider.notifier).googleSignIn();

    if (!mounted) return;
    final authState = ref.read(authProvider);
    if (authState.isAuthenticated) {
      final phone = authState.user?.phone;
      if (phone == null || phone.isEmpty) {
        // Navigate to dedicated setup page — replaces current route
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const GoogleProfileSetupPage()),
        );
      } else {
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const AuthWrapper()),
          (route) => false,
        );
      }
    }
  }

  Future<void> _signIn() async {
    if (!_loginKey.currentState!.validate()) return;
    FocusScope.of(context).unfocus();
    final result = await ref
        .read(authProvider.notifier)
        .login(
          email: _loginEmail.text.trim(),
          password: _loginPassword.text.trim(),
        );

    if (!mounted) return;

    if (result['error'] == 'EMAIL_NOT_VERIFIED') {
      // Backend says not verified — but for admin-created workers,
      // the account may already be verified. Try checkVerification first.
      final email = result['email'] as String;
      final repo = ref.read(authRepositoryProvider);
      final verifyResult = await repo.checkVerification(email);

      if (!mounted) return;

      if (verifyResult['verified'] == true &&
          verifyResult['user'] is UserModel &&
          verifyResult['token'] is String) {
        // Email IS verified — auto-login directly
        final user = verifyResult['user'] as UserModel;
        final token = verifyResult['token'] as String;
        await repo.saveToken(token);
        ref.read(authProvider.notifier).setAuthenticatedState(user, token);
        if (!mounted) return;
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const AuthWrapper()),
          (route) => false,
        );
      } else {
        // Still not verified — show verification page
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => EmailVerificationPage(email: email),
          ),
        );
      }
    } else if (ref.read(authProvider).isAuthenticated) {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const AuthWrapper()),
        (route) => false,
      );
    }
  }

  Future<void> _register() async {
    if (!_regKey.currentState!.validate()) return;
    FocusScope.of(context).unfocus();
    final result = await ref
        .read(authProvider.notifier)
        .signUp(
          email: _regEmail.text.trim(),
          password: _regPassword.text.trim(),
          fullName: _regName.text.trim(),
          phone: _regPhone.text.trim(),
        );

    if (!mounted) return;

    if (result['requiresVerification'] == true) {
      // Navigate to verification page — user cannot log in until email is verified
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (_) =>
              EmailVerificationPage(email: result['email'] as String),
        ),
      );
    }
    // If there's an error, auth_provider already sets it in state —
    // the error widget in the form will surface it automatically.
  }

  void _forgotPassword() {
    Navigator.of(
      context,
    ).push(MaterialPageRoute(builder: (_) => const ForgotPasswordPage()));
  }

  void _toggleForm(bool isLogin) {
    if (ref.read(isLoadingProvider)) return;
    setState(() => _isLoginSelected = isLogin);
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppColors.error,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(16),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenH = ScreenSize.height(context);
    final screenW = ScreenSize.width(context);
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    final isLoading = ref.watch(isLoadingProvider);
    ref.watch(authErrorProvider);

    ref.listen<String?>(authErrorProvider, (previous, next) {
      if (next != null) {
        _showError(next);
        Future.delayed(const Duration(milliseconds: 100), () {
          ref.read(authProvider.notifier).clearError();
        });
      }
    });

    final bottomInset = MediaQuery.of(context).viewInsets.bottom;

    // Pause animation when keyboard is open to fix lag
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      if (bottomInset > 0 && _orbController.isAnimating) {
        _orbController.stop();
      } else if (bottomInset == 0 && !_orbController.isAnimating) {
        _orbController.repeat();
      }
    });

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Stack(
        children: [
          // Background gradient
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                color: isDark
                    ? const Color(0xFF2A2A2A)
                    : const Color(0xFFDEE4EA),
              ),
            ),
          ),

          // Floating background shapes
          RepaintBoundary(child: _buildBackgroundOrbs(isDark)),

          // Content
          SafeArea(
            child: SingleChildScrollView(
              padding: EdgeInsets.fromLTRB(
                24,
                16,
                24,
                16 + MediaQuery.of(context).viewInsets.bottom,
              ),
              child: RepaintBoundary(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: screenH * 0.02),

                    // Title
                    AnimatedListItem(
                      index: 0,
                      child: Text(
                        'Nexify',
                        style: theme.textTheme.headlineLarge?.copyWith(
                          fontWeight: FontWeight.w800,
                          letterSpacing: -1,
                        ),
                      ),
                    ),
                    const SizedBox(height: 4),
                    AnimatedListItem(
                      index: 1,
                      child: Text(
                        'Digital Services Management',
                        style: theme.textTheme.bodyLarge?.copyWith(
                          color: theme.colorScheme.onSurface.withValues(
                            alpha: 0.5,
                          ),
                        ),
                      ),
                    ),

                    SizedBox(height: screenH * 0.03),

                    // Form container
                    Center(
                      child: ConstrainedBox(
                        constraints: BoxConstraints(
                          maxWidth: screenW > 700 ? 700 : double.infinity,
                        ),
                        child: Column(
                          children: [
                            const HeroBanner(),
                            const SizedBox(height: 20),

                            // Clay form card
                            ConstrainedBox(
                              constraints: BoxConstraints(
                                maxWidth: screenW > 700 ? 600 : double.infinity,
                              ),
                              child: ClayContainer(
                                color: isDark
                                    ? const Color(0xFF2D2D2D)
                                    : const Color(0xFFDEE4EA),
                                borderRadius: 24,
                                depth: 16,
                                padding: const EdgeInsets.all(24),
                                child: Column(
                                  children: [
                                    SegmentedControl(
                                      isLoginSelected: _isLoginSelected,
                                      onSelectionChanged: _toggleForm,
                                    ),
                                    const SizedBox(height: 24),

                                    AnimatedCrossFade(
                                      duration: const Duration(
                                        milliseconds: 300,
                                      ),
                                      crossFadeState: _isLoginSelected
                                          ? CrossFadeState.showFirst
                                          : CrossFadeState.showSecond,
                                      firstChild: LoginForm(
                                        key: const ValueKey('login_form'),
                                        formKey: _loginKey,
                                        emailController: _loginEmail,
                                        passwordController: _loginPassword,
                                        onSubmit: _signIn,
                                        onSwitchToRegister: () =>
                                            _toggleForm(false),
                                        onGoogleSubmit: _googleSignIn,
                                        onForgotPassword: _forgotPassword,
                                        isLoading: isLoading,
                                      ),
                                      secondChild: RegisterForm(
                                        key: const ValueKey('register_form'),
                                        formKey: _regKey,
                                        nameController: _regName,
                                        emailController: _regEmail,
                                        passwordController: _regPassword,
                                        phoneController: _regPhone,
                                        onSubmit: _register,
                                        onSwitchToLogin: () =>
                                            _toggleForm(true),
                                        isLoading: isLoading,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: screenH * 0.04),
                  ],
                ),
              ),
            ),
          ),

          // Loading overlay
          if (isLoading)
            Container(
              color: Colors.black.withValues(alpha: 0.3),
              child: const Center(
                child: ClayLoadingDots(dotSize: 12, dotCount: 3),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildBackgroundOrbs(bool isDark) {
    return AnimatedBuilder(
      animation: _orbController,
      builder: (context, _) {
        final size = MediaQuery.of(context).size;
        return Stack(
          children: [
            _buildOrb(
              size,
              0.1,
              0.15,
              120,
              (isDark ? Colors.white : Colors.black).withValues(alpha: 0.025),
              0,
            ),
            _buildOrb(
              size,
              0.8,
              0.1,
              80,
              (isDark ? Colors.white : Colors.black).withValues(alpha: 0.018),
              0.3,
            ),
            _buildOrb(
              size,
              0.9,
              0.7,
              100,
              (isDark ? Colors.white : Colors.black).withValues(alpha: 0.02),
              0.6,
            ),
          ],
        );
      },
    );
  }

  Widget _buildOrb(
    Size size,
    double x,
    double y,
    double radius,
    Color color,
    double phase,
  ) {
    final progress = (_orbController.value + phase) % 1.0;
    final xOff = math.sin(progress * 2 * math.pi) * 15;
    final yOff = math.cos(progress * 2 * math.pi) * 10;

    return Positioned(
      left: size.width * x + xOff,
      top: size.height * y + yOff,
      child: Container(
        width: radius,
        height: radius,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: color,
          boxShadow: [
            BoxShadow(
              color: color,
              blurRadius: radius * 0.8,
              spreadRadius: radius * 0.2,
            ),
          ],
        ),
      ),
    );
  }
}
