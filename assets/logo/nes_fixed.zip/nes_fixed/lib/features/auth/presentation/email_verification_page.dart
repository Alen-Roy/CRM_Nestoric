import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nes/app.dart';
import 'package:nes/features/auth/models/user_model.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';

/// Shown immediately after email/password registration.
/// Polls the backend every 4 seconds — when the user clicks the email link,
/// it auto-logs them in and navigates to the dashboard.
class EmailVerificationPage extends ConsumerStatefulWidget {
  final String email;

  const EmailVerificationPage({super.key, required this.email});

  @override
  ConsumerState<EmailVerificationPage> createState() =>
      _EmailVerificationPageState();
}

class _EmailVerificationPageState extends ConsumerState<EmailVerificationPage>
    with SingleTickerProviderStateMixin {
  bool _resending = false;
  bool _resentSuccess = false;
  bool _verified = false;

  late final AnimationController _pulseController;
  late final Animation<double> _pulseAnimation;
  Timer? _pollTimer;

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _pulseAnimation = Tween<double>(begin: 0.92, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    // Poll every 4 seconds
    _pollTimer = Timer.periodic(const Duration(seconds: 4), (_) => _poll());
  }

  @override
  void dispose() {
    _pollTimer?.cancel();
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _poll() async {
    if (_verified) return;
    final repo = ref.read(authRepositoryProvider);
    final result = await repo.checkVerification(widget.email);

    if (!mounted) return;
    if (result['verified'] == true &&
        result['user'] is UserModel &&
        result['token'] is String) {
      _pollTimer?.cancel();
      setState(() => _verified = true);

      // Auto-login: save token and update auth state
      final user = result['user'] as UserModel;
      final token = result['token'] as String;
      await repo.saveToken(token);
      ref.read(authProvider.notifier).setAuthenticatedState(user, token);

      if (!mounted) return;
      // Brief pause so the ✅ animation is visible
      await Future.delayed(const Duration(milliseconds: 800));
      if (!mounted) return;

      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => const AuthWrapper()),
        (route) => false,
      );
    }
  }

  Future<void> _resend() async {
    setState(() {
      _resending = true;
      _resentSuccess = false;
    });
    final repo = ref.read(authRepositoryProvider);
    final result = await repo.resendVerificationEmail(widget.email);
    if (!mounted) return;

    // If the backend says "already verified", force a verification check
    // This handles admin-created workers whose accounts may already be verified
    final errorMsg = (result['error'] ?? '').toString().toLowerCase();
    if (result['success'] != true &&
        (errorMsg.contains('already verified') ||
            errorMsg.contains('already_verified'))) {
      // Force immediate verification check — may auto-login
      await _poll();
      if (!mounted || _verified) return;
      // If still not verified, inform the user
      setState(() => _resending = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Your account may need admin verification. '
            'Please contact your administrator.',
          ),
          backgroundColor: Colors.orange,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    setState(() {
      _resending = false;
      _resentSuccess = result['success'] == true;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          result['success'] == true
              ? 'Verification email sent! Check your inbox.'
              : result['error'] ?? 'Failed to resend email.',
        ),
        backgroundColor: result['success'] == true ? Colors.green : Colors.red,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;

    return Scaffold(
      backgroundColor: cs.surface,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: _verified
              ? _buildVerifiedState(cs)
              : _buildWaitingState(theme, cs),
        ),
      ),
    );
  }

  Widget _buildVerifiedState(ColorScheme cs) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 100,
            height: 100,
            decoration: BoxDecoration(
              color: Colors.green.shade50,
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.check_circle_rounded,
              size: 56,
              color: Colors.green,
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'Email verified! 🎉',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: cs.onSurface,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Taking you to the dashboard…',
            style: TextStyle(color: cs.onSurface.withValues(alpha: 0.55)),
          ),
          const SizedBox(height: 24),
          const CircularProgressIndicator(),
        ],
      ),
    );
  }

  Widget _buildWaitingState(ThemeData theme, ColorScheme cs) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const SizedBox(height: 60),
        ScaleTransition(
          scale: _pulseAnimation,
          child: Container(
            width: 100,
            height: 100,
            decoration: BoxDecoration(
              color: cs.primaryContainer,
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.mark_email_unread_rounded,
              size: 48,
              color: cs.onPrimaryContainer,
            ),
          ),
        ),
        const SizedBox(height: 32),

        Text(
          'Check your inbox',
          style: theme.textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.w800,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 12),

        RichText(
          textAlign: TextAlign.center,
          text: TextSpan(
            style: theme.textTheme.bodyMedium?.copyWith(
              color: cs.onSurface.withValues(alpha: 0.6),
              height: 1.6,
            ),
            children: [
              const TextSpan(text: 'We sent a verification link to\n'),
              TextSpan(
                text: widget.email,
                style: TextStyle(
                  fontWeight: FontWeight.w700,
                  color: cs.primary,
                ),
              ),
              const TextSpan(
                text:
                    '\n\nTap the link — this page will automatically take you to the dashboard.',
              ),
            ],
          ),
        ),

        const SizedBox(height: 40),

        // ── Steps ──
        Container(
          decoration: BoxDecoration(
            color: cs.surfaceContainerHighest.withValues(alpha: 0.5),
            borderRadius: BorderRadius.circular(16),
          ),
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              _Step(number: 1, text: 'Open the email from Nexify'),
              const SizedBox(height: 12),
              _Step(number: 2, text: 'Tap "Verify my email"'),
              const SizedBox(height: 12),
              _Step(number: 3, text: 'This page auto-redirects ✨'),
            ],
          ),
        ),

        const Spacer(),

        // ── Resend ──
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 300),
          child: _resentSuccess
              ? Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.check_circle_outline,
                      color: Colors.green,
                      size: 18,
                    ),
                    const SizedBox(width: 8),
                    const Text(
                      'Email sent!',
                      style: TextStyle(
                        color: Colors.green,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                )
              : TextButton.icon(
                  key: const ValueKey('resend'),
                  onPressed: _resending ? null : _resend,
                  icon: _resending
                      ? SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: cs.primary,
                          ),
                        )
                      : const Icon(Icons.refresh_rounded, size: 18),
                  label: const Text('Resend verification email'),
                ),
        ),
        const SizedBox(height: 8),

        SizedBox(
          width: double.infinity,
          height: 52,
          child: FilledButton(
            onPressed: () =>
                Navigator.of(context).popUntil((route) => route.isFirst),
            child: const Text(
              'Go to sign in',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
            ),
          ),
        ),
        const SizedBox(height: 28),
      ],
    );
  }
}

class _Step extends StatelessWidget {
  final int number;
  final String text;
  const _Step({required this.number, required this.text});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Row(
      children: [
        Container(
          width: 28,
          height: 28,
          decoration: BoxDecoration(color: cs.primary, shape: BoxShape.circle),
          alignment: Alignment.center,
          child: Text(
            '$number',
            style: const TextStyle(
              color: Colors.white,
              fontSize: 12,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Text(
            text,
            style: Theme.of(
              context,
            ).textTheme.bodyMedium?.copyWith(fontWeight: FontWeight.w500),
          ),
        ),
      ],
    );
  }
}
