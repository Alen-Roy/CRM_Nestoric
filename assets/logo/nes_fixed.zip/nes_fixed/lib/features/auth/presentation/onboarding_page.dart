import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:nes/core/theme/app_colors.dart';
import 'package:nes/core/widgets/clay_container.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';

// ── Service card data ───────────────────────────────────────────────────────
class _Service {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  const _Service(this.icon, this.title, this.subtitle, this.color);
}

const _services = [
  _Service(
    Icons.phone_android_rounded,
    'Mobile App Development',
    'iOS & Android native apps',
    Color(0xFF6C63FF),
  ),
  _Service(
    Icons.language_rounded,
    'Web Development',
    'Modern websites & portals',
    Color(0xFF63B3ED),
  ),
  _Service(
    Icons.campaign_rounded,
    'Digital Marketing',
    'SEO, Ads & social growth',
    Color(0xFFF6AD55),
  ),
  _Service(
    Icons.design_services_rounded,
    'UI/UX Design',
    'Beautiful, user-first design',
    Color(0xFFFC8181),
  ),
  _Service(
    Icons.psychology_rounded,
    'AI & Automation',
    'Smart tools & chatbots',
    Color(0xFF68D391),
  ),
  _Service(
    Icons.manage_search_rounded,
    'SEO Optimization',
    'Rank higher, grow faster',
    Color(0xFFB794F4),
  ),
  _Service(
    Icons.cloud_queue_rounded,
    'Cloud Solutions',
    'Scalable cloud infrastructure',
    Color(0xFF4FD1C5),
  ),
  _Service(
    Icons.store_rounded,
    'E-Commerce',
    'Online stores that convert',
    Color(0xFFF687B3),
  ),
];

// ── Onboarding slides ───────────────────────────────────────────────────────
class _Slide {
  final String tag; // small badge text
  final String title;
  final String subtitle;
  const _Slide(this.tag, this.title, this.subtitle);
}

const _slides = [
  _Slide(
    'WELCOME',
    'Your Digital Growth\nPartner',
    'Nexify delivers world-class digital services — from mobile apps to cloud infrastructure — all in one seamless platform.',
  ),
  _Slide(
    'SERVICES',
    'Everything You\nNeed to Scale',
    'Browse 8+ professional services tailored for startups, businesses, and enterprises ready to go digital.',
  ),
  _Slide(
    'HOW IT WORKS',
    'Simple Steps to\nGet Started',
    'Submit a request, choose a plan, and our dedicated team handles the rest — with real-time updates every step of the way.',
  ),
];

// ── Main widget ────────────────────────────────────────────────────────────
class OnboardingPage extends ConsumerStatefulWidget {
  const OnboardingPage({super.key});
  @override
  ConsumerState<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends ConsumerState<OnboardingPage>
    with TickerProviderStateMixin {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  late AnimationController _bgController;
  late AnimationController _slideInController;
  late Animation<double> _slideIn;
  late Animation<double> _fadeIn;

  @override
  void initState() {
    super.initState();
    _bgController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 12),
    )..repeat();

    _slideInController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );
    _slideIn = Tween<double>(begin: 40, end: 0).animate(
      CurvedAnimation(parent: _slideInController, curve: Curves.easeOutCubic),
    );
    _fadeIn = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _slideInController, curve: Curves.easeOut),
    );
    _slideInController.forward();
  }

  @override
  void dispose() {
    _pageController.dispose();
    _bgController.dispose();
    _slideInController.dispose();
    super.dispose();
  }

  void _onPageChanged(int index) {
    setState(() => _currentPage = index);
    _slideInController.forward(from: 0);
  }

  void _onNext() {
    if (_currentPage < _slides.length - 1) {
      _pageController.nextPage(
        duration: const Duration(milliseconds: 500),
        curve: Curves.easeInOutCubic,
      );
    } else {
      _completeOnboarding();
    }
  }

  Future<void> _completeOnboarding() async {
    HapticFeedback.lightImpact();
    await ref.read(authProvider.notifier).completeOnboarding();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;
    final size = MediaQuery.of(context).size;

    // gradient palette per page
    final gradients = [
      isDark
          ? [const Color(0xFF1A1035), const Color(0xFF0D0B1F)]
          : [const Color(0xFFF5F3FF), const Color(0xFFEDE9FF)],
      isDark
          ? [const Color(0xFF0A1F2E), const Color(0xFF0B1622)]
          : [const Color(0xFFEFF8FF), const Color(0xFFDCEFFE)],
      isDark
          ? [const Color(0xFF0E1F1A), const Color(0xFF0A1612)]
          : [const Color(0xFFF0FFF4), const Color(0xFFDCFCE7)],
    ];

    final accentColors = [
      const Color(0xFF6C63FF),
      const Color(0xFF63B3ED),
      const Color(0xFF68D391),
    ];

    final currentAccent = accentColors[_currentPage];

    return Scaffold(
      body: Stack(
        children: [
          // ── Animated background
          AnimatedContainer(
            duration: const Duration(milliseconds: 600),
            curve: Curves.easeInOut,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: gradients[_currentPage],
              ),
            ),
          ),

          // ── Floating orbs
          RepaintBoundary(
            child: AnimatedBuilder(
              animation: _bgController,
              builder: (_, __) => Stack(
                children: [
                  _orb(
                    size,
                    0.1,
                    0.12,
                    180,
                    currentAccent.withValues(alpha: 0.06),
                  ),
                  _orb(
                    size,
                    0.78,
                    0.08,
                    120,
                    currentAccent.withValues(alpha: 0.05),
                  ),
                  _orb(
                    size,
                    0.45,
                    0.82,
                    220,
                    currentAccent.withValues(alpha: 0.04),
                  ),
                  _orb(
                    size,
                    0.9,
                    0.55,
                    80,
                    currentAccent.withValues(alpha: 0.07),
                  ),
                ],
              ),
            ),
          ),

          // ── Pages
          SafeArea(
            child: Column(
              children: [
                // Top bar: logo + skip
                Padding(
                  padding: const EdgeInsets.fromLTRB(24, 12, 16, 0),
                  child: Row(
                    children: [
                      Image.asset(
                        'assets/icon/Logo.png',
                        height: 36,
                        errorBuilder: (_, __, ___) => const SizedBox(width: 36),
                      ),
                      const Spacer(),
                      if (_currentPage < _slides.length - 1)
                        TextButton(
                          onPressed: _completeOnboarding,
                          style: TextButton.styleFrom(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: 8,
                            ),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            backgroundColor: currentAccent.withValues(
                              alpha: 0.1,
                            ),
                          ),
                          child: Text(
                            'Skip',
                            style: GoogleFonts.plusJakartaSans(
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                              color: currentAccent,
                            ),
                          ),
                        ),
                    ],
                  ),
                ),

                // Page content
                Expanded(
                  child: PageView.builder(
                    controller: _pageController,
                    onPageChanged: _onPageChanged,
                    itemCount: _slides.length,
                    itemBuilder: (_, i) {
                      if (i == 1)
                        return _buildServicesPage(currentAccent, isDark);
                      if (i == 2)
                        return _buildHowItWorksPage(currentAccent, isDark);
                      return _buildWelcomePage(currentAccent, isDark, size);
                    },
                  ),
                ),

                // Bottom controls
                _buildBottomBar(currentAccent, isDark),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── PAGE 1: Welcome ───────────────────────────────────────────────────────
  Widget _buildWelcomePage(Color accent, bool isDark, Size size) {
    final slide = _slides[0];
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28),
      child: Column(
        children: [
          const SizedBox(height: 24),

          // Hero logo / illustration
          AnimatedBuilder(
            animation: _bgController,
            builder: (_, __) {
              final pulse = math.sin(_bgController.value * 2 * math.pi) * 8;
              return ClayContainer(
                height: 230,
                width: 230,
                borderRadius: 115,
                depth: 24,
                spread: 2,
                color: isDark
                    ? const Color(0xFF1A1035)
                    : const Color(0xFFF5F3FF),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    // Glow ring
                    Container(
                      width: 160 + pulse,
                      height: 160 + pulse,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: accent.withValues(alpha: 0.08),
                      ),
                    ),
                    // Logo image
                    Image.asset(
                      'assets/icon/Logo.png',
                      width: 110,
                      height: 110,
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) =>
                          Icon(Icons.diamond_outlined, size: 80, color: accent),
                    ),
                  ],
                ),
              );
            },
          ),

          const SizedBox(height: 36),

          // Tag chip
          _tagChip(slide.tag, accent),
          const SizedBox(height: 16),

          // Title
          AnimatedBuilder(
            animation: _slideInController,
            builder: (_, child) => Transform.translate(
              offset: Offset(0, _slideIn.value),
              child: Opacity(opacity: _fadeIn.value, child: child),
            ),
            child: Text(
              slide.title,
              textAlign: TextAlign.center,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 32,
                fontWeight: FontWeight.w900,
                height: 1.15,
                letterSpacing: -0.5,
                color: isDark ? Colors.white : const Color(0xFF1A1035),
              ),
            ),
          ),

          const SizedBox(height: 16),

          // Subtitle
          AnimatedBuilder(
            animation: _slideInController,
            builder: (_, child) => Transform.translate(
              offset: Offset(0, _slideIn.value * 1.5),
              child: Opacity(opacity: _fadeIn.value, child: child),
            ),
            child: Text(
              slide.subtitle,
              textAlign: TextAlign.center,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 15,
                fontWeight: FontWeight.w400,
                height: 1.7,
                color: isDark
                    ? Colors.white.withValues(alpha: 0.55)
                    : const Color(0xFF1A1035).withValues(alpha: 0.55),
              ),
            ),
          ),

          const SizedBox(height: 28),

          // Mini stat row
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _stat('8+', 'Services', accent),
              _vDivider(),
              _stat('100%', 'Digital', accent),
              _vDivider(),
              _stat('24/7', 'Support', accent),
            ],
          ),
        ],
      ),
    );
  }

  // ── PAGE 2: Services ──────────────────────────────────────────────────────
  Widget _buildServicesPage(Color accent, bool isDark) {
    final slide = _slides[1];
    final bg = isDark ? const Color(0xFF0A1F2E) : const Color(0xFFEFF8FF);
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(28, 20, 28, 0),
          child: Column(
            children: [
              _tagChip(slide.tag, accent),
              const SizedBox(height: 14),
              AnimatedBuilder(
                animation: _slideInController,
                builder: (_, child) => Transform.translate(
                  offset: Offset(0, _slideIn.value),
                  child: Opacity(opacity: _fadeIn.value, child: child),
                ),
                child: Text(
                  slide.title,
                  textAlign: TextAlign.center,
                  style: GoogleFonts.plusJakartaSans(
                    fontSize: 28,
                    fontWeight: FontWeight.w900,
                    height: 1.2,
                    letterSpacing: -0.3,
                    color: isDark ? Colors.white : const Color(0xFF0A1F2E),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                slide.subtitle,
                textAlign: TextAlign.center,
                style: GoogleFonts.plusJakartaSans(
                  fontSize: 13,
                  color: (isDark ? Colors.white : const Color(0xFF0A1F2E))
                      .withValues(alpha: 0.5),
                ),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),

        // Services grid
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: GridView.builder(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.only(bottom: 8),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.55,
              ),
              itemCount: _services.length,
              itemBuilder: (_, i) {
                final s = _services[i];
                return ClayContainer(
                  color: bg,
                  borderRadius: 18,
                  depth: 14,
                  spread: 1,
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(18),
                      border: Border.all(
                        color: s.color.withValues(alpha: 0.18),
                        width: 1,
                      ),
                    ),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 14,
                      vertical: 12,
                    ),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: 34,
                          height: 34,
                          decoration: BoxDecoration(
                            color: s.color.withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Icon(s.icon, color: s.color, size: 18),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                s.title,
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 11.5,
                                  fontWeight: FontWeight.w700,
                                  color: isDark
                                      ? Colors.white
                                      : const Color(0xFF0A1F2E),
                                ),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              const SizedBox(height: 3),
                              Text(
                                s.subtitle,
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 9.5,
                                  color:
                                      (isDark
                                              ? Colors.white
                                              : const Color(0xFF0A1F2E))
                                          .withValues(alpha: 0.45),
                                ),
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ],
    );
  }

  // ── PAGE 3: How It Works ──────────────────────────────────────────────────
  Widget _buildHowItWorksPage(Color accent, bool isDark) {
    final slide = _slides[2];
    final steps = [
      (
        Icons.edit_note_rounded,
        'Submit a Request',
        'Tell us what you need — services, details, and timeline.',
        const Color(0xFF6C63FF),
      ),
      (
        Icons.payments_rounded,
        'Choose Your Plan',
        'Pick Basic, Standard, or Premium and pay securely.',
        const Color(0xFF63B3ED),
      ),
      (
        Icons.people_alt_rounded,
        'We Get to Work',
        'A dedicated expert is assigned and updates you in real time.',
        const Color(0xFF68D391),
      ),
      (
        Icons.verified_rounded,
        'Delivered & Done',
        'Review, approve, and go live with confidence.',
        const Color(0xFFF6AD55),
      ),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 28),
      child: Column(
        children: [
          const SizedBox(height: 20),
          _tagChip(slide.tag, accent),
          const SizedBox(height: 14),
          AnimatedBuilder(
            animation: _slideInController,
            builder: (_, child) => Transform.translate(
              offset: Offset(0, _slideIn.value),
              child: Opacity(opacity: _fadeIn.value, child: child),
            ),
            child: Text(
              slide.title,
              textAlign: TextAlign.center,
              style: GoogleFonts.plusJakartaSans(
                fontSize: 28,
                fontWeight: FontWeight.w900,
                height: 1.2,
                letterSpacing: -0.3,
                color: isDark ? Colors.white : const Color(0xFF0E1F1A),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            slide.subtitle,
            textAlign: TextAlign.center,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 13,
              height: 1.6,
              color: (isDark ? Colors.white : const Color(0xFF0E1F1A))
                  .withValues(alpha: 0.5),
            ),
          ),
          const SizedBox(height: 24),

          // Steps
          Expanded(
            child: Column(
              children: steps.asMap().entries.map((entry) {
                final i = entry.key;
                final step = entry.value;
                return Expanded(
                  child: Row(
                    children: [
                      Column(
                        children: [
                          Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: step.$4.withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(
                                color: step.$4.withValues(alpha: 0.25),
                              ),
                            ),
                            child: Icon(step.$1, color: step.$4, size: 22),
                          ),
                          if (i < steps.length - 1)
                            Expanded(
                              child: Container(
                                width: 2,
                                margin: const EdgeInsets.symmetric(vertical: 4),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    begin: Alignment.topCenter,
                                    end: Alignment.bottomCenter,
                                    colors: [
                                      step.$4.withValues(alpha: 0.3),
                                      steps[i + 1].$4.withValues(alpha: 0.15),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                step.$2,
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w800,
                                  color: isDark
                                      ? Colors.white
                                      : const Color(0xFF0E1F1A),
                                ),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                step.$3,
                                style: GoogleFonts.plusJakartaSans(
                                  fontSize: 12,
                                  height: 1.5,
                                  color:
                                      (isDark
                                              ? Colors.white
                                              : const Color(0xFF0E1F1A))
                                          .withValues(alpha: 0.5),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  // ── Bottom navigation bar ─────────────────────────────────────────────────
  Widget _buildBottomBar(Color accent, bool isDark) {
    final bg = isDark
        ? const Color(0xFF111111).withValues(alpha: 0.6)
        : Colors.white.withValues(alpha: 0.6);

    return Container(
      margin: const EdgeInsets.fromLTRB(24, 0, 24, 32),
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: accent.withValues(alpha: 0.15)),
        boxShadow: [
          BoxShadow(
            color: accent.withValues(alpha: 0.08),
            blurRadius: 20,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          // Progress dots
          Row(
            children: List.generate(
              _slides.length,
              (i) => AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                margin: const EdgeInsets.only(right: 7),
                height: 8,
                width: _currentPage == i ? 28 : 8,
                decoration: BoxDecoration(
                  color: _currentPage == i
                      ? accent
                      : (isDark ? Colors.white : Colors.black).withValues(
                          alpha: 0.15,
                        ),
                  borderRadius: BorderRadius.circular(4),
                ),
              ),
            ),
          ),

          const Spacer(),

          // CTA button
          GestureDetector(
            onTap: _onNext,
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              padding: EdgeInsets.symmetric(
                horizontal: _currentPage == _slides.length - 1 ? 22 : 18,
                vertical: 12,
              ),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [accent, accent.withValues(alpha: 0.75)],
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: accent.withValues(alpha: 0.4),
                    blurRadius: 16,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    _currentPage == _slides.length - 1 ? 'Get Started' : 'Next',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Icon(
                    _currentPage == _slides.length - 1
                        ? Icons.rocket_launch_rounded
                        : Icons.arrow_forward_rounded,
                    color: Colors.white,
                    size: 16,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Shared helpers ────────────────────────────────────────────────────────
  Widget _tagChip(String text, Color accent) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
      decoration: BoxDecoration(
        color: accent.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: accent.withValues(alpha: 0.3)),
      ),
      child: Text(
        text,
        style: GoogleFonts.plusJakartaSans(
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: accent,
          letterSpacing: 1.2,
        ),
      ),
    );
  }

  Widget _stat(String value, String label, Color accent) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          Text(
            value,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 22,
              fontWeight: FontWeight.w900,
              color: accent,
            ),
          ),
          Text(
            label,
            style: GoogleFonts.plusJakartaSans(
              fontSize: 11,
              color: accent.withValues(alpha: 0.6),
            ),
          ),
        ],
      ),
    );
  }

  Widget _vDivider() => Container(
    height: 32,
    width: 1,
    color: Colors.grey.withValues(alpha: 0.2),
  );

  Widget _orb(Size size, double x, double y, double radius, Color color) {
    return AnimatedBuilder(
      animation: _bgController,
      builder: (_, __) {
        final dx = math.sin(_bgController.value * 2 * math.pi + x * 10) * 18;
        final dy = math.cos(_bgController.value * 2 * math.pi + y * 8) * 14;
        return Positioned(
          left: size.width * x + dx,
          top: size.height * y + dy,
          child: Container(
            width: radius,
            height: radius,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color,
              boxShadow: [
                BoxShadow(
                  color: color,
                  blurRadius: radius * 0.9,
                  spreadRadius: radius * 0.1,
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
