import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phosphor_flutter/phosphor_flutter.dart';
import 'package:nes/core/widgets/clay_container.dart';
import 'package:nes/features/auth/providers/auth_provider.dart';

class ForgotPasswordPage extends ConsumerStatefulWidget {
  const ForgotPasswordPage({super.key});

  @override
  ConsumerState<ForgotPasswordPage> createState() => _ForgotPasswordPageState();
}

class _ForgotPasswordPageState extends ConsumerState<ForgotPasswordPage> {
  final _emailController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }

  void _submit() async {
    if (_formKey.currentState!.validate()) {
      final success = await ref
          .read(authProvider.notifier)
          .forgotPassword(_emailController.text.trim());

      if (mounted) {
        if (success) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text(
                'If that email is registered, a reset link was sent.',
              ),
              backgroundColor: Colors.green,
            ),
          );
          Navigator.pop(context); // Go back to login
        } else {
          final error = ref.read(authErrorProvider);
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(error ?? 'Failed to send reset email'),
              backgroundColor: Colors.red,
            ),
          );
          ref.read(authProvider.notifier).clearError();
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLoading = ref.watch(isLoadingProvider);
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    final baseColor = isDark
        ? const Color(0xFF2D2D2D)
        : const Color(0xFFDEE4EA);
    final textColor = isDark ? Colors.white : const Color(0xFF485057);
    final shadowColor1 = isDark
        ? Colors.black.withValues(alpha: 0.4)
        : Colors.black.withValues(alpha: 0.15);
    final shadowColor2 = isDark
        ? Colors.white.withValues(alpha: 0.04)
        : Colors.white.withValues(alpha: 0.7);

    return Scaffold(
      backgroundColor: baseColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: Padding(
          padding: const EdgeInsets.only(left: 16),
          child: Center(
            child: ClayContainer(
              height: 44,
              width: 44,
              borderRadius: 22,
              depth: 20,
              spread: 1,
              color: baseColor,
              shadowColor1: shadowColor1,
              shadowColor2: shadowColor2,
              child: IconButton(
                icon: Icon(
                  PhosphorIconsRegular.caretLeft,
                  size: 22,
                  color: textColor,
                ),
                onPressed: () => Navigator.pop(context),
              ),
            ),
          ),
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: DefaultTextStyle(
            style: TextStyle(color: textColor),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 20),
                  Text(
                    'Reset\nPassword',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 40,
                      fontWeight: FontWeight.w800,
                      height: 1.1,
                      letterSpacing: -1,
                      color: textColor,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    'Enter your email address and we\'ll send you instructions to reset your password.',
                    style: GoogleFonts.plusJakartaSans(
                      fontSize: 16,
                      color: textColor.withValues(alpha: 0.7),
                      height: 1.5,
                    ),
                  ),
                  const SizedBox(height: 48),

                  // Email Field
                  ClayContainer(
                    color: baseColor,
                    borderRadius: 16,
                    depth: -20, // Embossed
                    spread: 1,
                    shadowColor1: shadowColor1,
                    shadowColor2: shadowColor2,
                    emboss: true,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: TextFormField(
                        controller: _emailController,
                        keyboardType: TextInputType.emailAddress,
                        textInputAction: TextInputAction.done,
                        onFieldSubmitted: (_) => _submit(),
                        decoration: InputDecoration(
                          icon: Icon(
                            PhosphorIconsRegular.envelopeSimple,
                            color: textColor.withValues(alpha: 0.5),
                            size: 22,
                          ),
                          border: InputBorder.none,
                          hintText: 'Email address',
                          hintStyle: GoogleFonts.plusJakartaSans(
                            color: textColor.withValues(alpha: 0.4),
                          ),
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter your email';
                          }
                          if (!value.contains('@') || !value.contains('.')) {
                            return 'Please enter a valid email';
                          }
                          return null;
                        },
                      ),
                    ),
                  ),

                  const SizedBox(height: 48),

                  // Submit Button
                  GestureDetector(
                    onTap: isLoading ? null : _submit,
                    child: ClayContainer(
                      color: theme.colorScheme.primary,
                      borderRadius: 16,
                      depth: 25,
                      spread: 2,
                      width: double.infinity,
                      height: 60,
                      child: Center(
                        child: isLoading
                            ? const SizedBox(
                                height: 24,
                                width: 24,
                                child: CircularProgressIndicator(
                                  color: Colors.white,
                                  strokeWidth: 2.5,
                                ),
                              )
                            : Text(
                                'Send Reset Link',
                                style: GoogleFonts.plusJakartaSans(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
