import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nes/features/auth/presentation/onboarding_page.dart';
import 'core/theme/dark_theme.dart';
import 'core/theme/light_theme.dart';
import 'core/providers/theme_provider.dart';
import 'core/widgets/splash_screen.dart';
import 'features/admin/pages/admin_dashboard.dart';

import 'features/auth/providers/auth_provider.dart';
import 'features/auth/presentation/login_signup.dart';
import 'features/client/widgets/client_main_layout.dart';
import 'features/worker/widgets/worker_main_layout.dart';

class NexifyApp extends ConsumerWidget {
  const NexifyApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final themeMode = ref.watch(themeModeProvider);

    return MaterialApp(
      title: 'Nexify',
      theme: LightTheme.theme,
      darkTheme: DarkTheme.theme,
      themeMode: themeMode,
      debugShowCheckedModeBanner: false,
      home: const AuthWrapper(),
    );
  }
}

class AuthWrapper extends ConsumerStatefulWidget {
  const AuthWrapper({super.key});

  @override
  ConsumerState<AuthWrapper> createState() => _AuthWrapperState();
}

class _AuthWrapperState extends ConsumerState<AuthWrapper> {
  static const Duration _minimumSplashDuration = Duration(seconds: 2);
  bool _isSplashMinimumElapsed = false;

  @override
  void initState() {
    super.initState();
    _initSplash();
  }

  Future<void> _initSplash() async {
    await Future.delayed(_minimumSplashDuration);
    if (mounted) {
      setState(() {
        _isSplashMinimumElapsed = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authProvider);
    final hasCheckedAuth = ref.watch(hasCheckedAuthProvider);

    // Keep splash visible until auth is checked and minimum duration completes.
    if (!_isSplashMinimumElapsed || !hasCheckedAuth) {
      return const SplashScreen();
    }

    // Onboarding check
    if (!authState.hasSeenOnboarding) {
      return const OnboardingPage();
    }

    // Not authenticated - show login
    if (!authState.isAuthenticated) {
      return const LoginSignup();
    }

    // Authenticated - route based on role
    final user = authState.user;
    if (user == null) return const LoginSignup();

    if (user.isAdmin) {
      return const AdminDashboard();
    } else if (user.isWorker) {
      return const WorkerMainLayout();
    } else {
      return ClientMainLayout(key: clientNavKey);
    }
  }
}
