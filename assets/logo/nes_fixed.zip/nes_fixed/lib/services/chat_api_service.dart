import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:http_parser/http_parser.dart';
import 'package:mime/mime.dart';
import 'package:flutter/foundation.dart';

/// Enhanced Chat API Service with file upload support
class ChatApiService {
  static const String baseUrl = 'https://nestoric-backend.onrender.com/api';

  /// Get messages for a request
  static Future<Map<String, dynamic>> getMessages({
    required String token,
    required String requestId,
  }) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/requests/$requestId/messages'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return {'success': true, 'messages': data['messages'] ?? []};
      } else {
        return {
          'success': false,
          'error': data['error'] ?? 'Failed to get messages',
        };
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: ${e.toString()}'};
    }
  }

  /// Upload a file (image or document)
  static Future<Map<String, dynamic>> uploadFile({
    required String token,
    required File file,
    required String type, // 'image' or 'document'
  }) async {
    try {
      final endpoint = type == 'image' ? 'image' : 'document';
      var request = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl/upload/$endpoint'),
      );

      request.headers['Authorization'] = 'Bearer $token';

      final mimeType = lookupMimeType(file.path);
      if (kDebugMode)
        debugPrint('Uploading file: ${file.path}, Detected MIME: $mimeType');

      MediaType? contentType;
      if (mimeType != null) {
        final split = mimeType.split('/');
        contentType = MediaType(split[0], split[1]);
      }

      var multipartFile = await http.MultipartFile.fromPath(
        'file',
        file.path,
        contentType: contentType,
      );

      request.files.add(multipartFile);

      var streamedResponse = await request.send();
      var response = await http.Response.fromStream(streamedResponse);
      var data = jsonDecode(response.body);

      if (response.statusCode == 200 || response.statusCode == 201) {
        // Backend may return URL under different keys depending on resource type
        final uploadedUrl =
            data['url'] ??
            data['secure_url'] ??
            data['fileUrl'] ??
            data['file']?['url'] ??
            data['file']?['secure_url'];
        if (kDebugMode) debugPrint('Upload response data: $data');
        if (kDebugMode) debugPrint('Extracted URL: $uploadedUrl');
        return {
          'success': true,
          'url': uploadedUrl,
          'publicId': data['publicId'] ?? data['public_id'],
          'fileName':
              data['filename'] ?? data['fileName'] ?? data['original_filename'],
        };
      } else {
        return {
          'success': false,
          'error': data['error'] ?? 'Failed to upload file',
        };
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: ${e.toString()}'};
    }
  }

  /// Send a message (text + optional file)
  static Future<Map<String, dynamic>> sendMessage({
    required String token,
    required String requestId,
    required String message,
    String? fileUrl,
    String? fileName,
    String? fileType,
  }) async {
    try {
      final body = <String, dynamic>{'message': message};

      if (fileUrl != null) {
        body['fileUrl'] = fileUrl;
        body['fileName'] = fileName ?? 'File';
        body['fileType'] = fileType ?? 'file';
        // Also send as nested 'file' object for backend compatibility
        body['file'] = {
          'url': fileUrl,
          'name': fileName ?? 'File',
          'type': fileType ?? 'file',
        };
      }

      final url = Uri.parse('$baseUrl/requests/$requestId/messages');
      if (kDebugMode) debugPrint('Sending message to: $url');
      if (kDebugMode) debugPrint('Body: $body');

      final response = await http.post(
        url,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        body: jsonEncode(body),
      );

      if (kDebugMode) debugPrint('Response Status: ${response.statusCode}');
      if (kDebugMode) debugPrint('Response Body: ${response.body}');

      final data = jsonDecode(response.body);

      if (response.statusCode == 201 || response.statusCode == 200) {
        return {'success': true, 'message': data['data'] ?? data['message']};
      } else {
        return {
          'success': false,
          'error': data['error'] ?? 'Failed to send message',
        };
      }
    } catch (e) {
      if (kDebugMode) debugPrint('Error sending message: $e');
      return {'success': false, 'error': 'Network error: ${e.toString()}'};
    }
  }

  /// Mark messages as read
  static Future<Map<String, dynamic>> markAsRead({
    required String token,
    required String requestId,
  }) async {
    try {
      final response = await http.patch(
        Uri.parse('$baseUrl/requests/$requestId/messages/read'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      if (response.statusCode == 200) {
        return {'success': true};
      } else {
        final data = jsonDecode(response.body);
        return {
          'success': false,
          'error': data['error'] ?? 'Failed to mark as read',
        };
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: ${e.toString()}'};
    }
  }

  /// Get unread message count
  static Future<Map<String, dynamic>> getUnreadCount({
    required String token,
  }) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/messages/unread'),
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
      );

      final data = jsonDecode(response.body);

      if (response.statusCode == 200) {
        return {'success': true, 'unreadCount': data['unreadCount'] ?? 0};
      } else {
        return {
          'success': false,
          'error': data['error'] ?? 'Failed to get unread count',
        };
      }
    } catch (e) {
      return {'success': false, 'error': 'Network error: ${e.toString()}'};
    }
  }
}

/// Chat message model
class ChatMessage {
  final String id;
  final String message;
  final String senderId;
  final String senderName;
  final String senderRole;
  final DateTime timestamp;
  final bool isRead;
  final String? fileUrl;
  final String? fileName;
  final String? fileType;

  ChatMessage({
    required this.id,
    required this.message,
    required this.senderId,
    required this.senderName,
    required this.senderRole,
    required this.timestamp,
    required this.isRead,
    this.fileUrl,
    this.fileName,
    this.fileType,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> json) {
    // Parse file data from multiple possible response formats
    final fileObj = json['file'];
    final isFileMap = fileObj is Map<String, dynamic>;

    final parsedFileUrl =
        json['fileUrl'] ??
        json['file_url'] ??
        (isFileMap ? fileObj['url'] ?? fileObj['secure_url'] : null) ??
        (fileObj is String ? fileObj : null);

    final parsedFileName =
        json['fileName'] ??
        json['file_name'] ??
        json['filename'] ??
        (isFileMap ? fileObj['name'] ?? fileObj['filename'] : null);

    final parsedFileType =
        json['fileType'] ??
        json['file_type'] ??
        (isFileMap ? fileObj['type'] ?? fileObj['mimeType'] : null);

    return ChatMessage(
      id: json['_id'] ?? json['id'] ?? '',
      message: json['message'] ?? json['text'] ?? '',
      senderId: json['senderId'] ?? json['sender'] ?? '',
      senderName: json['senderName'] ?? json['name'] ?? 'User',
      senderRole: json['senderRole'] ?? json['role'] ?? 'client',
      timestamp: json['timestamp'] != null
          ? (DateTime.tryParse(json['timestamp'].toString()) ?? DateTime.now())
          : json['createdAt'] != null
          ? (DateTime.tryParse(json['createdAt'].toString()) ?? DateTime.now())
          : DateTime.now(),
      isRead: json['isRead'] ?? json['read'] ?? false,
      fileUrl: parsedFileUrl,
      fileName: parsedFileName,
      fileType: parsedFileType,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'message': message,
      'senderId': senderId,
      'senderName': senderName,
      'senderRole': senderRole,
      'timestamp': timestamp.toIso8601String(),
      'isRead': isRead,
      if (fileUrl != null) 'fileUrl': fileUrl,
      if (fileName != null) 'fileName': fileName,
      if (fileType != null) 'fileType': fileType,
    };
  }

  bool get hasFile => fileUrl != null && fileUrl!.isNotEmpty;

  bool get isImage {
    // Check by MIME type first
    if (fileType != null && fileType!.startsWith('image/')) return true;
    // Fallback: check URL or fileName for image extensions
    final name = (fileName ?? fileUrl ?? '').toLowerCase();
    return name.endsWith('.jpg') ||
        name.endsWith('.jpeg') ||
        name.endsWith('.png') ||
        name.endsWith('.gif') ||
        name.endsWith('.webp') ||
        name.endsWith('.bmp');
  }

  bool get isDocument {
    // Check by MIME type
    if (fileType != null) {
      return fileType!.contains('pdf') ||
          fileType!.contains('msword') ||
          fileType!.contains('wordprocessing') ||
          fileType!.contains('spreadsheet') ||
          fileType!.contains('excel') ||
          fileType!.contains('text/plain') ||
          fileType!.contains('presentation') ||
          fileType!.contains('powerpoint');
    }
    // Fallback: check file name or URL for document extensions
    final name = (fileName ?? fileUrl ?? '').toLowerCase();
    return name.endsWith('.pdf') ||
        name.endsWith('.doc') ||
        name.endsWith('.docx') ||
        name.endsWith('.xls') ||
        name.endsWith('.xlsx') ||
        name.endsWith('.txt') ||
        name.endsWith('.ppt') ||
        name.endsWith('.pptx');
  }
}
