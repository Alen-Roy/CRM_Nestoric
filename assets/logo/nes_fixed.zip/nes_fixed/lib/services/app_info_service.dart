/// Centralized app information service
/// This ensures version info is consistent across the app
class AppInfoService {
  AppInfoService._();

  /// App name
  static const String appName = 'Nexify';

  /// Current app version - sync with pubspec.yaml
  static const String version = '2.0.0';

  /// Build number
  static const String buildNumber = '1';

  /// Full version string
  static String get fullVersion => '$version+$buildNumber';
}
