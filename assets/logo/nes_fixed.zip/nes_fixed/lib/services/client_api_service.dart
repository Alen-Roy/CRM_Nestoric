// lib/services/client_api_service.dart
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class ClientApiService {
  // Base URL configuration
  static String get baseUrl {
    return 'https://nestoric-backend.onrender.com/api';

    // For production, use:
    // return 'https://your-production-domain.com/api';
  }

  static Map<String, String> _getHeaders(String? token) {
    return {
      'Content-Type': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  static Future<Map<String, dynamic>> _handleResponse(
    http.Response response,
    String operation,
  ) async {
    try {
      final data = jsonDecode(response.body) as Map<String, dynamic>;

      if (response.statusCode >= 200 && response.statusCode < 300) {
        return {'success': true, ...data};
      } else {
        return {
          'success': false,
          'error': data['error'] ?? data['message'] ?? 'Failed to $operation',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'error': 'Invalid response format: ${e.toString()}',
      };
    }
  }

  static Future<Map<String, dynamic>> _handleError(
    dynamic error,
    String operation,
  ) async {
    if (error is SocketException) {
      return {
        'success': false,
        'error': 'No internet connection. Please check your network.',
      };
    } else if (error is HttpException) {
      return {
        'success': false,
        'error': 'Could not connect to server. Please try again.',
      };
    } else if (error is FormatException) {
      return {
        'success': false,
        'error': 'Invalid data format received from server.',
      };
    } else {
      return {'success': false, 'error': 'Network error: ${error.toString()}'};
    }
  }

  // ==========================================
  // GET CLIENT STATS
  // Endpoint: GET /api/users/client-stats
  // ==========================================
  static Future<Map<String, dynamic>> getClientStats(String token) async {
    try {
      final response = await http
          .get(
            Uri.parse('$baseUrl/users/client-stats'),
            headers: _getHeaders(token),
          )
          .timeout(const Duration(seconds: 30));

      return await _handleResponse(response, 'get client stats');
    } catch (e) {
      return await _handleError(e, 'get client stats');
    }
  }

  // ==========================================
  // GET MY REQUESTS
  // Endpoint: GET /api/requests/my-requests
  // ==========================================
  static Future<Map<String, dynamic>> getMyRequests(String token) async {
    try {
      final response = await http
          .get(
            Uri.parse('$baseUrl/requests/my-requests'),
            headers: _getHeaders(token),
          )
          .timeout(const Duration(seconds: 30));

      return await _handleResponse(response, 'get requests');
    } catch (e) {
      return await _handleError(e, 'get requests');
    }
  }

  // ==========================================
  // GET REQUEST DETAILS
  // Endpoint: GET /api/requests/:id
  // ==========================================
  static Future<Map<String, dynamic>> getRequestDetails({
    required String token,
    required String requestId,
  }) async {
    try {
      final response = await http
          .get(
            Uri.parse('$baseUrl/requests/$requestId'),
            headers: _getHeaders(token),
          )
          .timeout(const Duration(seconds: 30));

      return await _handleResponse(response, 'get request details');
    } catch (e) {
      return await _handleError(e, 'get request details');
    }
  }

  // ==========================================
  // CREATE REQUEST
  // Endpoint: POST /api/requests
  // ==========================================
  static Future<Map<String, dynamic>> createRequest({
    required String token,
    required List<String> services,
    required String description,
    DateTime? deadline,
    List<String>? uploadedFiles,
    String? paymentId,
    String? razorpayOrderId,
    String? razorpaySignature,
    double? amountPaid,
    String? plan,
  }) async {
    try {
      final body = {
        'services': services,
        'description': description,
        if (deadline != null) 'deadline': deadline.toIso8601String(),
        if (uploadedFiles != null) 'uploadedFiles': uploadedFiles,
        if (paymentId != null) 'paymentId': paymentId,
        if (razorpayOrderId != null) 'razorpayOrderId': razorpayOrderId,
        if (razorpaySignature != null) 'razorpaySignature': razorpaySignature,
        if (amountPaid != null) 'amountPaid': amountPaid,
        if (plan != null) 'plan': plan,
      };

      final response = await http
          .post(
            Uri.parse('$baseUrl/requests'),
            headers: _getHeaders(token),
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 30));

      return await _handleResponse(response, 'create request');
    } catch (e) {
      return await _handleError(e, 'create request');
    }
  }

  // ==========================================
  // DELETE REQUEST
  // Endpoint: DELETE /api/requests/:id
  // ==========================================
  static Future<Map<String, dynamic>> deleteRequest({
    required String token,
    required String requestId,
  }) async {
    try {
      final response = await http
          .delete(
            Uri.parse('$baseUrl/requests/$requestId'),
            headers: _getHeaders(token),
          )
          .timeout(const Duration(seconds: 30));

      return await _handleResponse(response, 'delete request');
    } catch (e) {
      return await _handleError(e, 'delete request');
    }
  }

  // ==========================================
  // UPDATE REQUEST
  // Endpoint: PUT /api/requests/:id
  // ==========================================
  static Future<Map<String, dynamic>> updateRequest({
    required String token,
    required String requestId,
    String? status,
    String? note,
    List<String>? uploadedFiles,
  }) async {
    try {
      final body = <String, dynamic>{};
      if (status != null) body['status'] = status;
      if (note != null) body['note'] = note;
      if (uploadedFiles != null) body['uploadedFiles'] = uploadedFiles;

      final response = await http
          .put(
            Uri.parse('$baseUrl/requests/$requestId'),
            headers: _getHeaders(token),
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 30));

      return await _handleResponse(response, 'update request');
    } catch (e) {
      return await _handleError(e, 'update request');
    }
  }

  // ==========================================
  // UPLOAD IMAGE
  // Endpoint: POST /api/upload/image
  // ==========================================
  static Future<Map<String, dynamic>> uploadImage(
    String token,
    File file,
  ) async {
    try {
      var request = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl/upload/image'),
      );

      // Only add Authorization, let MultipartRequest handle Content-Type
      request.headers['Authorization'] = 'Bearer $token';
      request.files.add(await http.MultipartFile.fromPath('file', file.path));

      var streamedResponse = await request.send();
      var response = await http.Response.fromStream(streamedResponse);

      return await _handleResponse(response, 'upload image');
    } catch (e) {
      return await _handleError(e, 'upload image');
    }
  }

  // ==========================================
  // UPLOAD DOCUMENT
  // Endpoint: POST /api/upload/document
  // ==========================================
  static Future<Map<String, dynamic>> uploadDocument(
    String token,
    File file,
  ) async {
    try {
      var request = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl/upload/document'),
      );

      // Only add Authorization, let MultipartRequest handle Content-Type
      request.headers['Authorization'] = 'Bearer $token';
      request.files.add(await http.MultipartFile.fromPath('file', file.path));

      var streamedResponse = await request.send();
      var response = await http.Response.fromStream(streamedResponse);

      return await _handleResponse(response, 'upload document');
    } catch (e) {
      return await _handleError(e, 'upload document');
    }
  }
}
