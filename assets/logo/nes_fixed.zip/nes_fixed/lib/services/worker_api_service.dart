// lib/services/worker_api_service.dart
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class WorkerApiService {
  static String get baseUrl {
    return 'https://nestoric-backend.onrender.com/api';
  }

  static Map<String, String> _getHeaders(String? token) {
    return {
      'Content-Type': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  static Future<Map<String, dynamic>> _handleResponse(
    http.Response response,
    String operation,
  ) async {
    try {
      final data = jsonDecode(response.body) as Map<String, dynamic>;

      if (response.statusCode >= 200 && response.statusCode < 300) {
        return {'success': true, ...data};
      } else {
        return {
          'success': false,
          'error': data['error'] ?? data['message'] ?? 'Failed to $operation',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'error': 'Invalid response format: ${e.toString()}',
      };
    }
  }

  static Future<Map<String, dynamic>> _handleError(
    dynamic error,
    String operation,
  ) async {
    if (error is SocketException) {
      return {
        'success': false,
        'error': 'No internet connection. Please check your network.',
      };
    } else if (error is HttpException) {
      return {
        'success': false,
        'error': 'Could not connect to server. Please try again.',
      };
    } else if (error is FormatException) {
      return {
        'success': false,
        'error': 'Invalid data format received from server.',
      };
    } else {
      return {'success': false, 'error': 'Network error: ${error.toString()}'};
    }
  }

  // ==========================================
  // GET WORKER'S ASSIGNED TASKS
  // ==========================================
  static Future<Map<String, dynamic>> getMyTasks(String token) async {
    try {
      final response = await http
          .get(
            Uri.parse('$baseUrl/requests/my-tasks'),
            headers: _getHeaders(token),
          )
          .timeout(const Duration(seconds: 30));

      return await _handleResponse(response, 'get tasks');
    } catch (e) {
      return await _handleError(e, 'get tasks');
    }
  }

  // ==========================================
  // UPDATE TASK STATUS
  // ==========================================
  static Future<Map<String, dynamic>> updateTaskStatus({
    required String token,
    required String taskId,
    required String status,
    String? note,
  }) async {
    try {
      final response = await http
          .put(
            Uri.parse('$baseUrl/requests/$taskId/status'),
            headers: _getHeaders(token),
            body: jsonEncode({
              'status': status,
              if (note != null && note.isNotEmpty) 'note': note,
            }),
          )
          .timeout(const Duration(seconds: 30));

      return await _handleResponse(response, 'update status');
    } catch (e) {
      return await _handleError(e, 'update status');
    }
  }

  // ==========================================
  // ADD/UPDATE TASK NOTE
  // ==========================================
  static Future<Map<String, dynamic>> updateTaskNote({
    required String token,
    required String taskId,
    required String note,
  }) async {
    try {
      final response = await http
          .put(
            Uri.parse('$baseUrl/requests/$taskId/note'),
            headers: _getHeaders(token),
            body: jsonEncode({'note': note}),
          )
          .timeout(const Duration(seconds: 30));

      return await _handleResponse(response, 'update note');
    } catch (e) {
      return await _handleError(e, 'update note');
    }
  }

  // ==========================================
  // UPLOAD FILE TO TASK
  // ==========================================
  static Future<Map<String, dynamic>> uploadFile({
    required String token,
    required String taskId,
    required String fileName,
    required List<int> fileBytes,
  }) async {
    try {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse('$baseUrl/requests/$taskId/upload'),
      );

      request.headers.addAll(_getHeaders(token));
      request.files.add(
        http.MultipartFile.fromBytes('file', fileBytes, filename: fileName),
      );

      final streamedResponse = await request.send().timeout(
        const Duration(seconds: 60),
      );
      final response = await http.Response.fromStream(streamedResponse);

      return await _handleResponse(response, 'upload file');
    } catch (e) {
      return await _handleError(e, 'upload file');
    }
  }

  // ==========================================
  // DELETE UPLOADED FILE
  // ==========================================
  static Future<Map<String, dynamic>> deleteFile({
    required String token,
    required String taskId,
    required String fileName,
  }) async {
    try {
      final response = await http
          .delete(
            Uri.parse('$baseUrl/requests/$taskId/files/$fileName'),
            headers: _getHeaders(token),
          )
          .timeout(const Duration(seconds: 30));

      return await _handleResponse(response, 'delete file');
    } catch (e) {
      return await _handleError(e, 'delete file');
    }
  }

  // ==========================================
  // GET WORKER STATS
  // ==========================================
  static Future<Map<String, dynamic>> getWorkerStats(String token) async {
    try {
      final response = await http
          .get(
            Uri.parse('$baseUrl/users/worker-stats'),
            headers: _getHeaders(token),
          )
          .timeout(const Duration(seconds: 30));

      return await _handleResponse(response, 'get stats');
    } catch (e) {
      return await _handleError(e, 'get stats');
    }
  }
}
