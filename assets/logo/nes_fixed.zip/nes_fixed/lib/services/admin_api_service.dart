// lib/services/admin_api_service.dart
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;

class AdminApiService {
  static String get baseUrl {
    return 'https://nestoric-backend.onrender.com/api';
  }

  static Map<String, String> _getHeaders(String? token) {
    return {
      'Content-Type': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  static Future<Map<String, dynamic>> _handleResponse(
    http.Response response,
    String operation,
  ) async {
    try {
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      if (response.statusCode >= 200 && response.statusCode < 300) {
        return {'success': true, ...data};
      } else {
        return {
          'success': false,
          'error': data['error'] ?? data['message'] ?? 'Failed to $operation',
        };
      }
    } catch (e) {
      return {
        'success': false,
        'error': 'Invalid response format: ${e.toString()}',
      };
    }
  }

  static Future<Map<String, dynamic>> _handleError(
    dynamic error,
    String operation,
  ) async {
    if (error is SocketException) {
      return {
        'success': false,
        'error': 'No internet connection. Please check your network.',
      };
    } else if (error is HttpException) {
      return {
        'success': false,
        'error': 'Could not connect to server. Please try again.',
      };
    } else if (error is FormatException) {
      return {
        'success': false,
        'error': 'Invalid data format received from server.',
      };
    } else {
      return {'success': false, 'error': 'Network error: ${error.toString()}'};
    }
  }

  // ==========================================
  // GET ALL REQUESTS
  // ==========================================
  static Future<Map<String, dynamic>> getAllRequests(String token) async {
    try {
      final response = await http
          .get(Uri.parse('$baseUrl/requests'), headers: _getHeaders(token))
          .timeout(const Duration(seconds: 30));
      return await _handleResponse(response, 'get requests');
    } catch (e) {
      return await _handleError(e, 'get requests');
    }
  }

  // ==========================================
  // GET ALL WORKERS
  // ==========================================
  static Future<Map<String, dynamic>> getAllWorkers(String token) async {
    try {
      final response = await http
          .get(Uri.parse('$baseUrl/users/workers'), headers: _getHeaders(token))
          .timeout(const Duration(seconds: 30));
      return await _handleResponse(response, 'get workers');
    } catch (e) {
      return await _handleError(e, 'get workers');
    }
  }

  // ==========================================
  // CREATE WORKER
  // ==========================================
  static Future<Map<String, dynamic>> createWorker({
    required String token,
    required String email,
    required String password,
    required String fullName,
    required List<String> skills,
    String? phone,
  }) async {
    try {
      final response = await http
          .post(
            Uri.parse('$baseUrl/users/workers'),
            headers: _getHeaders(token),
            body: jsonEncode({
              'email': email,
              'password': password,
              'fullName': fullName,
              'skills': skills,
              'emailVerified':
                  true, // Admin-created workers skip email verification
              if (phone != null && phone.isNotEmpty) 'phone': phone,
            }),
          )
          .timeout(const Duration(seconds: 30));
      return await _handleResponse(response, 'create worker');
    } catch (e) {
      return await _handleError(e, 'create worker');
    }
  }

  // ==========================================
  // UPDATE WORKER
  // ==========================================
  static Future<Map<String, dynamic>> updateWorker({
    required String token,
    required String workerId,
    String? fullName,
    List<String>? skills,
    bool? isAvailable,
    String? phone,
  }) async {
    try {
      final body = <String, dynamic>{};
      if (fullName != null && fullName.isNotEmpty) body['fullName'] = fullName;
      if (skills != null && skills.isNotEmpty) body['skills'] = skills;
      if (isAvailable != null) body['isAvailable'] = isAvailable;
      if (phone != null) body['phone'] = phone;
      if (body.isEmpty) {
        return {'success': false, 'error': 'No fields to update'};
      }

      final response = await http
          .put(
            Uri.parse('$baseUrl/users/workers/$workerId'),
            headers: _getHeaders(token),
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 30));
      return await _handleResponse(response, 'update worker');
    } catch (e) {
      return await _handleError(e, 'update worker');
    }
  }

  // ==========================================
  // DELETE WORKER
  // ==========================================
  static Future<Map<String, dynamic>> deleteWorker({
    required String token,
    required String workerId,
  }) async {
    try {
      final response = await http
          .delete(
            Uri.parse('$baseUrl/users/workers/$workerId'),
            headers: _getHeaders(token),
          )
          .timeout(const Duration(seconds: 30));
      return await _handleResponse(response, 'delete worker');
    } catch (e) {
      return await _handleError(e, 'delete worker');
    }
  }

  // ==========================================
  // ASSIGN WORKER TO REQUEST
  // ==========================================
  static Future<Map<String, dynamic>> assignWorker({
    required String token,
    required String requestId,
    required String workerId,
  }) async {
    try {
      final response = await http
          .put(
            Uri.parse('$baseUrl/requests/$requestId'),
            headers: _getHeaders(token),
            body: jsonEncode({'assignedWorkerId': workerId}),
          )
          .timeout(const Duration(seconds: 30));
      return await _handleResponse(response, 'assign worker');
    } catch (e) {
      return await _handleError(e, 'assign worker');
    }
  }

  // ==========================================
  // UPDATE REQUEST STATUS
  // ==========================================
  static Future<Map<String, dynamic>> updateRequestStatus({
    required String token,
    required String requestId,
    required String status,
    String? note,
  }) async {
    try {
      final response = await http
          .put(
            Uri.parse('$baseUrl/requests/$requestId'),
            headers: _getHeaders(token),
            body: jsonEncode({
              'status': status,
              if (note != null && note.isNotEmpty) 'note': note,
            }),
          )
          .timeout(const Duration(seconds: 30));
      return await _handleResponse(response, 'update status');
    } catch (e) {
      return await _handleError(e, 'update status');
    }
  }

  // ==========================================
  // DELETE REQUEST
  // ==========================================
  static Future<Map<String, dynamic>> deleteRequest({
    required String token,
    required String requestId,
  }) async {
    try {
      final response = await http
          .delete(
            Uri.parse('$baseUrl/requests/$requestId'),
            headers: _getHeaders(token),
          )
          .timeout(const Duration(seconds: 30));
      return await _handleResponse(response, 'delete request');
    } catch (e) {
      return await _handleError(e, 'delete request');
    }
  }

  // ==========================================
  // GET ADMIN STATS
  // ==========================================
  static Future<Map<String, dynamic>> getAdminStats(String token) async {
    try {
      final response = await http
          .get(Uri.parse('$baseUrl/users/stats'), headers: _getHeaders(token))
          .timeout(const Duration(seconds: 30));
      return await _handleResponse(response, 'get stats');
    } catch (e) {
      return await _handleError(e, 'get stats');
    }
  }

  // ==========================================
  // SERVICE PRICING — GET ALL (admin, includes inactive)
  // ==========================================
  static Future<Map<String, dynamic>> getAllServicePrices(String token) async {
    try {
      final response = await http
          .get(Uri.parse('$baseUrl/pricing/all'), headers: _getHeaders(token))
          .timeout(const Duration(seconds: 30));
      return await _handleResponse(response, 'get service prices');
    } catch (e) {
      return await _handleError(e, 'get service prices');
    }
  }

  // ==========================================
  // SERVICE PRICING — GET ACTIVE ONLY (client/payment page)
  // ==========================================
  static Future<Map<String, dynamic>> getActiveServicePrices() async {
    try {
      final response = await http
          .get(Uri.parse('$baseUrl/pricing'))
          .timeout(const Duration(seconds: 30));
      return await _handleResponse(response, 'get active prices');
    } catch (e) {
      return await _handleError(e, 'get active prices');
    }
  }

  // ==========================================
  // SERVICE PRICING — UPDATE price or isActive
  // ==========================================
  static Future<Map<String, dynamic>> updateServicePrice({
    required String token,
    required String serviceId,
    double? price,
    bool? isActive,
  }) async {
    try {
      final body = <String, dynamic>{};
      if (price != null) body['price'] = price;
      if (isActive != null) body['isActive'] = isActive;

      final response = await http
          .put(
            Uri.parse('$baseUrl/pricing/$serviceId'),
            headers: _getHeaders(token),
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 30));
      return await _handleResponse(response, 'update service price');
    } catch (e) {
      return await _handleError(e, 'update service price');
    }
  }

  // ==========================================
  // SERVICE PRICING — ADD NEW SERVICE
  // ==========================================
  static Future<Map<String, dynamic>> addServicePrice({
    required String token,
    required String serviceName,
    required double price,
  }) async {
    try {
      final response = await http
          .post(
            Uri.parse('$baseUrl/pricing'),
            headers: _getHeaders(token),
            body: jsonEncode({'serviceName': serviceName, 'price': price}),
          )
          .timeout(const Duration(seconds: 30));
      return await _handleResponse(response, 'add service price');
    } catch (e) {
      return await _handleError(e, 'add service price');
    }
  }

  // ==========================================
  // SERVICE PRICING — DELETE SERVICE
  // ==========================================
  static Future<Map<String, dynamic>> deleteServicePrice({
    required String token,
    required String serviceId,
  }) async {
    try {
      final response = await http
          .delete(
            Uri.parse('$baseUrl/pricing/$serviceId'),
            headers: _getHeaders(token),
          )
          .timeout(const Duration(seconds: 30));
      return await _handleResponse(response, 'delete service price');
    } catch (e) {
      return await _handleError(e, 'delete service price');
    }
  }

  // ==========================================
  // PLAN TIERS — GET ALL (public)
  // Returns Basic / Standard / Premium tiers with multipliers and perks
  // ==========================================
  static Future<Map<String, dynamic>> getPlanTiers() async {
    try {
      final response = await http
          .get(Uri.parse('$baseUrl/pricing/plans'))
          .timeout(const Duration(seconds: 30));
      return await _handleResponse(response, 'get plan tiers');
    } catch (e) {
      return await _handleError(e, 'get plan tiers');
    }
  }

  // ==========================================
  // PLAN TIERS — UPDATE (admin only)
  // Updates multiplier and/or perks for a tier (basic|standard|premium)
  // ==========================================
  static Future<Map<String, dynamic>> updatePlanTier({
    required String token,
    required String tierId, // 'basic' | 'standard' | 'premium'
    double? multiplier,
    List<String>? perks,
  }) async {
    try {
      final body = <String, dynamic>{};
      if (multiplier != null) body['multiplier'] = multiplier;
      if (perks != null) body['perks'] = perks;

      final response = await http
          .put(
            Uri.parse('$baseUrl/pricing/plans/$tierId'),
            headers: _getHeaders(token),
            body: jsonEncode(body),
          )
          .timeout(const Duration(seconds: 30));
      return await _handleResponse(response, 'update plan tier');
    } catch (e) {
      return await _handleError(e, 'update plan tier');
    }
  }
}
