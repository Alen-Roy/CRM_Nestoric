import 'package:flutter/material.dart';

class ScreenSize {
  static Size size(BuildContext context) => MediaQuery.of(context).size;

  static double width(BuildContext context) =>
      MediaQuery.of(context).size.width;

  static double height(BuildContext context) =>
      MediaQuery.of(context).size.height;

  static double safeHeight(BuildContext context) {
    final mq = MediaQuery.of(context);
    return mq.size.height - mq.padding.top;
  }
}
