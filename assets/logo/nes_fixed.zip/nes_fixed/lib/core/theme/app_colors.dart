import 'package:flutter/material.dart';

/// Enhanced color palette for clay/glassmorphism design
class AppColors {
  // Primary Colors - Soft purple/lavender for clay feel
  static const Color primary = Color(0xFF8B7FD5);
  static const Color primaryLight = Color(0xFFA599E0);
  static const Color primaryDark = Color(0xFF6B5FB8);
  static const Color primarySofter = Color(0xFFB8ADEB);

  // Accent Colors
  static const Color accent = Color(0xFFE8B4F7);
  static const Color accentLight = Color(0xFFF3D4FC);
  static const Color success = Color(0xFF68D391);
  static const Color successSoft = Color(0xFFE6F9EE);
  static const Color warning = Color(0xFFFBD38D);
  static const Color warningSoft = Color(0xFFFFF9E6);
  static const Color error = Color(0xFFFC8181);
  static const Color errorSoft = Color(0xFFFEEBEB);
  static const Color info = Color(0xFF63B3ED);
  static const Color infoSoft = Color(0xFFE8F4FD);
  static const Color pending = Color(0xFFF6AD55);
  static const Color pendingSoft = Color(0xFFFFF3E0);

  // Shimmer & Glow
  static const Color shimmerBase = Color(0xFFE8E6F0);
  static const Color shimmerHighlight = Color(0xFFF5F4FA);
  static const Color glowPrimary = Color(0x408B7FD5);

  // Neutral Colors
  static const Color white = Color(0xFFFFFFFF);
  static const Color black = Color(0xFF000000);
  static const Color grey50 = Color(0xFFFAFAFA);
  static const Color grey100 = Color(0xFFF5F5F5);
  static const Color grey200 = Color(0xFFEEEEEE);
  static const Color grey300 = Color(0xFFE0E0E0);
  static const Color grey400 = Color(0xFFBDBDBD);
  static const Color grey500 = Color(0xFF9E9E9E);
  static const Color grey600 = Color(0xFF757575);
  static const Color grey700 = Color(0xFF616161);
  static const Color grey800 = Color(0xFF424242);
  static const Color grey900 = Color(0xFF212121);

  // Background Colors
  static const Color lightBackground = Color(0xFFDEE4EA);
  static const Color darkBackground = Color(0xFF2A2A2A);

  // Surface Colors - for cards and containers
  static const Color lightSurface = Color(0xFFFFFFFF);
  static const Color darkSurface = Color(0xFF2D2D2D);
  static const Color darkSurfaceVariant = Color(0xFF383838);

  // Text Colors
  static const Color textDark = Color(0xFF1A1A1A);
  static const Color textLight = Color(0xFFECECF5);
  static const Color textSecondaryDark = Color(0xFF6B7280);
  static const Color textSecondaryLight = Color(0xFFA8A8BE);

  // TextField Colors
  static const Color textFieldFillLight = Color(0xFFF2F1F7);
  static const Color textFieldFillDark = Color(0xFF333333);

  // Shadow & Overlay Colors
  static const Color shadowLight = Color(0x1A000000);
  static const Color shadowDark = Color(0x33000000);
  static const Color overlay = Color(0x66000000);

  // Clay effect colors
  static const Color clayLight = Color(0xFFF5F4F9);
  static const Color clayDark = Color(0xFF2D2D2D);

  // Glassmorphism effect colors
  static Color glassLight = Colors.white.withValues(alpha: 0.7);
  static Color glassDark = Colors.white.withValues(alpha: 0.1);

  // Gradient combinations
  static const LinearGradient primaryGradient = LinearGradient(
    colors: [primary, primaryLight],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient accentGradient = LinearGradient(
    colors: [accent, accentLight],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient clayLightGradient = LinearGradient(
    colors: [clayLight, white],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient clayDarkGradient = LinearGradient(
    colors: [darkSurface, darkSurfaceVariant],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}
