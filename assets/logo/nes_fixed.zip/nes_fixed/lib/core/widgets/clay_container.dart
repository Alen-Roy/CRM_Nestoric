import 'dart:math' as math;

import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

/// Beautiful clay/neumorphic container widget.
/// Performance-optimized: uses StatelessWidget when no tap animation is needed.
class ClayContainer extends StatelessWidget {
  final Widget? child;
  final double? width;
  final double? height;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final Color? color;
  final double borderRadius;
  final double spread;
  final BorderRadius? customBorderRadius;
  final double depth;
  final bool emboss;
  final Gradient? gradient;
  final Border? border;
  final VoidCallback? onTap;

  /// Optional: Override shadow colors for animation smoothness
  final Color? shadowColor1;
  final Color? shadowColor2;

  const ClayContainer({
    super.key,
    this.child,
    this.width,
    this.height,
    this.padding,
    this.margin,
    this.color,
    this.borderRadius = 24,
    this.customBorderRadius,
    this.depth = 20,
    this.spread = 1,
    this.emboss = false,
    this.gradient,
    this.border,
    this.onTap,
    this.shadowColor1,
    this.shadowColor2,
  });

  @override
  Widget build(BuildContext context) {
    // If tappable, delegate to the animated version
    if (onTap != null) {
      return _TappableClayContainer(
        width: width,
        height: height,
        padding: padding,
        margin: margin,
        color: color,
        borderRadius: borderRadius,
        customBorderRadius: customBorderRadius,
        depth: depth,
        spread: spread,
        emboss: emboss,
        gradient: gradient,
        border: border,
        onTap: onTap,
        shadowColor1: shadowColor1,
        shadowColor2: shadowColor2,
        child: child,
      );
    }

    // Static render — no AnimationController needed
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final baseColor =
        color ?? (isDark ? AppColors.darkSurface : AppColors.lightSurface);

    // Cap depth for performance — larger blur = more GPU work
    final clampedDepth = depth.clamp(0.0, 16.0);

    final effectiveShadowColor1 =
        shadowColor1 ??
        (isDark
            ? Colors.black.withValues(alpha: 0.4)
            : Colors.black.withValues(alpha: 0.12));
    final effectiveShadowColor2 =
        shadowColor2 ??
        (isDark
            ? Colors.white.withValues(alpha: 0.04)
            : Colors.white.withValues(alpha: 0.7));

    final radius = customBorderRadius ?? BorderRadius.circular(borderRadius);

    return Container(
      width: width,
      height: height,
      padding: padding,
      margin: margin,
      decoration: BoxDecoration(
        color: gradient == null ? baseColor : null,
        gradient: gradient,
        borderRadius: radius,
        border: border,
        boxShadow: emboss
            ? _getEmbossedShadows(
                clampedDepth,
                spread,
                effectiveShadowColor1,
                effectiveShadowColor2,
              )
            : _getRaisedShadows(
                clampedDepth,
                spread,
                effectiveShadowColor1,
                effectiveShadowColor2,
              ),
      ),
      child: child,
    );
  }

  static List<BoxShadow> _getRaisedShadows(
    double depth,
    double spread,
    Color shadowColor1,
    Color shadowColor2,
  ) {
    return [
      BoxShadow(
        color: shadowColor1,
        offset: Offset(depth / 3, depth / 3),
        blurRadius: depth * 0.8,
        spreadRadius: spread * 0.5,
      ),
      BoxShadow(
        color: shadowColor2,
        offset: Offset(-depth / 5, -depth / 5),
        blurRadius: depth * 0.4,
        spreadRadius: spread * 0.5,
      ),
    ];
  }

  static List<BoxShadow> _getEmbossedShadows(
    double depth,
    double spread,
    Color shadowColor1,
    Color shadowColor2,
  ) {
    return [
      BoxShadow(
        color: shadowColor2,
        offset: Offset(depth / 3, depth / 3),
        blurRadius: depth * 0.8,
        spreadRadius: -spread,
      ),
      BoxShadow(
        color: shadowColor1,
        offset: Offset(-depth / 5, -depth / 5),
        blurRadius: depth * 0.4,
        spreadRadius: -spread,
      ),
    ];
  }
}

/// Internal tappable version — only used when onTap is provided
class _TappableClayContainer extends StatefulWidget {
  final Widget? child;
  final double? width;
  final double? height;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final Color? color;
  final double borderRadius;
  final double spread;
  final BorderRadius? customBorderRadius;
  final double depth;
  final bool emboss;
  final Gradient? gradient;
  final Border? border;
  final VoidCallback? onTap;
  final Color? shadowColor1;
  final Color? shadowColor2;

  const _TappableClayContainer({
    this.child,
    this.width,
    this.height,
    this.padding,
    this.margin,
    this.color,
    this.borderRadius = 24,
    this.customBorderRadius,
    this.depth = 20,
    this.spread = 1,
    this.emboss = false,
    this.gradient,
    this.border,
    this.onTap,
    this.shadowColor1,
    this.shadowColor2,
  });

  @override
  State<_TappableClayContainer> createState() => _TappableClayContainerState();
}

class _TappableClayContainerState extends State<_TappableClayContainer>
    with SingleTickerProviderStateMixin {
  late AnimationController _tapController;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _tapController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 100),
      reverseDuration: const Duration(milliseconds: 180),
    );
    _scaleAnim = Tween<double>(
      begin: 1.0,
      end: 0.96,
    ).animate(CurvedAnimation(parent: _tapController, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _tapController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final baseColor =
        widget.color ??
        (isDark ? AppColors.darkSurface : AppColors.lightSurface);

    final clampedDepth = widget.depth.clamp(0.0, 16.0);

    final effectiveShadowColor1 =
        widget.shadowColor1 ??
        (isDark
            ? Colors.black.withValues(alpha: 0.4)
            : Colors.black.withValues(alpha: 0.12));
    final effectiveShadowColor2 =
        widget.shadowColor2 ??
        (isDark
            ? Colors.white.withValues(alpha: 0.04)
            : Colors.white.withValues(alpha: 0.7));

    final radius =
        widget.customBorderRadius ?? BorderRadius.circular(widget.borderRadius);

    final container = Container(
      width: widget.width,
      height: widget.height,
      padding: widget.padding,
      margin: widget.margin,
      decoration: BoxDecoration(
        color: widget.gradient == null ? baseColor : null,
        gradient: widget.gradient,
        borderRadius: radius,
        border: widget.border,
        boxShadow: widget.emboss
            ? ClayContainer._getEmbossedShadows(
                clampedDepth,
                widget.spread,
                effectiveShadowColor1,
                effectiveShadowColor2,
              )
            : ClayContainer._getRaisedShadows(
                clampedDepth,
                widget.spread,
                effectiveShadowColor1,
                effectiveShadowColor2,
              ),
      ),
      child: widget.child,
    );

    return GestureDetector(
      onTap: widget.onTap,
      onTapDown: (_) => _tapController.forward(),
      onTapUp: (_) => _tapController.reverse(),
      onTapCancel: () => _tapController.reverse(),
      child: AnimatedBuilder(
        animation: _scaleAnim,
        builder: (context, child) {
          return Transform.scale(scale: _scaleAnim.value, child: child);
        },
        child: container,
      ),
    );
  }
}

/// Premium clay-styled button with gradient and press animation
class ClayButton extends StatefulWidget {
  final String text;
  final VoidCallback? onPressed;
  final Gradient? gradient;
  final Color? color;
  final double height;
  final double borderRadius;
  final bool isLoading;
  final IconData? icon;
  final TextStyle? textStyle;

  const ClayButton({
    super.key,
    required this.text,
    this.onPressed,
    this.gradient,
    this.color,
    this.height = 56,
    this.borderRadius = 16,
    this.isLoading = false,
    this.icon,
    this.textStyle,
  });

  @override
  State<ClayButton> createState() => _ClayButtonState();
}

class _ClayButtonState extends State<ClayButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnim;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 100),
      reverseDuration: const Duration(milliseconds: 200),
    );
    _scaleAnim = Tween<double>(
      begin: 1.0,
      end: 0.95,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final btnGradient =
        widget.gradient ??
        LinearGradient(
          colors: [
            widget.color ?? theme.colorScheme.primary,
            (widget.color ?? theme.colorScheme.primary).withValues(alpha: 0.8),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        );

    return GestureDetector(
      onTapDown: widget.onPressed != null && !widget.isLoading
          ? (_) => _controller.forward()
          : null,
      onTapUp: widget.onPressed != null && !widget.isLoading
          ? (_) {
              _controller.reverse();
              widget.onPressed?.call();
            }
          : null,
      onTapCancel: () => _controller.reverse(),
      child: AnimatedBuilder(
        animation: _controller,
        builder: (context, child) {
          return Transform.scale(
            scale: _scaleAnim.value,
            child: AnimatedOpacity(
              opacity: widget.onPressed != null ? 1.0 : 0.5,
              duration: const Duration(milliseconds: 200),
              child: Container(
                height: widget.height,
                decoration: BoxDecoration(
                  gradient: btnGradient,
                  borderRadius: BorderRadius.circular(widget.borderRadius),
                  boxShadow: [
                    BoxShadow(
                      color: (widget.color ?? theme.colorScheme.primary)
                          .withValues(alpha: 0.25),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                      spreadRadius: -2,
                    ),
                  ],
                ),
                child: Center(
                  child: widget.isLoading
                      ? const SizedBox(
                          height: 22,
                          width: 22,
                          child: CircularProgressIndicator(
                            strokeWidth: 2.5,
                            color: Colors.white,
                          ),
                        )
                      : Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            if (widget.icon != null) ...[
                              Icon(widget.icon, color: Colors.white, size: 20),
                              const SizedBox(width: 10),
                            ],
                            Text(
                              widget.text,
                              style:
                                  widget.textStyle ??
                                  const TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.3,
                                  ),
                            ),
                          ],
                        ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

/// Animated list item that fades and slides in with staggered delay
class AnimatedListItem extends StatelessWidget {
  final Widget child;
  final int index;
  final Duration duration;
  final Duration staggerDelay;
  final Offset beginOffset;

  const AnimatedListItem({
    super.key,
    required this.child,
    required this.index,
    this.duration = const Duration(milliseconds: 400),
    this.staggerDelay = const Duration(milliseconds: 80),
    this.beginOffset = const Offset(0, 30),
  });

  @override
  Widget build(BuildContext context) {
    final delay = Duration(milliseconds: staggerDelay.inMilliseconds * index);

    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0.0, end: 1.0),
      duration: duration + delay,
      curve: Curves.easeOutCubic,
      builder: (context, value, child) {
        final delayFraction =
            delay.inMilliseconds /
            (duration.inMilliseconds + delay.inMilliseconds);
        final adjustedValue = ((value - delayFraction) / (1 - delayFraction))
            .clamp(0.0, 1.0);

        return Transform.translate(
          offset: Offset(
            beginOffset.dx * (1 - adjustedValue),
            beginOffset.dy * (1 - adjustedValue),
          ),
          child: Opacity(opacity: adjustedValue, child: child),
        );
      },
      child: child,
    );
  }
}

/// Lightweight glass-like container (no BackdropFilter for performance)
class GlassContainer extends StatelessWidget {
  final Widget? child;
  final double? width;
  final double? height;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;
  final double borderRadius;
  final double opacity;
  final Color? color;
  final Border? border;
  final VoidCallback? onTap;

  const GlassContainer({
    super.key,
    this.child,
    this.width,
    this.height,
    this.padding,
    this.margin,
    this.borderRadius = 24,
    this.opacity = 0.2,
    this.color,
    this.border,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final baseColor =
        color ??
        (isDark
            ? Colors.white.withValues(alpha: opacity)
            : Colors.white.withValues(alpha: opacity + 0.3));

    final container = Container(
      width: width,
      height: height,
      padding: padding,
      margin: margin,
      decoration: BoxDecoration(
        color: baseColor,
        borderRadius: BorderRadius.circular(borderRadius),
        border:
            border ??
            Border.all(color: Colors.white.withValues(alpha: 0.15), width: 1),
        boxShadow: [
          BoxShadow(
            color: isDark
                ? Colors.black.withValues(alpha: 0.2)
                : Colors.black.withValues(alpha: 0.06),
            blurRadius: 8,
            spreadRadius: 0,
          ),
        ],
      ),
      child: child,
    );

    if (onTap != null) {
      return GestureDetector(onTap: onTap, child: container);
    }

    return container;
  }
}

/// Shimmer loading widget for smooth loading states
class ShimmerLoading extends StatefulWidget {
  final Widget child;
  final bool isLoading;
  final Color? baseColor;
  final Color? highlightColor;

  const ShimmerLoading({
    super.key,
    required this.child,
    required this.isLoading,
    this.baseColor,
    this.highlightColor,
  });

  @override
  State<ShimmerLoading> createState() => _ShimmerLoadingState();
}

class _ShimmerLoadingState extends State<ShimmerLoading>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!widget.isLoading) {
      return widget.child;
    }

    final isDark = Theme.of(context).brightness == Brightness.dark;
    final baseColor =
        widget.baseColor ?? (isDark ? AppColors.grey800 : AppColors.grey200);
    final highlightColor =
        widget.highlightColor ??
        (isDark ? AppColors.grey700 : AppColors.grey100);

    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return ShaderMask(
          shaderCallback: (bounds) {
            return LinearGradient(
              begin: Alignment(-1.0 + 2.0 * _controller.value, 0.0),
              end: Alignment(1.0 + 2.0 * _controller.value, 0.0),
              colors: [baseColor, highlightColor, baseColor],
              stops: const [0.0, 0.5, 1.0],
            ).createShader(bounds);
          },
          child: widget.child,
        );
      },
    );
  }
}

/// Clay-styled loading dots animation
class ClayLoadingDots extends StatefulWidget {
  final Color? color;
  final double dotSize;
  final int dotCount;

  const ClayLoadingDots({
    super.key,
    this.color,
    this.dotSize = 10,
    this.dotCount = 3,
  });

  @override
  State<ClayLoadingDots> createState() => _ClayLoadingDotsState();
}

class _ClayLoadingDotsState extends State<ClayLoadingDots>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final dotColor = widget.color ?? Theme.of(context).colorScheme.primary;

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(widget.dotCount, (index) {
        return AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            final delay = index / widget.dotCount;
            final progress = (_controller.value - delay).clamp(0.0, 1.0);
            final bounce = math.sin(progress * math.pi);

            return Container(
              margin: EdgeInsets.symmetric(horizontal: widget.dotSize * 0.4),
              width: widget.dotSize,
              height: widget.dotSize,
              child: Transform.translate(
                offset: Offset(0, -bounce * widget.dotSize),
                child: Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: dotColor.withValues(alpha: 0.5 + bounce * 0.5),
                    boxShadow: [
                      BoxShadow(
                        color: dotColor.withValues(alpha: bounce * 0.3),
                        blurRadius: 6,
                        spreadRadius: bounce,
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      }),
    );
  }
}
