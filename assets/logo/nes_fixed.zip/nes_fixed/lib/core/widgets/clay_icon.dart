import 'package:flutter/material.dart';
import 'package:nes/core/widgets/clay_container.dart';

class ClayIcon extends StatelessWidget {
  final IconData icon;
  final double size;
  final Color color;
  final Color baseColor;
  final double depth;
  final double spread;
  final bool emboss;
  final double borderRadius;
  final EdgeInsets padding;
  final VoidCallback? onTap;

  const ClayIcon({
    super.key,
    required this.icon,
    required this.color,
    required this.baseColor,
    this.size = 24,
    this.depth = 10,
    this.spread = 1,
    this.emboss = false,
    this.borderRadius = 100, // Circular by default
    this.padding = const EdgeInsets.all(12),
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    Widget content = ClayContainer(
      color: baseColor,
      borderRadius: borderRadius,
      depth: depth,
      spread: spread,
      emboss: emboss,
      padding: padding,
      child: Icon(icon, size: size, color: color),
    );

    if (onTap != null) {
      return GestureDetector(onTap: onTap, child: content);
    }

    return content;
  }
}
