import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import '../theme/app_colors.dart';
import 'clay_container.dart';

class SplashScreen extends ConsumerStatefulWidget {
  const SplashScreen({super.key});

  @override
  ConsumerState<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends ConsumerState<SplashScreen>
    with TickerProviderStateMixin {
  late AnimationController _mainController;
  late AnimationController _pulseController;
  late AnimationController _orbController;

  late Animation<double> _logoScale;
  late Animation<double> _logoOpacity;
  late Animation<double> _textOpacity;
  late Animation<double> _taglineOpacity;
  late Animation<double> _loaderOpacity;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();

    // Main staggered entrance
    _mainController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    );

    _logoScale = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(
        parent: _mainController,
        curve: const Interval(0.0, 0.4, curve: Curves.elasticOut),
      ),
    );
    _logoOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _mainController,
        curve: const Interval(0.0, 0.3, curve: Curves.easeOut),
      ),
    );
    _textOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _mainController,
        curve: const Interval(0.3, 0.55, curve: Curves.easeOut),
      ),
    );
    _taglineOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _mainController,
        curve: const Interval(0.45, 0.7, curve: Curves.easeOut),
      ),
    );
    _loaderOpacity = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _mainController,
        curve: const Interval(0.6, 0.85, curve: Curves.easeOut),
      ),
    );

    // Pulsing glow behind logo
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    )..repeat(reverse: true);

    _pulseAnim = Tween<double>(begin: 0.6, end: 1.0).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    // Floating orb controller
    _orbController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();

    _mainController.forward();
  }

  @override
  void dispose() {
    _mainController.dispose();
    _pulseController.dispose();
    _orbController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      body: Stack(
        children: [
          // Background gradient
          Container(
            width: size.width,
            height: size.height,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: isDark
                    ? [
                        AppColors.darkBackground,
                        const Color(0xFF130F2A),
                        AppColors.primaryDark.withValues(alpha: 0.3),
                      ]
                    : [
                        AppColors.lightBackground,
                        const Color(0xFFF0EDF9),
                        AppColors.primaryLight.withValues(alpha: 0.2),
                      ],
              ),
            ),
          ),

          // Floating orbs
          ..._buildFloatingOrbs(size, isDark),

          // Main content
          SafeArea(
            child: Center(
              child: AnimatedBuilder(
                animation: _mainController,
                builder: (context, _) {
                  return Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      // Logo with pulsing glow
                      _buildLogo(isDark),
                      const SizedBox(height: 36),

                      // App name
                      _buildTitle(isDark),
                      const SizedBox(height: 10),

                      // Tagline
                      _buildTagline(isDark),
                      const SizedBox(height: 52),

                      // Loading dots
                      Opacity(
                        opacity: _loaderOpacity.value,
                        child: const ClayLoadingDots(dotSize: 10, dotCount: 3),
                      ),
                    ],
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLogo(bool isDark) {
    return AnimatedBuilder(
      animation: _pulseAnim,
      builder: (context, child) {
        return Transform.scale(
          scale: _logoScale.value,
          child: Opacity(
            opacity: _logoOpacity.value,
            child: Stack(
              alignment: Alignment.center,
              children: [
                // Pulsing glow
                Container(
                  width: 140 + (20 * _pulseAnim.value),
                  height: 140 + (20 * _pulseAnim.value),
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.primary.withValues(
                          alpha: 0.2 * _pulseAnim.value,
                        ),
                        blurRadius: 40 * _pulseAnim.value,
                        spreadRadius: 10 * _pulseAnim.value,
                      ),
                    ],
                  ),
                ),
                // Logo image
                Container(
                  width: 120,
                  height: 120,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        AppColors.primary,
                        AppColors.primaryLight,
                        AppColors.accent.withValues(alpha: 0.6),
                      ],
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: AppColors.primary.withValues(alpha: 0.4),
                        blurRadius: 24,
                        offset: const Offset(0, 8),
                      ),
                      BoxShadow(
                        color: isDark
                            ? Colors.white.withValues(alpha: 0.05)
                            : Colors.white.withValues(alpha: 0.6),
                        blurRadius: 12,
                        offset: const Offset(-4, -4),
                      ),
                    ],
                  ),
                  // Clip the image to circular shape
                  child: ClipOval(
                    child: Image.asset(
                      'assets/icon/Logo.png',
                      width: 120,
                      height: 120,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const Icon(
                        Icons.home_work_rounded,
                        size: 56,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildTitle(bool isDark) {
    return Opacity(
      opacity: _textOpacity.value,
      child: Transform.translate(
        offset: Offset(0, 16 * (1 - _textOpacity.value)),
        child: Text(
          'Nexify',
          style: GoogleFonts.poppins(
            fontSize: 48,
            fontWeight: FontWeight.w800,
            foreground: Paint()
              ..shader = LinearGradient(
                colors: [
                  AppColors.primary,
                  AppColors.primaryLight,
                  AppColors.accent,
                ],
              ).createShader(const Rect.fromLTWH(0, 0, 300, 70)),
            letterSpacing: -1.5,
          ),
        ),
      ),
    );
  }

  Widget _buildTagline(bool isDark) {
    return Opacity(
      opacity: _taglineOpacity.value,
      child: Transform.translate(
        offset: Offset(0, 12 * (1 - _taglineOpacity.value)),
        child: Text(
          'Your Service Management Platform',
          style: GoogleFonts.inter(
            fontSize: 14,
            fontWeight: FontWeight.w500,
            color: isDark
                ? AppColors.textSecondaryLight
                : AppColors.textSecondaryDark,
            letterSpacing: 0.5,
          ),
        ),
      ),
    );
  }

  List<Widget> _buildFloatingOrbs(Size size, bool isDark) {
    final orbs = <_OrbData>[
      _OrbData(0.15, 0.2, 60, AppColors.primary.withValues(alpha: 0.08)),
      _OrbData(0.8, 0.15, 45, AppColors.accent.withValues(alpha: 0.06)),
      _OrbData(0.1, 0.7, 35, AppColors.primaryLight.withValues(alpha: 0.07)),
      _OrbData(0.85, 0.75, 50, AppColors.primary.withValues(alpha: 0.05)),
      _OrbData(0.5, 0.85, 40, AppColors.accent.withValues(alpha: 0.06)),
      _OrbData(0.35, 0.1, 30, AppColors.primarySofter.withValues(alpha: 0.08)),
    ];

    return orbs.asMap().entries.map((entry) {
      final i = entry.key;
      final orb = entry.value;
      return AnimatedBuilder(
        animation: _orbController,
        builder: (context, child) {
          final progress = (_orbController.value + i * 0.15) % 1.0;
          final xOff = math.sin(progress * 2 * math.pi) * 20;
          final yOff = math.cos(progress * 2 * math.pi + i) * 15;

          return Positioned(
            left: size.width * orb.x + xOff,
            top: size.height * orb.y + yOff,
            child: Container(
              width: orb.radius,
              height: orb.radius,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: orb.color,
                boxShadow: [
                  BoxShadow(
                    color: orb.color,
                    blurRadius: orb.radius,
                    spreadRadius: orb.radius * 0.3,
                  ),
                ],
              ),
            ),
          );
        },
      );
    }).toList();
  }
}

class _OrbData {
  final double x;
  final double y;
  final double radius;
  final Color color;
  const _OrbData(this.x, this.y, this.radius, this.color);
}
