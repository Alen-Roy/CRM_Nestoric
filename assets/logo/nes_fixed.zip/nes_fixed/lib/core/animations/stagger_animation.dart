import 'package:flutter/material.dart';

/// A mixin that provides a staggered animation controller for lists/sections.
/// Add to any State class with `TickerProviderStateMixin`.
///
/// Usage:
/// ```dart
/// class _MyPageState extends State<MyPage>
///     with TickerProviderStateMixin, StaggeredListMixin {
///
///   @override
///   int get staggerItemCount => 6;
///
///   @override
///   void initState() {
///     super.initState();
///     initStagger();
///   }
///
///   @override
///   void dispose() {
///     disposeStagger();
///     super.dispose();
///   }
///
///   Widget build(BuildContext context) {
///     return Column(children: [
///       StaggeredFadeSlide(index: 0, controller: staggerController, child: ...),
///       StaggeredFadeSlide(index: 1, controller: staggerController, child: ...),
///     ]);
///   }
/// }
/// ```
mixin StaggeredListMixin<T extends StatefulWidget>
    on State<T>, TickerProviderStateMixin<T> {
  late AnimationController staggerController;

  /// Override to set the number of items to stagger.
  int get staggerItemCount;

  /// Total animation duration. Default: 600ms + 60ms per additional item.
  Duration get staggerDuration =>
      Duration(milliseconds: 500 + (staggerItemCount * 50));

  void initStagger() {
    staggerController = AnimationController(
      vsync: this,
      duration: staggerDuration,
    );
    // Defer to after first layout to avoid animation during build
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) staggerController.forward();
    });
  }

  void disposeStagger() {
    staggerController.dispose();
  }
}

/// A widget that applies staggered fade + slide-up entrance animation.
/// Uses only `FadeTransition` and `SlideTransition` (GPU-composited).
class StaggeredFadeSlide extends StatelessWidget {
  final int index;
  final AnimationController controller;
  final Widget child;
  final int totalItems;
  final Offset slideOffset;

  const StaggeredFadeSlide({
    super.key,
    required this.index,
    required this.controller,
    required this.child,
    this.totalItems = 10,
    this.slideOffset = const Offset(0, 0.08),
  });

  @override
  Widget build(BuildContext context) {
    // Each item occupies ~40% of the timeline, starting at staggered offsets
    final itemCount = totalItems;
    final begin = (index / itemCount).clamp(0.0, 0.7);
    final end = ((index + 1) / itemCount + 0.3).clamp(begin + 0.1, 1.0);

    final curvedAnimation = CurvedAnimation(
      parent: controller,
      curve: Interval(begin, end, curve: Curves.easeOutCubic),
    );

    return FadeTransition(
      opacity: Tween<double>(begin: 0.0, end: 1.0).animate(curvedAnimation),
      child: SlideTransition(
        position: Tween<Offset>(
          begin: slideOffset,
          end: Offset.zero,
        ).animate(curvedAnimation),
        child: child,
      ),
    );
  }
}
