import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      default:
        throw UnsupportedError('Platform not supported');
    }
  }

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBycSAwN9ffyxnokjYAp33jVqxIyPVBtgE',
    appId: '1:258491487709:android:6d3d82799ff223ae3dd234',
    messagingSenderId: '258491487709',
    projectId: 'appnestoric',
    storageBucket: 'appnestoric.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyDJUt3T3NIBjMTt0FqEoKJU5xcaAQbTres',
    appId: '1:258491487709:ios:a96dbc52be490cb03dd234',
    messagingSenderId: '258491487709',
    projectId: 'appnestoric',
    storageBucket: 'appnestoric.firebasestorage.app',
    iosClientId: '258491487709-i5k8gd9s8amcgj8d20td3bt7tt0vgh94.apps.googleusercontent.com',
    iosBundleId: 'com.example.nes',
  );

}