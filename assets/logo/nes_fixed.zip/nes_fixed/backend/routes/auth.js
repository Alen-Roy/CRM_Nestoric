// routes/auth.js - AUTHENTICATION ROUTES
// Handles signup, login, google sign-in, get profile

const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const rateLimit = require('express-rate-limit');
const User = require('../models/User');
const PendingRegistration = require('../models/PendingRegistration');
const admin = require('firebase-admin');
const { sendVerificationEmail, sendPasswordResetEmail } = require('../utils/mailer');

const router = express.Router();

// ── Rate limiters ────────────────────────────────
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 10,                   // 10 attempts per window
  message: { error: 'Too many login attempts. Please try again in 15 minutes.' },
  standardHeaders: true,
  legacyHeaders: false,
});

const signupLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 5,                    // 5 signups per hour per IP
  message: { error: 'Too many accounts created. Please try again later.' },
  standardHeaders: true,
  legacyHeaders: false,
});

const forgotPasswordLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5,                    // 5 reset emails per window
  message: { error: 'Too many reset requests. Please try again in 15 minutes.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// ==========================================
// FIREBASE ADMIN - Initialized once
// ==========================================
// Initialize Firebase Admin if not already initialized
if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert({
      projectId: process.env.FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      // Replace escaped newlines that can appear in .env strings
      privateKey: process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, '\n'),
    }),
  });
}

// ==========================================
// GOOGLE SIGN-IN — Verify Firebase ID token
// and create/login user in our own DB
// ==========================================
router.post('/google', async (req, res) => {
  try {
    const { idToken } = req.body;

    if (!idToken) {
      return res.status(400).json({ error: 'Firebase ID token is required' });
    }

    // 1. Verify the token with Firebase Admin
    let decodedToken;
    try {
      decodedToken = await admin.auth().verifyIdToken(idToken);
    } catch (err) {
      return res.status(401).json({ error: 'Invalid or expired Google token' });
    }

    const { uid, email, name, picture } = decodedToken;

    if (!email) {
      return res.status(400).json({ error: 'Google account must have an email' });
    }

    // 2. Find existing user or create a new one
    let user = await User.findOne({ $or: [{ googleId: uid }, { email }] });

    if (user) {
      // User exists — update Google info if needed
      if (!user.googleId) {
        user.googleId = uid;
        user.authProvider = 'google';
        if (!user.avatarUrl && picture) user.avatarUrl = picture;
        await user.save();
      }
    } else {
      // New Google user — already verified since Google verified their email
      user = await User.create({
        email,
        fullName: name || email.split('@')[0],
        avatarUrl: picture || null,
        googleId: uid,
        authProvider: 'google',
        role: 'client',
        isEmailVerified: true, // Google handles email verification
      });
    }

    // 3. Issue our own JWT (same format as regular login)
    const token = jwt.sign(
      { userId: user._id, email: user.email, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '30d' }
    );

    res.json({
      message: 'Google sign-in successful',
      user: {
        id: user._id,
        email: user.email,
        fullName: user.fullName,
        role: user.role,
        avatarUrl: user.avatarUrl,
        phone: user.phone || null,
        workerProfile: user.workerProfile,
      },
      token,
    });

  } catch (error) {
    console.error('Google auth error:', error);
    res.status(500).json({ error: 'Failed to authenticate with Google' });
  }
});

// ==========================================
// SIGNUP - Create new user account
// ==========================================
router.post('/signup', signupLimiter, async (req, res) => {
  try {
    const { email, password, fullName, phone } = req.body;

    if (!email || !password || !fullName) {
      return res.status(400).json({ error: 'Please provide email, password, and full name' });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    // Check if a real user already exists with this email
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: 'Email already registered' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const rawToken = crypto.randomBytes(32).toString('hex');

    // Store in PendingRegistration — NOT creating a User yet
    await PendingRegistration.findOneAndUpdate(
      { email },
      {
        email,
        passwordHash: hashedPassword,
        fullName,
        phone: phone || null,
        token: rawToken,
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000),
      },
      { upsert: true, new: true }
    );

    // Send verification email
    console.log(`[Signup] Sending verification email to: ${email}`);
    try {
      await sendVerificationEmail(email, rawToken);
      console.log(`[Signup] Verification email sent successfully to: ${email}`);
    } catch (mailErr) {
      console.error('[Signup] RESEND ERROR:', JSON.stringify(mailErr, null, 2));
      // Still respond with requiresVerification so user stays on the right screen
      // They can use the resend button
    }

    res.status(201).json({
      requiresVerification: true,
      message: 'Please check your email to verify your account.',
      email,
    });

  } catch (error) {
    console.error('Signup error:', error);
    res.status(500).json({ error: 'Failed to register. Please try again.' });
  }
});

// ==========================================
// LOGIN - Authenticate existing user
// ==========================================
router.post('/login', loginLimiter, async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'Please provide email and password' });
    }

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    // Block login for unverified email/password accounts
    if (!user.isEmailVerified && user.authProvider !== 'google') {
      return res.status(403).json({
        error: 'EMAIL_NOT_VERIFIED',
        message: 'Please verify your email before logging in.',
        email: user.email,
      });
    }

    const isPasswordValid = await bcrypt.compare(password, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ error: 'Invalid email or password' });
    }

    const token = jwt.sign(
      { userId: user._id, email: user.email, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '30d' }
    );

    res.json({
      message: 'Login successful',
      user: {
        id: user._id,
        email: user.email,
        fullName: user.fullName,
        role: user.role,
        avatarUrl: user.avatarUrl,
        phone: user.phone || null,
        workerProfile: user.workerProfile,
      },
      token,
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Failed to login' });
  }
});

// ==========================================
// CHECK VERIFICATION STATUS (polling)
// Called by the Flutter app every few seconds while waiting.
// Returns a JWT when the user has verified their email.
// ==========================================
router.get('/check-verification', async (req, res) => {
  try {
    const { email, token: checkToken } = req.query;
    if (!email) return res.status(400).json({ verified: false });

    // Only allow check-verification if a valid pending-verification token is provided,
    // OR if the request comes within a short window after signup (rate-limited).
    // This prevents unauthenticated token harvesting by email.

    // First check if there's a pending registration for this email
    const PendingRegistration = require('../models/PendingRegistration');
    const pending = await PendingRegistration.findOne({ email });

    // Check if user exists and is verified
    const user = await User.findOne({ email, isEmailVerified: true });

    if (!user) {
      // Not yet verified — but we only confirm verified:false
      // (no token returned, no user data leaked)
      return res.json({ verified: false });
    }

    // User is verified — only return JWT if there's no pending registration
    // (meaning they completed verification) or if the pending record matches
    if (pending) {
      // Clean up the pending record since user is now verified
      await PendingRegistration.deleteOne({ _id: pending._id });
    }

    // Issue a JWT so the app can log in automatically
    const token = jwt.sign(
      { userId: user._id, email: user.email, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '30d' }
    );

    res.json({
      verified: true,
      token,
      user: {
        id: user._id,
        email: user.email,
        fullName: user.fullName,
        role: user.role,
        avatarUrl: user.avatarUrl,
        phone: user.phone || null,
        workerProfile: user.workerProfile,
      },
    });
  } catch (error) {
    console.error('Check verification error:', error);
    res.status(500).json({ verified: false });
  }
});

// ==========================================
// VERIFY EMAIL — user clicks link in email
// ==========================================
router.get('/verify-email/:token', async (req, res) => {
  try {
    const { token } = req.params;

    // Look up the pending registration by token
    const pending = await PendingRegistration.findOne({ token }).select('+token');

    if (!pending || pending.expiresAt < new Date()) {
      if (pending) await PendingRegistration.deleteOne({ _id: pending._id });
      return res.status(400).send(`
        <html><body style="font-family:sans-serif;text-align:center;padding:60px">
          <h2 style="color:#e53e3e">&#10060; Invalid or expired link</h2>
          <p>This verification link has expired. Please register again in the Nestoric app.</p>
        </body></html>
      `);
    }

    // Check if a user was already created (double-click protection)
    const existingUser = await User.findOne({ email: pending.email });
    if (existingUser) {
      await PendingRegistration.deleteOne({ _id: pending._id });
      return res.send(`
        <html><body style="font-family:-apple-system,sans-serif;text-align:center;padding:60px;background:#f5f5f5">
          <div style="max-width:480px;margin:0 auto;background:#fff;border-radius:16px;padding:48px;box-shadow:0 4px 24px rgba(0,0,0,0.08)">
            <div style="font-size:56px;margin-bottom:16px">&#9989;</div>
            <h2 style="color:#38a169;margin:0 0 12px">Already verified!</h2>
            <p style="color:#555;line-height:1.6">Your account is active. Open the app and sign in.</p>
          </div>
        </body></html>
      `);
    }

    // Create the real User now that email is verified
    await User.create({
      email: pending.email,
      password: pending.passwordHash,
      fullName: pending.fullName,
      phone: pending.phone || null,
      role: 'client',
      isEmailVerified: true,
    });

    // Delete the pending record
    await PendingRegistration.deleteOne({ _id: pending._id });

    res.send(`
      <html><body style="font-family:-apple-system,sans-serif;text-align:center;padding:60px;background:#f5f5f5">
        <div style="max-width:480px;margin:0 auto;background:#fff;border-radius:16px;padding:48px;box-shadow:0 4px 24px rgba(0,0,0,0.08)">
          <div style="font-size:56px;margin-bottom:16px">&#9989;</div>
          <h2 style="color:#38a169;margin:0 0 12px">Email verified!</h2>
          <p style="color:#555;line-height:1.6">Your Nestoric account is now active.<br/>Open the app and sign in to continue.</p>
        </div>
      </body></html>
    `);

  } catch (error) {
    console.error('Verify email error:', error);
    res.status(500).send('<h2>Something went wrong. Please try again.</h2>');
  }
});

// ==========================================
// RESEND VERIFICATION EMAIL
// ==========================================
router.post('/resend-verification', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email is required' });

    // Check if user already exists and is verified
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ error: 'Email is already verified. Please sign in.' });
    }

    // Look up pending registration
    const pending = await PendingRegistration.findOne({ email });
    if (!pending) {
      return res.status(404).json({ error: 'No pending registration found. Please register again.' });
    }

    // Generate a new token and update
    const rawToken = crypto.randomBytes(32).toString('hex');
    pending.token = rawToken;
    pending.expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000);
    await pending.save();

    console.log(`[Resend] Sending verification email to: ${email}`);
    await sendVerificationEmail(email, rawToken);
    console.log(`[Resend] Verification email sent successfully to: ${email}`);

    res.json({ message: 'Verification email resent successfully.' });

  } catch (error) {
    console.error('[Resend] Error:', JSON.stringify(error, null, 2));
    res.status(500).json({ error: 'Failed to resend verification email' });
  }
});

// ==========================================
// MIDDLEWARE - Verify JWT Token
// ==========================================
const authenticateToken = (req, res, next) => {
  // Get token from header
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1]; // Format: "Bearer TOKEN"

  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }

  try {
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded; // Attach user info to request
    next(); // Continue to next function
  } catch (error) {
    res.status(401).json({ error: 'Invalid token' });
  }
};

// ==========================================
// GET PROFILE - Get current user info
// ==========================================
router.get('/me', authenticateToken, async (req, res) => {
  try {
    // Get user from database (without password)
    const user = await User.findById(req.user.userId).select('-password');

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ user });

  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({ error: 'Failed to get profile' });
  }
});

// ==========================================
// UPDATE PROFILE - Update user information
// ==========================================
router.put('/profile', authenticateToken, async (req, res) => {
  try {
    const { fullName, avatarUrl, phone } = req.body;

    // Build update object
    const updateData = {};
    if (fullName) updateData.fullName = fullName;
    if (avatarUrl) updateData.avatarUrl = avatarUrl;
    if (phone !== undefined) updateData.phone = phone;

    // Update user
    const user = await User.findByIdAndUpdate(
      req.user.userId,
      updateData,
      { new: true } // Return updated document
    ).select('-password');

    res.json({
      message: 'Profile updated successfully',
      user: {
        id: user._id,
        email: user.email,
        fullName: user.fullName,
        role: user.role,
        avatarUrl: user.avatarUrl,
        phone: user.phone || null,
        workerProfile: user.workerProfile,
      }
    });

  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ error: 'Failed to update profile' });
  }
});

// ==========================================
// CHANGE PASSWORD
// ==========================================
router.put('/change-password', authenticateToken, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({
        error: 'Please provide current and new password'
      });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({
        error: 'New password must be at least 6 characters'
      });
    }

    // Get user with password
    const user = await User.findById(req.user.userId);

    // Verify current password
    const isPasswordValid = await bcrypt.compare(currentPassword, user.password);
    if (!isPasswordValid) {
      return res.status(401).json({ error: 'Current password is incorrect' });
    }

    // Hash new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Update password
    user.password = hashedPassword;
    await user.save();

    res.json({ message: 'Password changed successfully' });

  } catch (error) {
    console.error('Change password error:', error);
    res.status(500).json({ error: 'Failed to change password' });
  }
});

// ==========================================
// FORGOT PASSWORD - Generate token and send email
// ==========================================
router.post('/forgot-password', forgotPasswordLimiter, async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }

    const user = await User.findOne({ email });
    // Don't reveal if user exists for security, just return success
    if (!user) {
      return res.json({ message: 'If that email is registered, a reset link was sent.' });
    }

    // Generate token
    const token = crypto.randomBytes(32).toString('hex');

    // Save to user with expiry (1 hour)
    user.resetPasswordToken = token;
    user.resetPasswordExpires = new Date(Date.now() + 3600000); // 1 hour
    await user.save();

    // Send email — wrapped in its own try/catch so a Brevo failure
    // doesn't expose a 500 to the user (token is already saved in DB).
    console.log(`[ForgotPassword] Sending reset email to: ${user.email}`);
    try {
      await sendPasswordResetEmail(user.email, token);
      console.log(`[ForgotPassword] Reset email sent successfully to: ${user.email}`);
    } catch (mailErr) {
      console.error('[ForgotPassword] BREVO ERROR:', JSON.stringify(mailErr, null, 2));
      // Still return success — the token is saved; user can try again
    }

    res.json({ message: 'If that email is registered, a reset link was sent.' });
  } catch (error) {
    console.error('Forgot password error:', error);
    res.status(500).json({ error: 'Failed to process forgot password request.' });
  }
});

// ==========================================
// RESET PASSWORD FORM - Web page served from email link
// GET /api/auth/reset-password-form?token=...
// ==========================================
router.get('/reset-password-form', async (req, res) => {
  const { token } = req.query;

  if (!token) {
    return res.status(400).send(`
      <html><body style="font-family:-apple-system,sans-serif;text-align:center;padding:60px;background:#f5f5f5">
        <div style="max-width:480px;margin:0 auto;background:#fff;border-radius:16px;padding:48px;box-shadow:0 4px 24px rgba(0,0,0,0.08)">
          <div style="font-size:56px;margin-bottom:16px">❌</div>
          <h2 style="color:#e53e3e;margin:0 0 12px">Invalid Link</h2>
          <p style="color:#555">No reset token provided. Please request a new password reset from the app.</p>
        </div>
      </body></html>
    `);
  }

  // Validate token before showing form
  const user = await User.findOne({
    resetPasswordToken: token,
    resetPasswordExpires: { $gt: new Date() },
  });

  if (!user) {
    return res.status(400).send(`
      <html><body style="font-family:-apple-system,sans-serif;text-align:center;padding:60px;background:#f5f5f5">
        <div style="max-width:480px;margin:0 auto;background:#fff;border-radius:16px;padding:48px;box-shadow:0 4px 24px rgba(0,0,0,0.08)">
          <div style="font-size:56px;margin-bottom:16px">⏰</div>
          <h2 style="color:#e53e3e;margin:0 0 12px">Link Expired</h2>
          <p style="color:#555">This password reset link has expired or is invalid.<br/>Please request a new one from the Nestoric app.</p>
        </div>
      </body></html>
    `);
  }

  const baseUrl = process.env.BACKEND_URL || 'https://nestoric-backend.onrender.com';

  res.send(`
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="utf-8"/>
      <meta name="viewport" content="width=device-width, initial-scale=1"/>
      <title>Reset Password – Nestoric</title>
      <style>
        * { box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #f5f5f5; margin: 0; padding: 20px; }
        .container { max-width: 420px; margin: 40px auto; background: #fff; border-radius: 16px; overflow: hidden; box-shadow: 0 4px 24px rgba(0,0,0,0.08); }
        .header { background: linear-gradient(135deg, #FF6B6B, #FF8E53); padding: 32px; text-align: center; }
        .header h1 { color: #fff; margin: 0; font-size: 24px; font-weight: 800; }
        .header p { color: rgba(255,255,255,0.9); margin: 6px 0 0; font-size: 14px; }
        .body { padding: 32px; }
        .body p { color: #555; font-size: 15px; margin: 0 0 20px; }
        label { display: block; font-size: 13px; font-weight: 600; color: #333; margin-bottom: 6px; }
        input[type=password] { width: 100%; padding: 12px 14px; border: 1.5px solid #e0e0e0; border-radius: 10px; font-size: 15px; outline: none; transition: border 0.2s; }
        input[type=password]:focus { border-color: #FF6B6B; }
        .gap { height: 16px; }
        button { width: 100%; padding: 14px; background: linear-gradient(135deg, #FF6B6B, #FF8E53); color: #fff; border: none; border-radius: 10px; font-size: 16px; font-weight: 700; cursor: pointer; margin-top: 24px; }
        button:hover { opacity: 0.9; }
        .error { color: #e53e3e; font-size: 13px; margin-top: 8px; display: none; }
        .success-box { text-align: center; padding: 32px; display: none; }
        .success-box .icon { font-size: 56px; margin-bottom: 12px; }
        .success-box h2 { color: #38a169; margin: 0 0 10px; }
        .success-box p { color: #555; font-size: 15px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>Reset Password</h1>
          <p>Nestoric Platform</p>
        </div>
        <div class="body">
          <div id="form-section">
            <p>Enter your new password below.</p>
            <label for="newPassword">New Password</label>
            <input type="password" id="newPassword" placeholder="At least 6 characters" minlength="6"/>
            <div class="gap"></div>
            <label for="confirmPassword">Confirm Password</label>
            <input type="password" id="confirmPassword" placeholder="Repeat your password"/>
            <div class="error" id="error-msg"></div>
            <button onclick="submitReset()">Set New Password</button>
          </div>
          <div class="success-box" id="success-section">
            <div class="icon">✅</div>
            <h2>Password Reset!</h2>
            <p>Your password has been changed successfully.<br/>Open the Nestoric app and sign in.</p>
          </div>
        </div>
      </div>

      <script>
        async function submitReset() {
          const newPassword = document.getElementById('newPassword').value;
          const confirmPassword = document.getElementById('confirmPassword').value;
          const errorMsg = document.getElementById('error-msg');

          errorMsg.style.display = 'none';

          if (newPassword.length < 6) {
            errorMsg.textContent = 'Password must be at least 6 characters.';
            errorMsg.style.display = 'block';
            return;
          }
          if (newPassword !== confirmPassword) {
            errorMsg.textContent = 'Passwords do not match.';
            errorMsg.style.display = 'block';
            return;
          }

          try {
            const res = await fetch('${baseUrl}/api/auth/reset-password', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ token: '${token}', newPassword }),
            });
            const data = await res.json();

            if (res.ok) {
              document.getElementById('form-section').style.display = 'none';
              document.getElementById('success-section').style.display = 'block';
            } else {
              errorMsg.textContent = data.error || 'Something went wrong. Please try again.';
              errorMsg.style.display = 'block';
            }
          } catch (e) {
            errorMsg.textContent = 'Network error. Please check your connection.';
            errorMsg.style.display = 'block';
          }
        }
      </script>
    </body>
    </html>
  `);
});

// ==========================================
// RESET PASSWORD - Use token to set new password
// ==========================================
router.post('/reset-password', async (req, res) => {
  try {
    const { token, newPassword } = req.body;

    if (!token || !newPassword) {
      return res.status(400).json({ error: 'Token and new password are required' });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }

    // Find user with valid token
    const user = await User.findOne({
      resetPasswordToken: token,
      resetPasswordExpires: { $gt: new Date() } // Expiry must be in the future
    });

    if (!user) {
      return res.status(400).json({ error: 'Password reset token is invalid or has expired.' });
    }

    // Hash new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Update user
    user.password = hashedPassword;
    user.resetPasswordToken = undefined;
    user.resetPasswordExpires = undefined;
    await user.save();

    res.json({ message: 'Password has been successfully reset. You can now log in.' });
  } catch (error) {
    console.error('Reset password error:', error);
    res.status(500).json({ error: 'Failed to reset password.' });
  }
});

// Export router
module.exports = router;

// ==========================================
// HOW TO USE THESE ROUTES IN FLUTTER:
// ==========================================
//
// 1. SIGNUP:
//    POST http://localhost:3000/api/auth/signup
//    Body: { "email": "...", "password": "...", "fullName": "..." }
//    Response: { "user": {...}, "token": "..." }
//
// 2. LOGIN:
//    POST http://localhost:3000/api/auth/login
//    Body: { "email": "...", "password": "..." }
//    Response: { "user": {...}, "token": "..." }
//
// 3. GET PROFILE:
//    GET http://localhost:3000/api/auth/me
//    Headers: { "Authorization": "Bearer YOUR_TOKEN" }
//    Response: { "user": {...} }
//
// 4. UPDATE PROFILE:
//    PUT http://localhost:3000/api/auth/profile
//    Headers: { "Authorization": "Bearer YOUR_TOKEN" }
//    Body: { "fullName": "...", "avatarUrl": "..." }
//
// ==========================================